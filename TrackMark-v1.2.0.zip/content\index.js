"use strict";
(() => {
  // src/storage/storage-manager.ts
  var StorageManager = class {
    static async getVideoData(videoId) {
      try {
        const result = await chrome.storage.local.get(videoId);
        return result[videoId] || null;
      } catch (error) {
        console.error("[TrackMark] Error getting video data:", error);
        return null;
      }
    }
    static async saveVideoData(data) {
      try {
        data.lastUpdated = Date.now();
        await chrome.storage.local.set({ [data.videoId]: data });
      } catch (error) {
        console.error("[TrackMark] Error saving video data:", error);
      }
    }
    static async getAllData() {
      try {
        const all = await chrome.storage.local.get(null);
        return all;
      } catch (error) {
        console.error("[TrackMark] Error getting all data:", error);
        return {};
      }
    }
    static async upsertTrack(videoId, videoTitle, duration, track) {
      let videoData = await this.getVideoData(videoId);
      if (!videoData) {
        videoData = {
          videoId,
          videoTitle,
          duration,
          tracks: [],
          activeTrackId: null,
          isLoopActive: false,
          lastUpdated: Date.now()
        };
      }
      const index = videoData.tracks.findIndex((t) => t.id === track.id);
      if (index >= 0) {
        videoData.tracks[index] = { ...track, updatedAt: Date.now() };
      } else {
        videoData.tracks.push({ ...track, createdAt: Date.now(), updatedAt: Date.now() });
      }
      videoData.tracks.sort((a, b) => a.startTime - b.startTime);
      await this.saveVideoData(videoData);
      return videoData;
    }
    static async deleteTrack(videoId, trackId) {
      const videoData = await this.getVideoData(videoId);
      if (!videoData) return null;
      videoData.tracks = videoData.tracks.filter((t) => t.id !== trackId);
      if (videoData.activeTrackId === trackId) {
        videoData.activeTrackId = null;
        videoData.isLoopActive = false;
      }
      await this.saveVideoData(videoData);
      return videoData;
    }
    static async toggleFavorite(videoId, trackId) {
      const videoData = await this.getVideoData(videoId);
      if (!videoData) return false;
      const track = videoData.tracks.find((t) => t.id === trackId);
      if (!track) return false;
      track.isFavorite = !track.isFavorite;
      track.updatedAt = Date.now();
      await this.saveVideoData(videoData);
      return track.isFavorite;
    }
    static async clearAllTracks(videoId) {
      const videoData = await this.getVideoData(videoId);
      if (!videoData) return null;
      videoData.tracks = [];
      videoData.activeTrackId = null;
      videoData.lastUpdated = Date.now();
      await this.saveVideoData(videoData);
      return videoData;
    }
    static async getEqSettings() {
      try {
        const res = await chrome.storage.local.get("__tm_global_eq");
        return res["__tm_global_eq"] || null;
      } catch {
        return null;
      }
    }
    static async saveEqSettings(settings) {
      try {
        await chrome.storage.local.set({ "__tm_global_eq": settings });
      } catch (e) {
        console.error("[TrackMark] Error saving EQ settings:", e);
      }
    }
    static async getBoostSettings() {
      try {
        const res = await chrome.storage.local.get("__tm_global_boost");
        return res["__tm_global_boost"] || null;
      } catch {
        return null;
      }
    }
    static async saveBoostSettings(settings) {
      try {
        await chrome.storage.local.set({ "__tm_global_boost": settings });
      } catch (e) {
        console.error("[TrackMark] Error saving boost settings:", e);
      }
    }
  };

  // src/core/video-controller.ts
  var VideoController = class {
    video = null;
    activeTrack = null;
    isLoopActive = false;
    listeners = [];
    isSeekingGuard = false;
    isProgrammaticSeek = false;
    pollInterval = null;
    currentVideoId = null;
    constructor() {
      this.attachToVideo();
    }
    attachToVideo() {
      const videoEl = document.querySelector("video.html5-main-video");
      if (videoEl && videoEl !== this.video) {
        this.detachListeners();
        this.video = videoEl;
        this.attachListeners();
        console.log("[TrackMark] Attached to YouTube HTML5 video element");
        this.notifyState();
        return true;
      }
      return !!this.video;
    }
    setVideoId(videoId) {
      this.currentVideoId = videoId;
      this.notifyState();
    }
    setActiveTrack(track) {
      this.activeTrack = track;
      this.notifyState();
    }
    setLoop(active) {
      this.isLoopActive = active;
      if (this.isLoopActive && this.activeTrack && this.video) {
        const current = this.video.currentTime;
        if (current < this.activeTrack.startTime || current >= this.activeTrack.endTime) {
          this.seekTo(this.activeTrack.startTime);
        }
      }
      this.notifyState();
    }
    toggleLoop() {
      this.setLoop(!this.isLoopActive);
      return this.isLoopActive;
    }
    seekTo(timeInSeconds) {
      if (!this.video) {
        this.attachToVideo();
      }
      if (this.video) {
        const targetTime = Math.max(0, Math.min(timeInSeconds, this.video.duration || Infinity));
        this.isSeekingGuard = true;
        this.isProgrammaticSeek = true;
        this.video.currentTime = targetTime;
        setTimeout(() => {
          this.isSeekingGuard = false;
          this.isProgrammaticSeek = false;
        }, 250);
      }
    }
    getCurrentTime() {
      return this.video?.currentTime || 0;
    }
    getVideoElement() {
      return this.video;
    }
    getDuration() {
      return this.video?.duration || 0;
    }
    isPlaying() {
      return !!(this.video && !this.video.paused && !this.video.ended && this.video.readyState > 2);
    }
    isAdPlaying() {
      const moviePlayer = document.querySelector("#movie_player");
      if (!moviePlayer) return false;
      return moviePlayer.classList.contains("ad-showing") || moviePlayer.classList.contains("ad-interrupting");
    }
    subscribe(listener) {
      this.listeners.push(listener);
      listener(this.getState());
      return () => {
        this.listeners = this.listeners.filter((l) => l !== listener);
      };
    }
    getState() {
      return {
        videoId: this.currentVideoId,
        currentTime: this.getCurrentTime(),
        duration: this.getDuration(),
        isPlaying: this.isPlaying(),
        isLoopActive: this.isLoopActive,
        activeTrack: this.activeTrack,
        isAdPlaying: this.isAdPlaying()
      };
    }
    attachListeners() {
      if (!this.video) return;
      this.video.addEventListener("timeupdate", this.handleTimeUpdate);
      this.video.addEventListener("play", this.handleMediaEvent);
      this.video.addEventListener("pause", this.handleMediaEvent);
      this.video.addEventListener("ended", this.handleMediaEvent);
      this.video.addEventListener("seeking", this.handleUserSeeking);
      this.video.addEventListener("seeked", this.handleMediaEvent);
      this.pollInterval = window.setInterval(() => {
        if (!this.video || !document.contains(this.video)) {
          this.attachToVideo();
        }
      }, 1e3);
    }
    detachListeners() {
      if (!this.video) return;
      this.video.removeEventListener("timeupdate", this.handleTimeUpdate);
      this.video.removeEventListener("play", this.handleMediaEvent);
      this.video.removeEventListener("pause", this.handleMediaEvent);
      this.video.removeEventListener("ended", this.handleMediaEvent);
      this.video.removeEventListener("seeking", this.handleUserSeeking);
      this.video.removeEventListener("seeked", this.handleMediaEvent);
      if (this.pollInterval !== null) {
        clearInterval(this.pollInterval);
        this.pollInterval = null;
      }
    }
    handleUserSeeking = () => {
      if (!this.video || this.isProgrammaticSeek) return;
      const current = this.video.currentTime;
      if (this.isLoopActive && this.activeTrack) {
        console.log(`[TrackMark] User manual seek detected (${current.toFixed(2)}s). Disabling loop.`);
        this.setLoop(false);
        return;
      }
      this.notifyState();
    };
    handleTimeUpdate = () => {
      if (!this.video) return;
      if (this.isAdPlaying()) {
        return;
      }
      const current = this.video.currentTime;
      if (this.isLoopActive && this.activeTrack && !this.isSeekingGuard) {
        const { startTime, endTime } = this.activeTrack;
        if (endTime > startTime) {
          if (current >= endTime) {
            this.isSeekingGuard = true;
            this.isProgrammaticSeek = true;
            this.video.currentTime = startTime;
            if (this.video.paused) {
              this.video.play().catch(() => {
              });
            }
            setTimeout(() => {
              this.isSeekingGuard = false;
              this.isProgrammaticSeek = false;
            }, 250);
          }
        }
      }
      this.notifyState();
    };
    handleMediaEvent = () => {
      this.notifyState();
    };
    notifyState() {
      const state = this.getState();
      this.listeners.forEach((listener) => {
        try {
          listener(state);
        } catch (err) {
          console.error("[TrackMark] Listener error:", err);
        }
      });
    }
    destroy() {
      this.detachListeners();
      this.listeners = [];
      this.video = null;
    }
  };

  // src/core/spa-navigator.ts
  var SPANavigator = class {
    currentVideoId = null;
    listeners = [];
    pollTimer = null;
    constructor() {
      this.initListeners();
    }
    getVideoId() {
      const url = new URL(window.location.href);
      if (url.pathname.startsWith("/watch")) {
        return url.searchParams.get("v");
      }
      return null;
    }
    onVideoChange(callback) {
      this.listeners.push(callback);
      const current = this.getVideoId();
      callback(current, null);
      return () => {
        this.listeners = this.listeners.filter((cb) => cb !== callback);
      };
    }
    initListeners() {
      this.currentVideoId = this.getVideoId();
      const check = (source) => this.checkVideoChange(source);
      window.addEventListener("yt-navigate-finish", () => check("yt-navigate-finish"));
      document.addEventListener("yt-navigate-finish", () => check("doc-yt-navigate-finish"));
      window.addEventListener("yt-page-data-updated", () => check("yt-page-data-updated"));
      document.addEventListener("yt-page-data-updated", () => check("doc-yt-page-data-updated"));
      window.addEventListener("popstate", () => check("popstate"));
      this.pollTimer = window.setInterval(() => {
        check("interval-check");
      }, 400);
    }
    checkVideoChange(source) {
      const newVideoId = this.getVideoId();
      if (newVideoId !== this.currentVideoId) {
        console.log(`[TrackMark] Navigation (${source}): ${this.currentVideoId} -> ${newVideoId}`);
        const prev = this.currentVideoId;
        this.currentVideoId = newVideoId;
        this.listeners.forEach((cb) => cb(newVideoId, prev));
      }
    }
    destroy() {
      if (this.pollTimer !== null) {
        clearInterval(this.pollTimer);
        this.pollTimer = null;
      }
      this.listeners = [];
    }
  };

  // src/core/audio-booster.ts
  var EQ_FREQUENCIES = [60, 150, 400, 1e3, 2400, 15e3];
  var EQ_PRESETS = {
    flat: {
      id: "flat",
      name: "Flat (Off)",
      gains: [0, 0, 0, 0, 0, 0]
    },
    bass_boost: {
      id: "bass_boost",
      name: "Bass Boost (Trap / Reggaeton)",
      gains: [7, 5, 2, 0, 0, 0]
    },
    electronic: {
      id: "electronic",
      name: "Electronic / EDM / Dance",
      gains: [6, 4, 0, 2, 4, 5]
    },
    rock: {
      id: "rock",
      name: "Rock / Metal",
      gains: [5, 3, -1, 2, 4, 5]
    },
    pop: {
      id: "pop",
      name: "Pop",
      gains: [-1, 2, 4, 4, 2, -1]
    },
    hiphop: {
      id: "hiphop",
      name: "Hip-Hop / R&B",
      gains: [6, 5, 0, 2, 1, 3]
    },
    vocal: {
      id: "vocal",
      name: "Vocal / Podcast Clarity",
      gains: [-4, -2, 2, 5, 4, 1]
    },
    acoustic: {
      id: "acoustic",
      name: "Acoustic / Jazz",
      gains: [3, 2, 1, 2, 3, 3]
    },
    treble_boost: {
      id: "treble_boost",
      name: "Treble Boost (Brightness)",
      gains: [0, 0, 0, 2, 5, 7]
    }
  };
  var AudioBooster = class {
    audioCtx = null;
    gainNode = null;
    compressorNode = null;
    eqFilters = [];
    sourceNode = null;
    currentVideo = null;
    boostMultiplier = 1;
    isBoostEnabled = false;
    currentPresetId = "flat";
    customGains = [0, 0, 0, 0, 0, 0];
    constructor() {
      this.loadSavedEq();
      this.loadSavedBoost();
    }
    async loadSavedBoost() {
      const saved = await StorageManager.getBoostSettings();
      if (saved) {
        this.boostMultiplier = saved.multiplier;
        this.isBoostEnabled = saved.enabled;
        this.applySettings();
      }
    }
    async loadSavedEq() {
      const saved = await StorageManager.getEqSettings();
      if (saved) {
        this.currentPresetId = saved.presetId || "flat";
        if (Array.isArray(saved.gains) && saved.gains.length === 6) {
          this.customGains = [...saved.gains];
        }
        this.applySettings();
      }
    }
    init(video) {
      if (this.currentVideo === video && this.audioCtx) return;
      try {
        this.currentVideo = video;
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        this.audioCtx = new AudioContextClass();
        this.gainNode = this.audioCtx.createGain();
        this.compressorNode = this.audioCtx.createDynamicsCompressor();
        this.compressorNode.threshold.setValueAtTime(-12, this.audioCtx.currentTime);
        this.compressorNode.knee.setValueAtTime(24, this.audioCtx.currentTime);
        this.compressorNode.ratio.setValueAtTime(12, this.audioCtx.currentTime);
        this.compressorNode.attack.setValueAtTime(3e-3, this.audioCtx.currentTime);
        this.compressorNode.release.setValueAtTime(0.2, this.audioCtx.currentTime);
        this.eqFilters = EQ_FREQUENCIES.map((freq, index) => {
          const filter = this.audioCtx.createBiquadFilter();
          if (index === 0) {
            filter.type = "lowshelf";
          } else if (index === EQ_FREQUENCIES.length - 1) {
            filter.type = "highshelf";
          } else {
            filter.type = "peaking";
            filter.Q.setValueAtTime(1.4, this.audioCtx.currentTime);
          }
          filter.frequency.setValueAtTime(freq, this.audioCtx.currentTime);
          filter.gain.setValueAtTime(this.customGains[index] || 0, this.audioCtx.currentTime);
          return filter;
        });
        this.sourceNode = this.audioCtx.createMediaElementSource(video);
        let lastNode = this.sourceNode;
        for (const filter of this.eqFilters) {
          lastNode.connect(filter);
          lastNode = filter;
        }
        lastNode.connect(this.gainNode);
        this.gainNode.connect(this.compressorNode);
        this.compressorNode.connect(this.audioCtx.destination);
        this.applySettings();
      } catch (e) {
        console.warn("[TrackMark] AudioContext initialization deferred or already hooked:", e);
      }
    }
    setBoost(multiplier) {
      this.boostMultiplier = Math.max(1, Math.min(6, multiplier));
      this.applySettings();
      StorageManager.saveBoostSettings({
        multiplier: this.boostMultiplier,
        enabled: this.isBoostEnabled
      });
    }
    setEnabled(enabled) {
      this.isBoostEnabled = enabled;
      if (this.audioCtx && this.audioCtx.state === "suspended") {
        this.audioCtx.resume().catch(() => {
        });
      }
      this.applySettings();
      StorageManager.saveBoostSettings({
        multiplier: this.boostMultiplier,
        enabled: this.isBoostEnabled
      });
    }
    getBoost() {
      return this.boostMultiplier;
    }
    getIsEnabled() {
      return this.isBoostEnabled;
    }
    setBandGain(index, gainDb) {
      if (index < 0 || index >= this.customGains.length) return;
      const clampedGain = Math.max(-12, Math.min(12, gainDb));
      this.customGains[index] = clampedGain;
      this.currentPresetId = "custom";
      if (this.audioCtx && this.audioCtx.state === "suspended") {
        this.audioCtx.resume().catch(() => {
        });
      }
      if (this.eqFilters[index] && this.audioCtx) {
        this.eqFilters[index].gain.setValueAtTime(clampedGain, this.audioCtx.currentTime);
      }
      StorageManager.saveEqSettings({
        presetId: this.currentPresetId,
        gains: [...this.customGains]
      });
    }
    setPreset(presetId) {
      const preset = EQ_PRESETS[presetId];
      if (!preset) return;
      this.currentPresetId = presetId;
      this.customGains = [...preset.gains];
      if (this.audioCtx && this.audioCtx.state === "suspended") {
        this.audioCtx.resume().catch(() => {
        });
      }
      if (this.audioCtx && this.eqFilters.length === this.customGains.length) {
        const now = this.audioCtx.currentTime;
        this.customGains.forEach((gain, i) => {
          this.eqFilters[i].gain.setValueAtTime(gain, now);
        });
      }
      StorageManager.saveEqSettings({
        presetId: this.currentPresetId,
        gains: [...this.customGains]
      });
    }
    resetEq() {
      this.setPreset("flat");
    }
    getGains() {
      return [...this.customGains];
    }
    getCurrentPreset() {
      return this.currentPresetId;
    }
    applySettings() {
      if (!this.gainNode || !this.audioCtx) return;
      const now = this.audioCtx.currentTime;
      if (!this.isBoostEnabled) {
        this.gainNode.gain.setValueAtTime(1, now);
      } else {
        this.gainNode.gain.setValueAtTime(this.boostMultiplier, now);
      }
      if (this.eqFilters.length === this.customGains.length) {
        this.customGains.forEach((gain, i) => {
          this.eqFilters[i].gain.setValueAtTime(gain, now);
        });
      }
    }
  };

  // src/core/state-manager.ts
  var StateManager = class {
    videoController;
    spaNavigator;
    audioBooster;
    currentVideoData = null;
    listeners = [];
    constructor() {
      this.videoController = new VideoController();
      this.spaNavigator = new SPANavigator();
      this.audioBooster = new AudioBooster();
      this.init();
    }
    init() {
      this.spaNavigator.onVideoChange(async (videoId) => {
        this.videoController.attachToVideo();
        this.videoController.setVideoId(videoId);
        if (videoId) {
          setTimeout(async () => {
            this.videoController.attachToVideo();
            await this.loadVideoData(videoId);
          }, 150);
        } else {
          this.currentVideoData = null;
          this.videoController.setActiveTrack(null);
          this.videoController.setLoop(false);
          this.notify();
        }
      });
      this.videoController.subscribe((controllerState) => {
        this.autoSyncActiveTrack(controllerState.currentTime);
        this.syncLoopPersistence(controllerState.isLoopActive);
        this.notify();
      });
    }
    async loadVideoData(videoId) {
      let data = await StorageManager.getVideoData(videoId);
      const videoTitle = this.extractVideoTitle();
      const duration = this.videoController.getDuration();
      if (!data) {
        data = {
          videoId,
          videoTitle,
          duration,
          tracks: [],
          activeTrackId: null,
          isLoopActive: false,
          lastUpdated: Date.now()
        };
      } else {
        if (videoTitle && data.videoTitle !== videoTitle) {
          data.videoTitle = videoTitle;
        }
      }
      this.currentVideoData = data;
      if (data.activeTrackId) {
        const track = data.tracks.find((t) => t.id === data.activeTrackId) || null;
        this.videoController.setActiveTrack(track);
      } else {
        this.videoController.setActiveTrack(null);
      }
      this.videoController.setLoop(data.isLoopActive);
      this.notify();
      return data;
    }
    autoSyncActiveTrack(currentTime) {
      if (!this.currentVideoData || this.videoController.getState().isLoopActive) {
        return;
      }
      const currentTrack = this.currentVideoData.tracks.find(
        (t) => currentTime >= t.startTime && currentTime < t.endTime
      );
      if (currentTrack && currentTrack.id !== this.currentVideoData.activeTrackId) {
        this.currentVideoData.activeTrackId = currentTrack.id;
        this.videoController.setActiveTrack(currentTrack);
      }
    }
    syncLoopPersistence(controllerLoop) {
      if (!this.currentVideoData) return;
      if (this.currentVideoData.isLoopActive !== controllerLoop) {
        this.currentVideoData.isLoopActive = controllerLoop;
        StorageManager.saveVideoData(this.currentVideoData);
      }
    }
    async setLoop(active) {
      this.videoController.setLoop(active);
      if (this.currentVideoData) {
        this.currentVideoData.isLoopActive = active;
        await StorageManager.saveVideoData(this.currentVideoData);
      }
      this.notify();
    }
    async toggleLoop() {
      const newState = this.videoController.toggleLoop();
      if (this.currentVideoData) {
        this.currentVideoData.isLoopActive = newState;
        await StorageManager.saveVideoData(this.currentVideoData);
      }
      this.notify();
      return newState;
    }
    async selectTrack(trackId, jumpToStart = true) {
      if (!this.currentVideoData) return;
      const track = this.currentVideoData.tracks.find((t) => t.id === trackId) || null;
      this.currentVideoData.activeTrackId = trackId;
      this.videoController.setActiveTrack(track);
      if (track && jumpToStart) {
        this.videoController.seekTo(track.startTime);
      }
      await StorageManager.saveVideoData(this.currentVideoData);
      this.notify();
    }
    async addTrack(track) {
      if (!this.currentVideoData) return null;
      const newTrack = {
        ...track,
        id: `trk_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const updated = await StorageManager.upsertTrack(
        this.currentVideoData.videoId,
        this.currentVideoData.videoTitle,
        this.videoController.getDuration(),
        newTrack
      );
      this.currentVideoData = updated;
      this.notify();
      return newTrack;
    }
    async importBulkTracks(candidates) {
      if (!this.currentVideoData || candidates.length === 0) return 0;
      let count = 0;
      for (const c of candidates) {
        const newTrack = {
          id: `trk_${Date.now()}_${Math.random().toString(36).substring(2, 7)}_${count}`,
          title: c.title,
          startTime: c.startTime,
          endTime: c.endTime,
          isFavorite: false,
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        this.currentVideoData.tracks.push(newTrack);
        count++;
      }
      this.currentVideoData.tracks.sort((a, b) => a.startTime - b.startTime);
      await StorageManager.saveVideoData(this.currentVideoData);
      this.notify();
      return count;
    }
    async deleteTrack(trackId) {
      if (!this.currentVideoData) return;
      const updated = await StorageManager.deleteTrack(this.currentVideoData.videoId, trackId);
      if (updated) {
        this.currentVideoData = updated;
        if (this.currentVideoData.activeTrackId === trackId) {
          this.videoController.setActiveTrack(null);
        }
        this.notify();
      }
    }
    async clearAllTracks() {
      if (!this.currentVideoData) return;
      const updated = await StorageManager.clearAllTracks(this.currentVideoData.videoId);
      if (updated) {
        this.currentVideoData = updated;
        this.videoController.setActiveTrack(null);
        this.notify();
      }
    }
    async toggleFavorite(trackId) {
      if (!this.currentVideoData) return false;
      const isFav = await StorageManager.toggleFavorite(this.currentVideoData.videoId, trackId);
      const track = this.currentVideoData.tracks.find((t) => t.id === trackId);
      if (track) {
        track.isFavorite = isFav;
      }
      this.notify();
      return isFav;
    }
    subscribe(listener) {
      this.listeners.push(listener);
      listener(this.currentVideoData, this.videoController.getState());
      return () => {
        this.listeners = this.listeners.filter((l) => l !== listener);
      };
    }
    getVideoData() {
      return this.currentVideoData;
    }
    extractVideoTitle() {
      const titleEl = document.querySelector("h1.ytd-watch-metadata yt-formatted-string, #title h1");
      return titleEl?.textContent?.trim() || document.title.replace(" - YouTube", "").trim() || "YouTube Video";
    }
    notify() {
      const controllerState = this.videoController.getState();
      this.listeners.forEach((cb) => {
        try {
          cb(this.currentVideoData, controllerState);
        } catch (err) {
          console.error("[TrackMark] StateManager notification error:", err);
        }
      });
    }
  };

  // src/ui/styles.ts
  var stylesText = `
:host {
  all: initial;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color: #d4d4d8;
  box-sizing: border-box;
}

*, *::before, *::after {
  box-sizing: border-box;
}

@keyframes tm-spin-light {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

@keyframes tm-logo-shimmer {
  0% {
    background-position: 200% center;
  }
  100% {
    background-position: -200% center;
  }
}

@keyframes tm-pane-fade {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.tm-menu-wrapper {
  position: absolute;
  right: 20px;
  bottom: 64px;
  width: 420px;
  max-height: 560px;
  border-radius: 8px;
  padding: 1.5px;
  background: #181820;
  box-shadow: 0 0 30px rgba(0, 240, 255, 0.2), 0 20px 50px rgba(0, 0, 0, 0.95);
  z-index: 999999;
  pointer-events: auto !important;
  user-select: none;
  display: flex;
  overflow: hidden;
  position: absolute;
}

.tm-border-light {
  position: absolute;
  top: -150%;
  left: -150%;
  width: 400%;
  height: 400%;
  background: conic-gradient(
    from 0deg,
    #ff2a6d 0deg,
    #ff9f1c 60deg,
    #05ffa1 120deg,
    #00f0ff 180deg,
    #7000ff 240deg,
    #ff2a6d 360deg
  );
  animation: tm-spin-light 3.5s linear infinite;
  z-index: 0;
  pointer-events: none;
}

.tm-menu {
  position: relative;
  z-index: 1;
  width: 100%;
  height: 100%;
  background: #111115;
  border-radius: 6.5px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.tm-header {
  padding: 10px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #15151b;
  border-bottom: 1px solid #1f1f27;
  cursor: grab;
}

.tm-header:active {
  cursor: grabbing;
}

.tm-title-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tm-logo-icon-wrap {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  flex-shrink: 0;
}

.tm-logo-img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.tm-logo-text {
  font-size: 13px;
  font-weight: 900;
  letter-spacing: 1.5px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: linear-gradient(
    110deg,
    #ffffff 20%,
    #00f0ff 40%,
    #ffffff 50%,
    #05ffa1 60%,
    #ffffff 80%
  );
  background-size: 200% auto;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: tm-logo-shimmer 3.5s ease-in-out infinite;
  text-transform: uppercase;
  display: inline-block;
}

.tm-author-tag {
  font-size: 10px;
  color: #71717a;
  font-weight: 600;
  margin-left: 4px;
}

.tm-author-link {
  color: #00f0ff;
  text-decoration: none;
  font-weight: 700;
  transition: color 0.12s;
}

.tm-author-link:hover {
  color: #05ffa1;
  text-decoration: underline;
}

.tm-header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tm-header-icon-link {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #71717a;
  text-decoration: none;
  padding: 4px;
  border-radius: 50%;
  background: transparent;
  transition: color 0.15s ease, transform 0.15s ease;
}

.tm-header-icon-link:hover {
  color: #00f0ff;
  background: transparent;
  transform: scale(1.15);
  filter: drop-shadow(0 0 5px rgba(0, 240, 255, 0.7));
}

.tm-btn-close {
  background: none;
  border: none;
  color: #71717a;
  cursor: pointer;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 13px;
  font-weight: bold;
  transition: all 0.12s;
}

.tm-btn-close:hover {
  color: #fff;
  background: #23232b;
}

.tm-tabs {
  display: flex;
  background: #0d0d10;
  margin: 8px 12px 6px 12px;
  padding: 3px;
  border-radius: 6px;
  border: 1px solid #1c1c24;
  gap: 3px;
}

button, input, select, textarea {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}

.tm-tab {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  flex: 1;
  padding: 5px 2px;
  text-align: center;
  font-size: 10px;
  font-weight: 700;
  color: #71717a;
  background: transparent;
  border: 1px solid transparent;
  border-radius: 4px;
  cursor: pointer;
  letter-spacing: 0.3px;
  transition: color 0.12s ease, background 0.12s ease, border-color 0.12s ease;
  outline: none;
  white-space: nowrap;
}

.tm-tab:hover {
  color: #e4e4e7;
  background: rgba(255, 255, 255, 0.04);
}

.tm-tab.active {
  color: #fff;
  background: #1d1d27;
  border: 1px solid #2d2d3c;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5), 0 0 1px rgba(255, 255, 255, 0.2);
  font-weight: 700;
}

.tm-content-pane {
  display: none;
  flex-direction: column;
  flex: 1;
}

.tm-content-pane.active {
  display: flex;
}

.tm-title-with-info {
  display: flex;
  align-items: center;
  gap: 6px;
}

.tm-info-tooltip-wrap {
  position: relative;
  display: inline-flex;
  align-items: center;
  cursor: pointer;
}

.tm-info-icon {
  font-size: 11px;
  opacity: 0.65;
  transition: opacity 0.15s, transform 0.15s;
}

.tm-info-tooltip-wrap:hover .tm-info-icon {
  opacity: 1;
  transform: scale(1.15);
}

.tm-tooltip-content {
  visibility: hidden;
  opacity: 0;
  width: 230px;
  background: #161622;
  color: #d4d4d8;
  text-align: left;
  border-radius: 6px;
  padding: 8px 10px;
  position: absolute;
  z-index: 100000;
  top: 100%;
  left: 0;
  margin-top: 6px;
  border: 1px solid #2d2d42;
  box-shadow: 0 8px 24px rgba(0,0,0,0.8), 0 0 10px rgba(0, 240, 255, 0.15);
  font-size: 10px;
  line-height: 1.4;
  pointer-events: none;
  transition: opacity 0.18s ease, visibility 0.18s ease, transform 0.18s ease;
  transform: translateY(-4px);
}

.tm-tooltip-content strong {
  color: #00f0ff;
}

.tm-info-tooltip-wrap:hover .tm-tooltip-content {
  visibility: visible;
  opacity: 1;
  transform: translateY(0);
}

.tm-tools-row {
  display: flex;
  gap: 6px;
}


.tm-active-bar {
  padding: 10px 14px;
  background: #141419;
  border-bottom: 1px solid #1f1f27;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.tm-active-info {
  display: flex;
  flex-direction: column;
  gap: 3px;
  overflow: hidden;
  flex: 1;
}

.tm-active-title {
  font-size: 12px;
  font-weight: 700;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tm-active-times {
  font-size: 10px;
  color: #00f0ff;
  font-family: monospace;
  font-weight: 600;
}



.tm-toggle-loop {
  padding: 5px 12px;
  border-radius: 4px;
  border: 1px solid #272736;
  background: #181822;
  color: #a1a1aa;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.15s;
  letter-spacing: 0.4px;
}

.tm-toggle-loop.active {
  background: #00f0ff;
  color: #000;
  border-color: #00f0ff;
  box-shadow: 0 0 12px rgba(0, 240, 255, 0.45);
  font-weight: 800;
}

.tm-toggle-loop:hover {
  filter: brightness(1.15);
}

.tm-add-section {
  padding: 10px 14px;
  background: #131317;
  border-bottom: 1px solid #1f1f27;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.tm-inputs-row {
  display: flex;
  gap: 6px;
}

.tm-input {
  background: #191920;
  border: 1px solid #272732;
  border-radius: 4px;
  color: #fff;
  padding: 6px 10px;
  font-size: 11px;
  outline: none;
  transition: all 0.12s;
}

.tm-input:focus {
  border-color: #00f0ff;
  background: #1e1e27;
  box-shadow: 0 0 6px rgba(0, 240, 255, 0.2);
}

.tm-input-title {
  flex: 1;
}

.tm-input-time {
  width: 72px;
  text-align: center;
  font-family: monospace;
}

.tm-btn-primary {
  background: #181824;
  color: #00f0ff;
  border: 1px solid #00f0ff;
  border-radius: 4px;
  padding: 7px 12px;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.15s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  letter-spacing: 0.5px;
}

.tm-btn-primary:hover {
  background: #00f0ff;
  color: #000;
  box-shadow: 0 0 12px rgba(0, 240, 255, 0.5);
}

.tm-btn-primary.active {
  background: #00f0ff;
  color: #000;
  box-shadow: 0 0 10px rgba(0, 240, 255, 0.4);
}

.tm-list {
  flex: 1;
  overflow-y: auto;
  max-height: 200px;
  background: #111115;
  scroll-behavior: smooth;
}

.tm-list::-webkit-scrollbar {
  width: 7px;
}

.tm-list::-webkit-scrollbar-track {
  background: #14141c;
  border-radius: 4px;
}

.tm-list::-webkit-scrollbar-thumb {
  background: #00f0ff;
  border-radius: 4px;
  box-shadow: 0 0 8px rgba(0, 240, 255, 0.5);
}

.tm-list::-webkit-scrollbar-thumb:hover {
  background: #05ffa1;
  box-shadow: 0 0 10px rgba(5, 255, 161, 0.7);
}

.tm-empty {
  padding: 24px 14px;
  text-align: center;
  color: #52525b;
  font-size: 11px;
}

.tm-track-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 14px;
  border-bottom: 1px solid #16161f;
  cursor: pointer;
  transition: background 0.12s ease;
  position: relative;
  background: transparent;
}

.tm-track-item:hover {
  background: #171720;
}

.tm-track-item.active {
  background: #1f1f2d;
}

.tm-track-item.active .tm-track-name {
  color: #fff;
  font-weight: 700;
  font-size: 11px;
}

.tm-active-badge {
  display: inline-block;
  color: #00f0ff;
  font-size: 9px;
  margin-right: 5px;
  vertical-align: middle;
}

.tm-track-item.active .tm-track-range {
  color: #00f0ff;
  font-weight: 600;
}


@keyframes tm-marquee-scroll {
  0%, 20% {
    transform: translateX(0);
  }
  80%, 100% {
    transform: translateX(var(--marquee-dist, -50%));
  }
}

@keyframes tm-star-pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.25) rotate(15deg); }
  100% { transform: scale(1); }
}

.tm-track-details {
  display: flex;
  flex-direction: column;
  gap: 2px;
  overflow: hidden;
  flex: 1;
  padding-right: 8px;
  min-width: 0;
}

.tm-track-name-wrap {
  width: 100%;
  overflow: hidden;
  position: relative;
}

.tm-track-name {
  font-size: 11px;
  font-weight: 600;
  color: #e4e4e7;
  display: flex;
  align-items: center;
  white-space: nowrap;
  transition: color 0.12s;
  width: 100%;
  overflow: hidden;
}

.tm-title-inner {
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
}

.tm-title-inner.overflowing {
  overflow: visible;
  text-overflow: clip;
  animation: tm-marquee-scroll 6s cubic-bezier(0.45, 0.05, 0.55, 0.95) infinite alternate;
}

.tm-track-meta {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tm-track-range {
  font-size: 10px;
  color: #71717a;
  font-family: monospace;
}

.tm-track-search-links {
  display: flex;
  align-items: center;
  gap: 4px;
}

.tm-search-link {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  padding: 1px 4px;
  border-radius: 3px;
  font-size: 8.5px;
  font-weight: 700;
  text-decoration: none;
  background: #181822;
  border: 1px solid #282836;
  color: #a1a1aa;
  transition: all 0.12s;
}

.tm-search-link:hover {
  color: #fff;
  border-color: #00f0ff;
  background: #222230;
}

.tm-search-yt:hover {
  color: #ff0033;
  border-color: #ff0033;
}

.tm-search-sc:hover {
  color: #ff5500;
  border-color: #ff5500;
}

.tm-track-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.tm-btn-fav {
  background: none;
  border: none;
  cursor: pointer;
  padding: 3px;
  border-radius: 4px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #4b4b5c;
  transition: all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.tm-btn-fav:hover {
  color: #00f0ff;
  transform: scale(1.15);
}

.tm-btn-fav.starred {
  color: #00f0ff;
  filter: drop-shadow(0 0 5px rgba(0, 240, 255, 0.8));
  animation: tm-star-pulse 0.4s ease;
}

.tm-btn-fav.starred:hover {
  color: #05ffa1;
  filter: drop-shadow(0 0 6px rgba(5, 255, 161, 0.9));
}

.tm-btn-del {
  background: none;
  border: none;
  color: #71717a;
  cursor: pointer;
  padding: 2px 4px;
  font-size: 11px;
  border-radius: 3px;
  transition: all 0.12s;
}

.tm-btn-del:hover {
  color: #fff;
  background: rgba(255, 42, 109, 0.2);
}

.tm-btn-danger {
  color: #ff2a6d !important;
  border-color: #ff2a6d !important;
}

.tm-btn-danger:hover {
  background: #ff2a6d !important;
  color: #fff !important;
  box-shadow: 0 0 10px rgba(255, 42, 109, 0.5) !important;
}

.tm-boost-panel {
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 14px;
  background: #111115;
  overflow-y: auto;
  max-height: 440px;
}

.tm-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.tm-btn-reset-eq {
  background: #1c1c24;
  border: 1px solid #2d2d3c;
  color: #71717a;
  border-radius: 4px;
  font-size: 9.5px;
  font-weight: 700;
  padding: 2px 8px;
  cursor: pointer;
  transition: all 0.15s;
}

.tm-btn-reset-eq:hover {
  color: #00f0ff;
  border-color: #00f0ff;
}

.tm-preset-select-wrap {
  position: relative;
  width: 100%;
  margin-bottom: 10px;
}

.tm-preset-select {
  width: 100%;
  background: #16161f;
  border: 1px solid #272736;
  border-radius: 5px;
  color: #00f0ff;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 10px;
  outline: none;
  cursor: pointer;
  transition: border 0.15s;
}

.tm-preset-select:focus {
  border-color: #00f0ff;
  box-shadow: 0 0 6px rgba(0, 240, 255, 0.25);
}

.tm-preset-select option {
  background: #14141c;
  color: #fff;
}

.tm-eq-rack {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #16161d;
  border: 1px solid #23232f;
  border-radius: 6px;
  padding: 10px 8px;
  gap: 4px;
}

.tm-eq-col {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  flex: 1;
}

.tm-eq-val {
  font-size: 9.5px;
  font-weight: 700;
  color: #71717a;
  font-family: monospace;
}

.tm-eq-val.active {
  color: #05ffa1;
}

.tm-slider-v {
  -webkit-appearance: slider-vertical;
  appearance: slider-vertical;
  width: 16px;
  height: 80px;
  background: transparent;
  outline: none;
  cursor: pointer;
  accent-color: #00f0ff;
  display: inline-block;
  margin: 0 auto;
}


.tm-eq-freq {
  font-size: 9.5px;
  font-weight: 700;
  color: #a1a1aa;
}

.tm-boost-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
  background: #16161d;
  border: 1px solid #23232f;
  border-radius: 6px;
  padding: 10px;
}

.tm-boost-controls {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 6px;
}

.tm-btn-preset {
  background: #1f1f2a;
  border: 1px solid #2d2d3b;
  color: #a1a1aa;
  border-radius: 4px;
  padding: 6px 0;
  font-size: 10px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.12s;
}

.tm-btn-preset:hover {
  color: #05ffa1;
  border-color: #05ffa1;
}

.tm-btn-preset.active {
  background: #05ffa1;
  color: #000;
  border-color: #05ffa1;
  box-shadow: 0 0 8px rgba(5, 255, 161, 0.35);
}

.tm-boost-status {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.tm-boost-value-label {
  font-size: 11px;
  font-weight: 700;
  color: #05ffa1;
  font-family: monospace;
}

.tm-btn-toggle-boost {
  background: #1f1f2a;
  border: 1px solid #2d2d3b;
  color: #00f0ff;
  border-radius: 4px;
  padding: 5px 10px;
  font-size: 9.5px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.12s;
  text-transform: uppercase;
}

.tm-btn-toggle-boost:hover {
  background: #00f0ff;
  color: #000;
}

.tm-btn-toggle-boost.active {
  background: #00f0ff;
  color: #000;
  border-color: #00f0ff;
  box-shadow: 0 0 8px rgba(0, 240, 255, 0.35);
}

.tm-tools-panel {
  padding: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #111115;
}

.tm-tool-card {
  background: #16161d;
  border: 1px solid #23232c;
  border-radius: 4px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.tm-tool-title {
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  text-transform: uppercase;
}

.tm-tool-desc {
  font-size: 10px;
  color: #71717a;
}

.tm-btn-action {
  background: #1f1f2a;
  border: 1px solid #2d2d3b;
  border-radius: 4px;
  color: #00f0ff;
  padding: 7px 10px;
  font-size: 10px;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: all 0.12s;
  text-transform: uppercase;
}

.tm-btn-action:hover {
  background: #00f0ff;
  color: #000;
  box-shadow: 0 0 10px rgba(0, 240, 255, 0.4);
}

.tm-footer {
  padding: 8px 14px;
  background: #141418;
  border-top: 1px solid #1f1f27;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.tm-footer-btn {
  background: none;
  border: none;
  color: #71717a;
  font-size: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: color 0.12s;
}

.tm-footer-btn:hover {
  color: #00f0ff;
}

.tm-modal-view {
  position: absolute;
  inset: 0;
  background: #111115;
  z-index: 1000000;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.tm-modal-header {
  padding: 10px 14px;
  border-bottom: 1px solid #23232b;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #16161c;
}

.tm-modal-title {
  font-size: 12px;
  font-weight: 700;
  color: #00f0ff;
  text-transform: uppercase;
}

.tm-modal-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.tm-textarea {
  width: 100%;
  height: 150px;
  background: #181820;
  border: 1px solid #272734;
  border-radius: 4px;
  color: #fff;
  font-family: monospace;
  font-size: 11px;
  padding: 8px;
  resize: none;
  outline: none;
}

.tm-textarea:focus {
  border-color: #00f0ff;
}

.tm-preview-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  background: #17171f;
  border: 1px solid #22222c;
  border-radius: 4px;
  font-size: 11px;
}

.tm-preview-title {
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #e4e4e7;
}

.tm-preview-time {
  color: #00f0ff;
  font-family: monospace;
  font-size: 10px;
}

.tm-modal-footer {
  padding: 10px 14px;
  border-top: 1px solid #23232b;
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  background: #141418;
}

.tm-btn-secondary {
  background: #1d1d26;
  border: 1px solid #2b2b38;
  color: #a1a1aa;
  border-radius: 4px;
  padding: 6px 12px;
  font-size: 10px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.12s;
}

.tm-btn-secondary:hover {
  color: #fff;
  background: #272733;
}

.tm-list-bar {
  padding: 6px 14px;
  background: #111116;
  border-bottom: 1px solid #1a1a24;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.tm-list-count {
  font-size: 10px;
  font-weight: 700;
  color: #71717a;
  letter-spacing: 0.5px;
}

.tm-btn-filter-fav {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #171722;
  border: 1px solid #282836;
  color: #8e8e9f;
  padding: 3px 8px;
  border-radius: 4px;
  font-size: 9.5px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.15s ease;
  letter-spacing: 0.3px;
}

.tm-btn-filter-fav:hover {
  color: #00f0ff;
  border-color: #00f0ff;
  background: #1d1d2b;
}

.tm-btn-filter-fav.active {
  background: rgba(0, 240, 255, 0.15);
  border-color: #00f0ff;
  color: #00f0ff;
  box-shadow: 0 0 8px rgba(0, 240, 255, 0.3);
}

.tm-favs-header {
  padding: 10px 14px;
  background: #141419;
  border-bottom: 1px solid #1f1f27;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.tm-favs-header-title {
  font-size: 11.5px;
  font-weight: 800;
  color: #fff;
  letter-spacing: 0.4px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.tm-favs-count-badge {
  font-size: 9.5px;
  font-weight: 700;
  color: #00f0ff;
  background: rgba(0, 240, 255, 0.12);
  border: 1px solid rgba(0, 240, 255, 0.3);
  padding: 2px 7px;
  border-radius: 10px;
  font-family: monospace;
}

.tm-favs-list {
  max-height: 290px !important;
}

.tm-fav-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 9px 14px 9px 12px;
  border-bottom: 1px solid #16161f;
  border-left: 2px solid transparent;
  box-sizing: border-box;
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease;
  position: relative;
  background: transparent;
}

.tm-fav-item:hover {
  background: #171722;
  border-left-color: #00f0ff;
}

.tm-fav-item.active {
  background: #1d1d2c;
  border-left-color: #05ffa1;
}

.tm-fav-content {
  display: flex;
  flex-direction: column;
  gap: 3px;
  overflow: hidden;
  flex: 1;
  padding-right: 8px;
  min-width: 0;
}

.tm-fav-video-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow: hidden;
}

.tm-fav-video-name {
  font-size: 9.5px;
  color: #71717a;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 600;
}

.tm-fav-here-badge {
  display: inline-block;
  font-size: 8px;
  font-weight: 800;
  color: #05ffa1;
  background: rgba(5, 255, 161, 0.15);
  border: 1px solid rgba(5, 255, 161, 0.4);
  padding: 1px 4px;
  border-radius: 3px;
  letter-spacing: 0.4px;
}

.tm-fav-track-name {
  font-size: 11px;
  font-weight: 700;
  color: #f4f4f5;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: flex;
  align-items: center;
}

.tm-fav-meta-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tm-fav-actions {
  display: flex;
  align-items: center;
  gap: 6px;
}
`;

  // src/ui/shadow-host.ts
  var ShadowHost = class _ShadowHost {
    static instance = null;
    hostElement = null;
    shadowRoot = null;
    constructor() {
      this.mount();
    }
    static getInstance() {
      if (!_ShadowHost.instance) {
        _ShadowHost.instance = new _ShadowHost();
      }
      return _ShadowHost.instance;
    }
    mount() {
      if (this.shadowRoot && this.hostElement && document.contains(this.hostElement)) {
        return this.shadowRoot;
      }
      let playerContainer = document.querySelector("#movie_player");
      if (!playerContainer) {
        playerContainer = document.querySelector("ytd-player") || document.body;
      }
      if (!playerContainer) return null;
      let host = document.getElementById("trackmark-shadow-host");
      if (!host || !document.contains(host)) {
        if (host) host.remove();
        host = document.createElement("div");
        host.id = "trackmark-shadow-host";
        host.style.position = "absolute";
        host.style.top = "0";
        host.style.left = "0";
        host.style.width = "100%";
        host.style.height = "100%";
        host.style.pointerEvents = "none";
        host.style.zIndex = "999999";
        host.style.overflow = "visible";
        if (getComputedStyle(playerContainer).position === "static") {
          playerContainer.style.position = "relative";
        }
        playerContainer.appendChild(host);
        this.shadowRoot = host.attachShadow({ mode: "open" });
      } else {
        this.shadowRoot = host.shadowRoot;
      }
      this.hostElement = host;
      if (this.shadowRoot && !this.shadowRoot.querySelector("style#tm-styles")) {
        const styleEl = document.createElement("style");
        styleEl.id = "tm-styles";
        styleEl.textContent = stylesText;
        this.shadowRoot.appendChild(styleEl);
      }
      return this.shadowRoot;
    }
  };

  // src/parser/timestamp-regex.ts
  function timeStringToSeconds(timeStr) {
    const cleaned = timeStr.replace(/[^0-9:]/g, "").trim();
    const parts = cleaned.split(":").map(Number);
    if (parts.some(isNaN) || parts.length === 0) return 0;
    if (parts.length === 3) {
      return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    if (parts.length === 2) {
      return parts[0] * 60 + parts[1];
    }
    if (parts.length === 1) {
      return parts[0];
    }
    return 0;
  }
  var TIMESTAMP_REGEX = /(?:\[|\()?(?:(?:(\d{1,2}):)?([0-5]?\d):([0-5]\d))(?:\]|\))?/;
  function cleanTrackTitle(rawLine, timestampMatch) {
    let title = rawLine.replace(timestampMatch, "").trim();
    title = title.replace(/^#?\d{1,3}[\.\:\-\)\s]+\s*/, "").replace(/^(?:track|pista|song)\s*\d{1,3}[\.\:\-\s]*/i, "").replace(/^\[\d{1,3}\]\s*/, "").trim();
    title = title.replace(/^[\-–—\|\•\:\~\/\.\,\s]+/, "").replace(/[\-–—\|\•\:\~\/\.\,\s]+$/, "").trim();
    title = title.replace(/\(\s*\)/g, "").replace(/\[\s*\]/g, "").trim();
    return title;
  }
  function parseTracklistText(rawText, videoDuration = 0) {
    if (!rawText) return [];
    const lines = rawText.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    const candidates = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      const match = trimmed.match(TIMESTAMP_REGEX);
      if (!match) continue;
      const timestampStr = match[0];
      const startTime = timeStringToSeconds(timestampStr);
      let title = cleanTrackTitle(trimmed, timestampStr);
      if (!title || title.length < 2) {
        title = `Track @ ${timestampStr.replace(/[^0-9:]/g, "")}`;
      }
      candidates.push({
        title,
        startTime,
        rawLine: trimmed
      });
    }
    const uniqueCandidates = [];
    const seenTimes = /* @__PURE__ */ new Set();
    for (const item of candidates) {
      if (!seenTimes.has(item.startTime)) {
        seenTimes.add(item.startTime);
        uniqueCandidates.push(item);
      }
    }
    uniqueCandidates.sort((a, b) => a.startTime - b.startTime);
    const result = [];
    for (let i = 0; i < uniqueCandidates.length; i++) {
      const curr = uniqueCandidates[i];
      const next = uniqueCandidates[i + 1];
      let endTime;
      if (next) {
        endTime = next.startTime;
      } else {
        if (videoDuration > curr.startTime) {
          endTime = videoDuration;
        } else {
          endTime = curr.startTime + 180;
        }
      }
      result.push({
        title: curr.title,
        startTime: curr.startTime,
        endTime,
        rawLine: curr.rawLine
      });
    }
    return result;
  }

  // src/parser/tracklist-extractor.ts
  var TracklistExtractor = class {
    static extractFromDOM(videoDuration = 0) {
      const chaptersResult = this.extractFromChapters(videoDuration);
      if (chaptersResult.tracks.length >= 2) {
        return chaptersResult;
      }
      const descResult = this.extractFromDescription(videoDuration);
      if (descResult.tracks.length >= 2) {
        return descResult;
      }
      const commentsResult = this.extractFromComments(videoDuration);
      if (commentsResult.tracks.length >= 2) {
        return commentsResult;
      }
      if (descResult.tracks.length > 0) return descResult;
      if (chaptersResult.tracks.length > 0) return chaptersResult;
      if (commentsResult.tracks.length > 0) return commentsResult;
      return {
        source: "none",
        sourceLabel: "No automatic timestamps found",
        tracks: []
      };
    }
    static extractFromChapters(videoDuration = 0) {
      const chapterItems = document.querySelectorAll("ytd-macro-markers-list-item-renderer, ytd-chapter-renderer");
      if (chapterItems.length >= 2) {
        const textLines = [];
        chapterItems.forEach((item) => {
          const timeEl = item.querySelector("#time, .ytd-macro-markers-list-item-renderer#time");
          const titleEl = item.querySelector("#title, .ytd-macro-markers-list-item-renderer#title, h4");
          const timeText = timeEl?.textContent?.trim() || "";
          const titleText = titleEl?.textContent?.trim() || "";
          if (timeText && titleText) {
            textLines.push(`${timeText} ${titleText}`);
          }
        });
        if (textLines.length >= 2) {
          const parsed = parseTracklistText(textLines.join("\n"), videoDuration);
          if (parsed.length >= 2) {
            return {
              source: "chapters",
              sourceLabel: `Official Chapters (${parsed.length} tracks)`,
              tracks: parsed
            };
          }
        }
      }
      return { source: "none", sourceLabel: "", tracks: [] };
    }
    static extractFromDescription(videoDuration = 0) {
      const descSelectors = [
        "#description-inner",
        "ytd-text-inline-expander#description-inline-expander",
        "#description.ytd-watch-metadata",
        "ytd-expandable-video-description-body-renderer",
        "#description yt-formatted-string"
      ];
      for (const sel of descSelectors) {
        const el = document.querySelector(sel);
        if (el) {
          const text = el.innerText || el.textContent || "";
          if (text) {
            const parsed = parseTracklistText(text, videoDuration);
            if (parsed.length >= 2) {
              return {
                source: "description",
                sourceLabel: `Description (${parsed.length} tracks)`,
                tracks: parsed
              };
            }
          }
        }
      }
      return { source: "none", sourceLabel: "", tracks: [] };
    }
    static extractFromComments(videoDuration = 0) {
      const commentEls = document.querySelectorAll("#comments ytd-comment-thread-renderer #content-text");
      for (let i = 0; i < commentEls.length; i++) {
        const el = commentEls[i];
        const text = el?.innerText || el?.textContent || "";
        if (text) {
          const parsed = parseTracklistText(text, videoDuration);
          if (parsed.length >= 2) {
            return {
              source: "comments",
              sourceLabel: `Comments (${parsed.length} tracks)`,
              tracks: parsed
            };
          }
        }
      }
      return { source: "none", sourceLabel: "", tracks: [] };
    }
  };

  // src/storage/import-export.ts
  var BackupManager = class {
    static async exportBackup() {
      const allData = await StorageManager.getAllData();
      const payload = {
        version: "1.0.0",
        exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
        schemaVersion: 1,
        data: allData
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `trackmark-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      console.log("[TrackMark] Backup exported successfully");
    }
    static async importBackup(file) {
      try {
        const text = await file.text();
        const payload = JSON.parse(text);
        if (!payload || !payload.data || typeof payload.data !== "object") {
          return { success: false, videosCount: 0, message: "Invalid JSON file format" };
        }
        let count = 0;
        for (const videoId of Object.keys(payload.data)) {
          const videoData = payload.data[videoId];
          if (videoData && videoData.videoId && Array.isArray(videoData.tracks)) {
            await StorageManager.saveVideoData(videoData);
            count++;
          }
        }
        return {
          success: true,
          videosCount: count,
          message: `Successfully imported data for ${count} videos!`
        };
      } catch (err) {
        console.error("[TrackMark] Import error:", err);
        return { success: false, videosCount: 0, message: "Failed to parse JSON backup file" };
      }
    }
  };

  // src/ui/logo-asset.ts
  var TM_LOGO_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAACvWUlEQVR4nOydB3xb5dX/PRIgzvKQvLS8bUn3XkneQ3dJnnFiW8t2FiMBStlQSktfVvu2b0tbOt8WWjYt0AGl7A1JGBlAICFhhCReGcyQzUjs8/884w7JzqDlT9I393w+53OvJFuRwL/vc57znOc8SUmGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhhhlmmGGGGWaYYYYZZphhxBinM7mxJZRTJXZ6fUK7x+tv46r4draqMcj6GmTOVy9ylfUSV90Y8HjrRA9XK3LEJc5TJ7GeWon11omst1ZgfXUC46vjmUrsfsZX26RefbVNrLemkfXUNLJcdRPDVhHnkFc3MR7kNU2sp6aJ8RJnfTVNjI9clXvGV9OoeqXi6N+pbWSqapvivLquiamu9zPV9Txb0yCy1Q08W4u8SWDr/SLb4BfYhiaereNld7U/4KzCHnSie+Q1ftlZ45ectbzsrPVLrpom0VndKFZUNYgVvgahorJeqPDV8RW+ep5c63j8XGW94FS8qgH/jrO6UXLWIG+i7pcqav2yzqWKOvRv+SVnnXLfpN5X1Pnlinq/VF7vl8vr+UBZnT9QWs8HSuuIl9VSr/EHyqr9snqt9gfKqpDzwbJKvrnMx7eU+YS2skqhrbxSbC/3Ce3lVVJHRbXU7qySg2xjoKX00SeeSj3Wf5eGfU3GuSsmlXlbL7G65W0OLrjFwQVHHJ7gMHI7FxhxcPKIg5NG7Jy0hbg8Yvcgl0YcHnnY4ZGG0bXAi++HCjzSkMMjxjsnIB92cOIwuUpDduwyvqLH6HfJ6+KQnfiwevWo98Q98Vcbde11Sfcz6F6in1MaLvBIw4VeGXuxVxwu8gjD5bUdg4wY2eQWo5sZMaLzsOqsGB6g95tY5FJ4EydFNrFSBF+xy1HiUmQzJ0c3c3JkM76f2PF76J2TwptZCf9b+B67GNlEH2/ixPBG6u9yYngDJ6n+7niPTOisFFV8I3YxshF9Fo8URf/eiFfsfG7zyEDWsf67NOxrMo5lJxV4g9fku0WwMprbqOvvbeyhXAA7K4IdX+PdxvL4dfXK8GBjBPJ7uqudvs+/4tYJrnpP/Hny2XhwMH6wM01QUt0KLiEMTj6E3YU9jN0tUOdD2j11JuEeu3iI+/+Pzuqu2EXlcYS4GAFG0Dn6Xjz5Tgz2HmCxd4PX37FhcPjt7GP9d2nY12Qcw00u9LVea2EksOgFz5KrnYocicah3HOKCwlXERycgD3utXFQEFRw6EU5ocA53ZUT4x8fAgSHdd3ncnA82Dk/lNS0YRFr4g+BSyDu1jmjXMWwesXPido9o9zrnLwe/5o77jX9cyH6Psq/QR/rgSISkR/eI7prBBjFdeDCV74HGIGIn+W7wNPUvn5o64D5WP9dGvY1Gcdyk4sqW7+fj0UvUfFL1BWhS9SJwO0e5GLc1aFz9bECA/qcnYIBidCK3p8TJnTlZ2yeQ1zR71Mnj3ndc7z6WvzPaD9rxy7gq83DQ0ltGxafIvjEqyJ+JEZ3gsDdCWJnJJ3rn9O95pYmfj4RHGzCverSeOfGXSPAYg/TqwKBsAoCEr0ogEEg6AKO73hjcJsBgBPG3G5mcmFlC44ArIxe+JJupKf3nnh3KBDwihoAvAoQRNU1SIhU3CJ25f0VcStAsWEXxl3V1zjlnl6Vx5z+Ne1nFTho76dBCQGguE4BABmR3VTY2HUidSMRqQKPjHusuFt3n/jal/coES9yOaKKmZWJczonj6O616Lq8wz+vaj2vipcdNGJ0A0cP2vt0NYB07H+uzTsa7IKZ8XkQl/wagsjjlkZJdynzsW7QxW+FCdwJHqHl4ifPEdB4J0AFh5JJ1bqOqjEiz4eOImvKWIef6/7ORUwIlhV8WuAsHsFKKlrp+In7lKEL2nXOCHLOmHLYfJY1r2W6Pj56MSvHcLZhN9jx3lUd40S4QeQR/CVC5Dn8WPdz2oAiKgAIJEFggACQMfaoW2DRgRwolhpWenkIl/wGiuTkNDjpLhR2hEHAL3wE+4THtt1UYAt7l7SiVUncm/Cc176HHX1Z7xU5F79eylC1x5b1UhA1MBD/33yXgIU17dT4UfAjZ0I301H4DixH0rkigeoeGW96GNfTvzSRILXjeqquOk9FT6ne8zpIMBRSBAARFUAuDEEQlj8CgA8fMe6wW1DBgBOFCspLlYBYNVl+gkApITRVzciezVXRns15FdHf0GFgBYNCKoAEyGgjNJW/XNU4Og5q1cDhB3/rOJCHDisun/DyiX+G5L6fgQuAhTXtetGfgIAEsqHtdFS91gfhuuB4KaOhUZdeU6JBFgKBbfOGfX3Dg0UdQRHVzrKK46eU8WuF38gPkpQP5MyVYmLAmgEIHSsHzAAcOJYUWHh5GJf89V4BUBd1iO5AHvcaCnpACDFAUARf9xznvjRX580tMWJV1QFb02MDLya6OOuCb9nT3isvS7FvbcSGajPeyX8nggALt2c362fx+vE655A8IniZxKfC0Tjwn+3EhkExv/sESODBEHrowA9AOIjAwUS1GlUo0Q68bkAAwAnnBU4CmgEIJEaAAUCNOxXkoDjw3VhvPgTE37qKoEy8o8HgG2Cq+0onrcqIb9X/5qQMNrr5/8TTDsoVDAABJr8o+J3U6G7lSmAHInPASTO7+OeRyO/FgFo04HohEKfCBzj8gFx8/7xEGADCfeBhOdVAERplKOPAOiKhtANrDBr/cC2YQMAJ4rZbXYMAKUGwKpf66dXm24akLgScCgnGX96r8DEo1vLpzkG5FZuvLgTAZE4uuvFrI8EJgJGnOg5UY1mSAQgxQNAzQEcJjMvT3DVj7A6ABzNKH80o38cAOiIrgoe5xgmAIE++aeG/zECNTERAiFwiQYATjizWW2Ti7xaDsCaUOwTt2QXl0SjYp9geVB9XhW9VgOgrvFz4oSeCIDxwo//DOPn97I6xz9crsGuA0ARzgGE8EoATgTSaQB7VMt4usTaEaYLh3X0b8pa5HH4aCAaHwHEiT+m5QgUMCREANhFNA3QTwXQ90fFQLPWDb63xQDAiWJWi3VyMVoG1JUCkymAREZmPQgOsTSnCN7h0aYNDp0ra/12XYUgGflpwi9hSdCqC931gh8/x9eN5rrMvpa7kBOigYSf1QOAFv648Eg4UQQQnRAA5Odi6r07ITJQRK2KW9I9ThC/VjdAnNUlHN3jIgHNuYmAkOBMAgDcEwKgBwNgwADAiWMIAEUEAGNKItDKyiQRSFcCbAkiVaODxEiA5gscCcuHiSXDVlZ5L0k3JdCLXQ8GDQTWuHs5Lts/fpSX4twa911kDAd7whTAJeqnAYkFPdpqgAoEMapbKoyo82u9yNVRXP+86vqkYzjOJyowUgt55Oi4KIA8jsWJfRwEFPGrSUA63aE1EAoAjAjgBDJrvmVyoTeAAYATgaxeoONH54keK6XCSFjjiofUunsaBdBKQ602n74XK+rKdZWafy1SiJsm6PYejJ8OxAufiF5Z+lNWMiQaAchg88pQXNeh1v67FACMq+iLD/fdiWBIcFaFiF7U44XuTigBduvLgvVLkfrPoIb2MdUZFQQxbbRPdEX8Uvzor7gTlQPzs9YPbjcAcMKYJS9/cpE3cJUaATCHBkCi6PSjPq4ZwACQ4vYOqD5ut5+ou+oAoEBBvSaCQVc+rH4W+u8lin+c0yVMxVUAtOPRzy2EteXAcREAGfG1UVQX9uvCabXWPmGfgPuwHjrE80p4TpN16meJqZ9jPAT0MIh3t0zE76Kf2YVdiwScOALoNJKAJ5KhCKAIRwDSmEUfAbD6oqCECMCjB4IU76ykAwL9XbXCkAqcEcDKTLxN99C7+0TtMQaFRH6HgsCeIHQlB6AkBe0eDRB2JVmoA4Bb6KGbf7SRm1Vq5tWRXj96KiOo/p46fo/4nYRxzifuNAzTHYg94zYgKa/rwaBNBxQIKMKPHXLu79YBQPkOCgBc8RHAus1bjTqAE8Ys+TgJeA0CgDIFiB+VDx0NaPN4TfTY9fBgle3FOkEj8ev7DDD0OTb+iiBhZXlyZSaKIOKjEHtC0pCIP35aQECg5AAC2Itr28HF92ARKqOxOpKrIX5UdbcY0wk+IZyO6xXQkyD+HgIafiIPjX+OAsGlB4Ggiyz0INDlAfQ5gMTRX3HXISIABICNI8ZegBPGrPlWFAFcY2EmAMAhpgDaVIDuF1BWDZT5PRW4dZzQtSYjeOchI034ur4RiTXxNV2fAmXPAtmcJGOPS1zGiV6BgKxLAgbwNADnAPgeXS1AOA4CblGpndctnwmK08hA+TkhrO7fxw03BNJ0A+27x01F1Hsqcr9y7Qa3nz7266FAf0cHgbhmICLaLRjTQSB+SqDN/7Vpg0uNACJxeQADACegIQAUe4PXWlUA6IR8uBwAq7uyojp1wKO1mwerix+1uvh9Vhe/w+YW33dw8tYCThop4MQhBythL8AuDhMXdFdy71DvheECDvsIuhZyInEPauklDRd5pZFCjzBc4BEGbJywxcaJB9XkH6dPACpAUAAgg92njwCUETYSN/9maEcdVfBC+AAjhrdyYmSIkyIjnBgZ4aTIECeGkQ96xNCgR+jBzhEf4ITuzRyPfRNLfCP1Tay/exPDd29i/N2biXdtxo/57s2M0LOZFXoGWCE0yAihYVYIbWWF0HssH/qQ4UP7UGcf3PUHbxsmMGAnWBHAeYsJpgB6EOAcgDB7/eYtIwYAThTTACCPkX4AWg7AysUn4LT1+/EtwVThO5sO5pc1rCjxyJd4Gzs6fQ2tfl9joJqpbPSWsTVckdPHFLsqmVKXjylxepmiCi9bXOFlC8s9bFG5B18LyzhyLeewF5SxbEEpyzrKOM5ewrKOUpa1lzD46ijluIIyjnOUutkSt8/ZwAdlK8NvwTDiiPCVa3wSkEYAGAAd4MQRQFh1FQRqSE/n9nwIWH/n2+dc+J1AucvLlLm8XKmrkitxVbIlrkqmxFXpVt1d5S5hqt0lTI2rhKl1lrJ1zlKurqKMq68o5erLqVeg5/AVvc7WOUvYWid+7GlwlvmanOVVvMtZLbjdtRLLNQS8XENzVW0wWu+RY12upu573HzoUzIlIBBgElYG2IlWACQNAG4VACEEgHWbtxpJwBPGrCQHoAKARAATAUDJyifmCWjCzi2AxeUHS0X9UFXT7IZ777s7ddLkyV/792npDlnz3fwA/h4chYBS1KQWC8kUADLNAXRo4TYWfESDAH2sdtDhe4DjO1/9+z8fyE9JTv7av5/e3n77naRLr/qZ2SWE73MLoVG8/KibCqi5AClh/q/kAKT45CWqg+DEOesHthpTgBPGKAC+b2Vk0NcBWHUCV5fxlDV5NUsvqtl5i9sP+c7GUZur/u5Hnnk27Vh9n/ZQny3XyQ9aFJjpAcDFrw5oScAOcPrJFIAk3cIJAAjhJpoMztb3AOuf/fL9jz6en5Kccqy+pmpZJ01P9Xf09bmFnl04L4Dn+jF1dYCREgqAJH3oH58IpBHA+o1bjFWAE8as+daTir0EALgxKBW0NWGEn2j9XgUADf/zXY17ucbWaIBvOmZD46zIPFuuUxjMZ2WIjwJEXVGQrCsEUqYApCOwm0+YBuBoQGvMiQDA+GevfOypZ/JSUo59+/wpJ52c9IdfXlfg9HevxM0/JV3CbxwAIglLgDqXohgAnDjnzQ1Dx98U4MmlTx/bcOv/quXnWiYTAEhxEYAqdH0iMGEJTr2ny3hW1v9WQ2t3ybH8PrOjC+w5CACMBgCbfolSqVdQpwH6CCBEha+bAvC6rL5A6+WFrhVPPPVMXmrK1z/Fmchu/+n3U72ByHWkUCmmy/jHdJWLWgmwS4oXv7KUiUDnEee89dbmzUZb8BPF8rLzJisRwHgAHKIqMCE6UAp47JzwUK0QPKaHSnRG59pznDwFgKwCQJkKaFFAYFwOwM1HSL98JeGXeAYAXSrjxK7lTz79bF5qyqRj+VXjzCv2LWSkvk81AMR0YT+pWHRJRPzOuCIg3T0FwLrBdw0AnCiWY86dXOJt/r7VTQHAaFV3VlaX9FP28LOJxT5a8U6RT/7f4qLiYzb/R9YR6SMAUKYArD4RqABA1lw3BdBC//gkoEsHABQBeMSu5U88syQvNfX4AUCRlw8yct/7jNQLjBiLW/fXb0BCYneKMXqNzwO48LkDc97esGXIAMCJYjnmPAIAJQJQdwQmnqQzfu3frpy+QwAwVl7T+n1zVuZJx/L7dET6HLlOYUiJACxsvPitdNOSTZkC+ILaKoBu3o9DZeVed9IPBcCKJ59DADg+pgDInN5alpH63lUBIMbUkJ+R9Jl+OuoLaM4fAWfc82Fg+TlvbxwZNABwoli2CQGghUYASpWeLunH6EJ8Kvr45CBPK/78Bxpbes+trq45psmazkh/YY5TGEYAsLC6wiYu0bWVgJLaWfRUoLAu9I/ErQKQvvkUAFLXqiefW5o/6TgCwI9++AObU4i8yogEAG7qjCrwqA4CdPQXkEe0VQEBA+CddwY2GgA4USzblD+5FANAAqtbKb0VwM7Qc/xYeh9Xx68BAf2MxY288cOW7tNmJ08+tpnxzkhfEQYAGwALnQaQkV/GrlYGciT8t3uDGACkBiCCBaFMAVy6GgDFKQBefmrp8QWAZU/cPbPCH36YEWJjqGIRlycL+v0KEXWrsyr8uO+LlgHD4PLP2fDm5ncMAJwolmuyoAjgGix+7IIOAHrntYM9da9b3X5aA9Dw1unfvIQ71t9ndrSvOMcpjpAIQAaLTvxWtTFIgE4BNAA4KQD0xT/qYzEhByB1v/LUkuMLAFu3LJ/sC8693iXEvnDzdJ+CqJUvk5E+HCf88Y6WObvefeOddQYAThTLM1smFXsCV1tdqJhHAJubitutFz0Pdp341WU/VPqLxO9qgrzyhud//POf5xzr7zM70luS4xRGUASgzwHEhf/qhiACgOK6WeNzADoYuMZFAN2vPLV0ieV4AkBOVk5Kfcvc81xC7FMXFb1biMblMbDI+Yj6nci9BgBcDt00e+Nrb75hAOBEMWuOdVIhK15lceENPNgxBLDzxJH43fGuiN/iakIFQOj6lxvu+tMxTQAimxPtK9FHAKQWgAhePwVQVgBwBKACIKQTvRYeq9WAAlkG9IjdLz99nE0BUpOSkqXZp7e7hOhuNcSPE3j80eYTHX+OipzcTbM2vfrG2mMOcsO+JrPn2icXMMIPLE4/YMcQEFQQ2CYUvx+sLiJ+4o1jBR7ht8f6uyDrivarEQAGQMIUgCz/6aYAeBVgFi4ESqwC1CcFGQUAaC+A2L0KTQGOp1WA1OTkJGn2aRUV/shHSPia0++jF7vSlCRue3I3uJvmgKu+bXDF6jW5x/r7GPY1mT3XllrCSf0ON/+ggxEeKmDFBxUv5MSHkBdxwsNFnPBQEcdjL0TO+h9EXsQ2PVDENjxYytWfcay/SxIBQLGyCmBNBAAn06PCAiT8R1dlGdAfihsV43YG0hJhpXMPJ3avfHrp0rzjKQJAdvY3v5NRKYdvq5LDD1fKkQcq5cg/K+XIP3xS+B8+KfQPr9hzv0fovt8jdN3v4bvu5/g597P+2fez/s772abO+9mG9gddVdKNjy5bnn6sv4thX6P98L9+nHzW6WemLliwOLV//uLUvv5FqXP7z0jt6z0d+aT+3tMm9fcunNTXf/qkubH5k+b3zZ/UH52bOq+3L3V+pCd1brhr0vlnnn7sd8YkJSV14yQgAgCKAAI4CWhTQn9OawaiLAGqhUAKANTwOKICAUOBJyMnjgCErpVPPvfccVUIhKzG7Uq64JvnpFxwzuLUs09fkPKNU09N+capp6csmn9qyqKFi1IWnbo4ZfEZ30hZvOiclMWLz01ZfPYFKWd+46KUxedclHLOBZemnHPJ5alXXnNtytub1h/rr2KYYf+adStTAAoAsgxIAEDOBJS1fQBqIdAsbTcgPxEAQmo3H7wbUOha+egzzxxXpcCGGWZYUlJST0wPAOV8AxT6B7Db9OKnSUAyBVBacGmijwcAaenlJABY9ehTT+enJB/73YCGGWaYzkK9GADDZBlQiQAC6koAmftPBIBQQgSgB0GPCgC8HViY8/JDjz+Rn2oAwLD/6/brm2451h/hSxkBgKhLAso68Wt7AEgNgL4hyKEBgMXvD1EYdAPDz3n1wceesBgRgGH/5+32u/50rD/Cl7Jwb39p/DKgrCX/OCX8D9AqQBoB1CgACKkJP6VFmNaZVxcB8LNfvf+RxwwAGGbY8WYhHQDwFECX/bfrIgCHJ4A9bgqQEAW4VQDopwAoApi9+r6HHrUkJx0XCx+GGWaYYqHeuSW5LpQD0KYABAABtQhIHwU4JqgDSBz9MQD8OgD4Z6++70EEAKNLlWGGHVcWihEAWOheAHXuzwXGi98bxAAoSYgA3Hrx+5UcQA89uAMd4NG5+u8PPGIAwDDDjjcLxfpLcl0iBQDN/utC/8QcAAZATQe4mujRYIlRgF87yUcPgL/982EDAIb951tGekZS92mnTn7ohRfTcvPz0n7z57+mPffK62m/+8uTaUtWrUl78sU1aY8+vzbtkWdeTnvipTfSlq5cndZ12tlpG7a9l9Z96tlpy9e/k/bosy+m3fvI0rS/Pbws7c77nk67/W+Pp/3h1n+kBbsvTGtoWTyV7zhrakvkwqnNkQumdvZeMpXvOG9qffPpU+/6231pl157XVo9U3FSbtZXswEtFJ07IQDsXAIAvCQCKPA1k34ATWQvgFsXASQe5aUCoGnW6r/e/5Dlq/i8U08+JdVsMp2SbcqcYs7KmmLCnok9KzN9SmZG+pSM9BlTMtJnTpk5c8aU9PQZ+DpzxnT1mp4+E7+OfjYzM53+XsYUU2YGfk9zVuaUbJOJeJZpSrY5e0qu2Twlx5w9JcdsnpKXkzMlL9s8JdecNSU3K/MUm8lskO1EsbKS0uTK6vp2RxF7W4Gz9rZiZ91tRc7G2wpc/tvsTv9tNid/m9Up3G5zirdZK/y32sobbrWUVt9iLa691VrScIutnL/V5hRutbvkW21O6VarE11F/JzDLd9uc8t3WJ3CnVan8CerU/iz1cn/Cbndzd9hK6+9I7+k9nZrceXl37zwe6av4vskAsAWt/6vOE0C4ikABQDdDKR0Ak6s/tOmAQQA99z34L8NgIeeeHxqsOeMBfWtc39b29L7u5rmvt/XNPfdgLy2ufeGuhbksRvqW2K/b2jtJd6GPPb7xrZe7Mpj7K2xG+rHefSGurbYjXWtsRtrW6M31uJr7A+1bb1/qGuNIf8j8vq26E0NbdGb6lpCvwif+o18I7o5QazIUZhc7uW/Vcjwo0WsOFrIiqMFjDzqYAKjduRu4jaXPGp3SaN2tzhqd4mjNpeEn7O5AqNWlzxqdZGfsbnlUTt2iTgjY7e5pTE7dhH5qM3Fj9qc/lE7vjZ9Wupu+uGvb7hjyr/7fXAOwC0NW9ggqfzj5PjNP1j4AQqAAAVAhwaACSIAchYAcZe/C1wYAA9Y/h2JrHnr3VShvf8MrqlnNydER1khMsry0VGGj46yfCTOOQF5dJQTo6MeMTrqlRSPqfce5GJEu+J7xaPavRgZ5VQPj3JiaJQTQqMeoQc75+/cMat3YW1y8jE+9siwr8cK7EXJJV75kgJWGi3gZCjkAlDIBaEAezO5skFwsAFwMAH1ameC2G3oil8nVzt6nZVVt+scnQZsZ+mpwLTfgAO7AA5G/LCyaVaX5G/9t/7w4gDA0vJfmgBUkoBI+MoKgD4CUHIACgSU8B9l/t3q6b0EAHfd+89/GQDJKclJ0qz5NR5/6B1OjAEn9AIrxLAzfBRY7BH1yglR4IQIcGIUu0dxKcFF9DOH8zBx1PsPOzoJqAdYvhs45P45wDTN2jE7trAqJSXFAMCJYA6rI6XEG/iWgw2MOXTCL6ReMIE72GZwcC3g4JrBHudBcGAPYBDgebci/gQQ4CO+GREcLPECVhor5uRVQnNPJQD8y98HTwEQALgg2LigWv8fnwjUrwLoAaBvjkGjAL8S/scB4NU///3+fxkAV13765zqQN/9Xql3zCP1Ayf2ASsiCCggiJITf5HoBU3A6OQfDos9ggWP7+UocDK5V68TekRz1P1XJABgeAIAlu8Cju8CV2P7x3P6Tqs0AHCCmC3PmlLqC1xmZ+U4ABR4Ehw972mmAqeC9xDR2z1BsCPRc1T0qpNTeGyJV3r8OOkyLIGDE6GAk6CQk8eKOPmh079xmZ0pLvyXvk8o2l+S65YxAMjoH4yv/+foHgBPEEcCKAlYqs8BTJT8owBQpgDuxo5X7vjLvf/SPPkXN90zvaF1wf/45L5PffJc8CIA6CEgxoAVoxoEqPDRAZ+cqB0Dzsnx7pGP8FwcBHQAEFBlYzd2lp8DzqaOj7vmnl6Zknp4ADy/csW/9P/HsOPMrLmWlFKffJmNkcbQqF3ABSgAgjpXQEAeO5DwPUT4NqWiTu8JEFCP49I/p5wtQF+jAED+RZlH+O1l37t6xr/yfUKR/pI8tzxi5ZrBiqOAwMSrADQHUFDZDKV1CgBCOgjoYdBNHAGgCY2SHS/fevdfvzQAlq7eMInvWHhupdy3E4tfngsoAsBRgNQHnAoACgGRdPdl6D12SedyDLg4j07wOBEEFAAYAiEKgW4MAlbA0c3H3XPPqEw+QgTwi9/8z7/yv8ewr9aS0d9gSnJycmpKampKcsqXL03Nz85NLfXJ344HgE78Xu3q0Lld56iphjLH1lye0MkoLGmHjHAkL4C8gJWgELmb31XBNV553iWXf+mkYA8GQGAYAUAd/blEAKBVAHI8uBIBuPUAECaKBGgEQACw8uY/3ZOfcpQAQIeIPrP8tUl827x+rim8xSv2gk/qx6M/AUAfcFIvcR0E0Ok+yr1b0p37JxNHAGADvZoHe4ELaM4GYsAF4mHA4elDhEQAqNuxSKMADQAfheYvOiIADDvGdseN90wqrWyvsriEb1mc/E/yKprOkToiJZOSJ32p/3HWnLzUUq98OQIAmqc7OAoBD3VvUHVF+Ch5hhppoHZaNgUA3vhMO3LUfMOqF79aj687qJOKH0HBgZwVoZAVoJDxv1/Fz4p0hSLJX+YU3p5IfzEGAKsBQOsDGIiHAF0FKFVXAUITiJ8AgFHrAAgA/njnXXkpR7kX4Jvf/EZSR+zseqax+22OR8m6Xp34yejPSr1xjoSuiN5N77HLBAJuBQJU/Ax1BAHkTJAAgAlQUMjkuHCWTgMmBkA3OP2dH4UWLDYAcDzbBVdflVTZOKs9v5xfb3UF9ltd8hcWl7zPWtH4eEEJY0v5EqfW5mfnpJZhAIhjdpq5RwBweDThF+Jrsyr8OAD4NABgsXuJ2In4JbB6Zezq6O+VtbbcrAYAG04UkrxAAYMAwEMR419V4vS5H3/4zqP+Y+xWAKBEALoVAG1LsDIFkPF30XIA9BRgnfgZFQDdGAIEALNW3nDrnfmpRwmACy7/YZ6nqedB1o+W3GLgEXrBI/ZpoT8GQB8Vfq8meJmI3kWvymGf+NhvFQBU5Drxq66PDlQIRHD4z0hE/KwOAIyoAsBnJAGPY/vlDb+eXsIGHrY4RUBudYlgwy4cKPPwP+7rmnXUQ2auOTu1zCt9GwEAZ+o5GgWoEQASSjOpmqNXJBy7MrJy+hFdxKfxYmdFsNADRvEJvZ74nvxxvfpZzfHKACNAAV4e9I8VMU33dPXGpiUnH137re5wf1GeOzCkASAYNy2xc3oAkKVAlANw6yIARogHAEMjABIFYACsuOHWO/NSkg7/nxn1DHzqpVcn1YiR77FNPQc8fAQ8eEmPhPo43FdHfOqyBgDtGO9IvOtO+sWQkCPABBQwRAkUZAIG9H6s3EunDCQCQGcFktwCgkCPLgroBpd/9kfhBYt9RgRwHNvixRd4bE7hbYuLiB+18bZTL2CEp6tr6o76iO5cc3ZKmVe6zMaIo2QKgEJxMkcuUESiAIAm/VByzYL67rslsLhFsKBDRVw85CvuJJ7nRIeGkANHLIyEXd2gw8naoZ3KwaOM4gI+i8BBziXYW+is++n5l10x82i+T0+4vzDPLScAQAv7bQlTAJwDqNNHAKEJIgANAnQZcPnvb74jLzXp8FB67/0PJvnb5s5lGrq2cKr4Y9o8H8/p6aiPhC8T4aNz+8qFGJTzyKNQ7o9AhT8C5XwEyv1hcuXJtQK5QNxJnZwLgA4HQTDpw65GDCoAyGGnpN05cQQBAoBFBgCOV6urq032VDYvsjiFfRa3DDa3hN3uFsHhxuHzGrZWLjva98szZ6eUeqRvKQAgEYCEARAHARQNINHKCyH3ol9A/oW/BOsFvwDrBdeD5fzrwXLez8Fy7s/Acu5PwXLudZB/7nVgOfcnYEXX864Dy/nXQe55PwFrXRRsqGBI3aarAUA5nFQ7fozH0YDd5d9V5hW/8cLqNSclHUF0XaFeBIDBuCSgMvdPSARiCPiCUBYXAWiiV4CgRAHKXgBXU+eK/73p1rxJh4lK1m94O6V73gWyu6HrXdYfBjT3x+IXaIKPJvncVPwu5FIUysUYFIYugpIrb4bSq2+G4qtvgoKrbwbH1beA4yrN7eh69a2qF2C/GQqvvhmKrrkZCq69GezX/hHs378JCi/+JU0eRon4dQBwixR6dBqAABBaeKbPqAQ8Tq2tvTWtiA38yupCh3lS8TMSqqTDXsBJI+66tvqjfb+87JyUMq98qY0VR3HTDF1CTmucQbPmrAS5fZdD1tMbIOfZAch9dhBfs58bBPNzw2BeOgLmZVsh+/ltkP38dsh+4T3IfvF9MC3/AEyrPoCM1z4Ey0/uBQvXqRYKkSgATRfItCEuEmAFUijEiFDIiJuDbT1tmzdvPuwfZne4rzDPJQ2iJCBeBvQEx61M2D30u+FVgPgpAHPIKQC5VwDwuz/ekj/pMB2BfvDTPxT5/JGlHB8Z4+jIz44TfwxcyOUYOKUolAlRKO44GywPrwPrxs/B/u7nkP/uZ5C74TPI3vA5mDd8AVnvEM985wBkbqD+7gHIQL7xAGRsOgAZmw/CzIEDMH3wAEzfchBsL23BUQaa/+OjwvFx4eSsQ2Xk10cAoQUIAEYEcFzaxd+5Kr+ICyzHZbaMTMSPltCQ+BmcQf+kXu6ZdbTvZ82xpZR5A5fYWHnURrvoakU82l56JH4rI4Np/lWQ/swGyHx+EExLByFryRBkLR2GzKUjkLlsK2Q8vw0yX9wOGS+9B5nLP4CslR9C1qqPwPTyDshYuxtmrtkJlkt+D1Z3M9gYcnSXhRVVV6MAWjKMvxsrQyErjxW7m1bPXXS+O/Uwy539fYuL8l3ioBUDJqirT9AKghzqZqAAjQA61fk/Kr5BR2orZwGyiuMyWlSZFwK2adbKu+65N/+kSRMnWy/73nXmSj50i0dAdfq9OOuvAIDRn8YrRqBCjIBTikC5EIZisRccv38c8gYPQP7QQcgbOgA5Qwcge+ggmAdHIWtwFDIHRiFj4CCkDyCRaz5j8CAR/NBB7DOGD8K0kVGYug0gc/k2YAPzgQuQlQA3hYBLJCBQTg0mU4KuD8MLz/YeqRBIb6hy877770n54203pr7/3nsGOP5/Wqz3rLICVt5ExC/jpFkBowGggOU/Z+vbzgoGOo7qf0S+2ZJS6pUvtrFSHAAcdO1cTdghgTISmOdeDTOfeRfSlw6CackwmJeMgHnpVjAt2wZZz2+HzBffg6yX3sfiz1zxEWSu/AgyV30MWS/vANOrOyFz3V7IeH4I8ju+CRYXETkWPxMfBVgZmhSkqxJF2OXR8kr5r3nZuYfMB/T3n1mU7xaG4gDgTdgLoOY2SCmwAgCGAoDVA4Des0o5Lhopm2at/NPdf88/efJ4AKx4fV1qU+u8Kzg+8hla30fi99CEHyMox3RHsfiR8CvEMJQLISjhQ1Bw7k/BuulzyB4eBfMQ9eExyBoeg8xhgPRhgJlDY9hnDI3CzMFRmEF9OgbAQZg+PIqFjzxt6xhM2QYw48X3gQ0uAA9KFOLEYISsAuBEIhG/W6LPCXM+DC04y5OSmnrEv5+Hnng0+ZwLv1sgtM9fXCnPvc4XmP/r2mD0km9955qSP/35rqP58zPsyxg6/80fjNY5GOljmwIAPEKKKgAcLD9W5pN+dfUPf552NO+Za8pLLvUGLrbiCCBApwDxjTRxmE4BYOq/CmY+vQnSlw5D1nNE/Oal28H0/PuQ9cL7kPnih5D10keQteJjyFq5A0yrPiH+8k4wv7ITTKt3wYzVH4H5rucgr7obJxCtjBgXBahlwhhCAVqbIEORB0UC0n5ndfPi5RvfmvAg0ljf4uJ8Fz9kZcnv2icoTIqvAwjGAYBRR8KECEAI49EfJwIbO1be/bd/jAPAkuefTu4//VvNlVJsi0/uB6/cB168zBejVX0RCgAqfikE5UIPlPi7oajnfHAs3w45Qwcha3gUTENjYELiHwHIHAHIGKEAGAaYMUR9cAz79MExmDY4CtOGRmHa8BhMHSGethUwAKa98B54EABkbaWAUaOAsDodoAD4oGf+mdyRADA8MpC08OzLCyv5yIMePrrLI8QO+sTYqEeI7Pf659z6o5//NuPL/XV/9fbk0qeO9Uf4am3ySScl1/A9c+2M9Jl+d51DFT9NnDlrH/3l//7xqA54zMnKTS7xBi7CAND3z9Mt01koAPLdImT1XwkzntoI6UuGwbRkCxa/+fn3wfTCB5D1wkeQ9dLHkLV8B2St+ARMK3eCadUuMK/aCeaXd0E29p14OjB9xRbI+99/QJ53Fl7FQHN+C6cd5a2VDgcoBGQMgQL8fYUt7mo59jHAuLlAT+yMotyKpqF8t7bsaNWtANhoLYK+JwBOAtKEH6sKn87/hZC6aYYsAc4BZ33rirv/fn8cAMbGxpIDoUVlPiG8yivFwBcgAPAoAJCI6PTirxBDUOKfA4UdZ0LBM4OQOzAKWUPIkfgBiz9rC0AG9fQR4nEQGAKYjn0MpiEfBpg6ApA2AjBFAcDz28EbWABevEQYpRGAAoAQdrdSFMRjALCpRwDAL35729RKf+R61h89QPYtRPEuQw/6b8d376gS5rSnT51qTAe+ShsYGU71NHRcYXeLB7D4qRewRPwoY47dVbfh/Eu/60pNPXI5QG4WjgAusuIpgL6L7sQAyOy/EqY/tQFmorn/EjL6Zy/7AMzPfwimFz6GrBd3QNbyT8C0YieYVu6C7FW7IXvVLuw52HdC9sodkPnyhzBjxTDkXvYbyGeaSdKPHt+lHOEdt4GHTkvQngEHWk6saHibqfJLV3xnYdwfWXfsjMLs0vqhnAoe8hlBXWrUTgaW1fdWAYBLgWnGXwiriUBGXQbsxiXAzoZOKK/rgPKa4PK//OOf+SfrcgCz555r5Zq67vWIkYM+qRdQBOBBpb20Lp/Rre07pTAGQCnfBYV8GApuXwa5mw+CaZAAAI/+VPyZivi3AMwcAZiRGAWoAACYhlwHgFMoAKY+v51GABGSA4gDQFiNAlAE4ObnvN8170z2SBFAqP/8AqYp9AZDE5tk9yKJkli++2C1HP5pT0/olH/rD96wePvH3Y+dUuxuutdO6/bJ9loJh8sOWkCDQFDANO70t/U0Hs3egFxTXkqxN3CJlZFGcRddVhO+Ve+sCHmMRADw5DuQvmQIzEu2QjaKAJZ9AKbnP4LMFz6GzJc+gczlOyFr5S7sOAJYiaIABQI7IXvVDshe+RFkrP4QMpdsAEvft8HCkO9jo0JVw3RODwEa8aDP6BLGbBWND8+JzLd/un+/+n1mh08tMJfUDprLGiCnognnFtR6AxUCkroSgEqbSxUA4GO/NPErOwGR+CvqO6G8th3KatqgrFJacd8DD+ZPoQC48fZ7T66WItd6xfCnaPRHtf5I/AoAWDmmlvGiqj6nHMGhfxGa9//3nyF/4xdgGjwImYOjYBocA9MQQBaNAHD4j8S/BWDGCMD0EYBpI0To04Y0nz4IMG0QJo4Alm4DT3ChCgAlB4Dm/8ror0QACADd885kjhQB+NvmV7F8dHvc5iWlxwDfM8Y2zLr/N7f9bfpX8XdvGLXOrgVWh8u/jogfNebQA4CM/gUIAKx/H1Mb6DiaRE4eAoBH1gCgr9DTgcDCEQBkzP0vmPnk2yoATEu2Q9ay9yHjhY8g/aUdMHPlTpixahfMfHk3ZKzaBZmrduFIAEEge+UuGg18AjmrPobslz+G9Nc+AtPj68DWshg3FFHqDmz01B4cuidsJVaAZ3fxnxdW1Nz+zUu+qyYFW7vnFZiKqgdNpfVgKq2DXGcTWVlQIaDbDETPBSit68DLgKQeXhfy42W/HnA2zIZSKv7S6lYo9QovP/DgY5ZTTjk56d6nXkxtD5+xkGvq/sgrRQADAG/siWmhvxyj4qcAEENQKoTAce7PwPbu52AeHMPZfRP2McgaHIOsISCJvxEi/ulbAaZtBTKvR76FiHwqEvwQFf/QBADYDjBtyVbwNMcDwE0BoC4HijQJyM95b87cxe7USYePHr1Nc1o9YnSHuksR9y5A4X8IRQFjnH/OS4svvPKrafRoGLHO0MLWIi74PhZJQgRgZ+MA8JmrRu47GgDkm/NTijzyRXoAKFt4lfJdZa1eBcATb0HmkkEwL9kCpqXbIev5DyDjxQ9g5oqPYPrLO2DGqzth5updkPnabkh/ZRcGgWkFhQCeEuyE7Jd3QPYrOyD7tZ2QufYTyLnrBbDVx/BWY7QPAW0yUsuNdaXG2GkTEVwk5Gz6pNzLn3XzX+7BVTnB2fMKsoqqh0wldWAqqQVzWR3kufwkuajkFRIOCC2r7QDG360CgFEB0A3Opjk47C9VxF/VDCVc0yt33nmXJdzblxxeeG4t0zB7jVcIgw+LPwYeLP4onfeTkd8diIErEAOnjNb7Q+CYfS5YVnyAM/5oeS+LAiAL+xhkDNJQH4kfiXg7QNrwGKQNjcKUoYMwZfAgvsdiVwCgh8AWXQSAAXAqAUBAA0BcElBSpgCz35s9d7HzSADwNM2Z75ViexHkGLV5CckBYJdCG7v7v3HUBWmGHcG27n47SWyJnVfIBfahklyt9ZYGADudAjhY/4HyKvHy5JQjzwHysy3JRR75Qgsj6iIAXY0/PVIb5QHyWAky5v0XpD/5JmQuGYDsJSNgWrYdzI9tBtMP/gKZV90OWdfeAVlX3w45V90O+Te/CDNeRQDYCVkrFAjQnMArOyHn1Z2Qu3on5KzdBZnrPoGcn/0NrJVz1H4D6u5CGvoT8euiANRIhBXA5mzYWlMvtY58uCNZbJ9fkFVcN5RVUosBYCpFEKiHXDdPIKDfFeglHg+AHrVRBkr6odC/rLYdSigASlD/AI9/9S9/+WvLwrO+Zfc0zFrmFUJjPikKXlkTP6fbvINHf0X8YgSKWk4H6/1rIBdl+YfGcOifRcWPIoH0AZTdJyM5WsefNnIQch5aD7brH4D83zwIub99AMy/vh/ybnoKZr71KUwZpuIfoAAYoQDYRiOA57aBp+W0OACQHIA+AqCrAPzs7bP7FzlTJx2+4pLzd3/XK/V+jqMcpWsRFT+6eqXQB+3hRfJXqYET2t56c1mKr6Hth4We4BdohHTQzLhd7ayDIgAeLQOCg+NHK6rl306fmnbELKA115oAAC1JpkQBFrwUKAI6bSd9/lUw84k3wbRkEHKWjkDOC9sh++6Xoai6k24UasaRicXJg6UqBNMeeBPSX94NmSgfsHw3BcBuyHllN+Ss3gW5r+2EvDW7wLx+D2Ss/RjyLvol2Dyz6Bp+M1iVXXw0D0FGcVF1BAG7mx+zldUs6etfUNrWiSKA2qEsHAEQN5fWQk55A+S7Bfr9lGPCAxoA+C68GYalEEC7/1DoX143C4f/pTXtGADFlc1Q7BFWn33upeU1/tk/8/LdXyDx+2Q6+tM996TmnmzWUcRfLkagWJoL9hufhVyU7UdzfBTux4l/FGYMjEHaMBnBp24dg4xH1gMT+w54Zi0GT8dp4GubD1ywF9yhiyBr9cdwClr6Q8uBAzQhiHIEFACnvAcw9dmt4G09nQJAqwNQAKBMBRgJ5QBmb+/sX1Qx6QgAqG/r/6VHio3GTwEUD4NHDO1vau+7+KvUwAltf73nz9OcVW13k448egBIWPw2CgA7dv9YqVf482NPPn7EfcHWHGtyISdfRACghfwaAGQsQisGQQAyFiAArAfTkgEVAFl3vEA7BRFR4RN5GQHyyhsho/tSmLZ0O2Ss3A1ZKxEA9kD2y3sg55U9kLt6D+S+thtyX98NuWv3QNZbeyFr1Vaw9n8P7J523H5M7Sug20Fo1+UnSGJQQKsCBxwVtXc3NYeqTEU1A4r4UQSAvayOJAVxFKCtBqArEjje7ksBgK449K+fheGAXi+pboMSDIAWKPYFBrxNc37h8Xft9OLRDs39o7RPX0TdcIN36gXIdt5yMQylQhRs370FJ/3MwwCZQ2i+D3jOj0CQMUhGfhTSowz+KdvGIPOV98E1/ypgWxYC2zofuNZ54GntB09LH7gjF8KM1R/AlJGDhwQAigCmPrMFvK1nYDjpk4DKMqAWAYRwBDCrd1HFpMmHBsCdt/9hkk8M/01tXIKWAXHrMgIC1JzUK4bHfFL33fNOW3x02zgNO7z98L9/ZC3yBJba6V59nANA6/U0HCY19MoGGv9YAdPw1O9u+s0Rs7D2fEdKISddlO8W4qcAHm3fvpWKxeIJQMbCqyH9ifVgxgAYhpwXtkHGrUsBLSGin7d4ZMj3yJCHcgauJsgua4DM/7odMlbthsxVe8GEAbAXcl/dC7mr90Lua3shd80eyFu7B/JQleBbeyDn0bVgF08FG23qQaYg8SsUcY4iIIYHq7NhV1553b2mouodJPyvw56FnUAAJQXxygCa2tBoAAPA34UbYiB3+/Xi74CS2nYorm7DXlLVChW1HaMevucAFr8Yod14w1T8YQIAmQjfJaM1/zCU8GGwxb4Nttc/gWwU9qviByp+gJl0Do8SfCej0P+dPVB2xS3ANC8ApmUeOFvmgat1Hrhb5wLb0geuyIWQ+dqHMGXkAExD8Bigy4IKAFDeAE0BxgEgSnMAaPQP6XIAJAKY1YcAcOix46JLLzf75N6XUAejxBZmSgNTj4TA2PPKrNjpeV+1Fk5I6+yM1DpYcZAUxcRHAGQ3Hd1B5/Zjd7gb3ph36llH7KxpsxakFHAiBoCFlXQAkHTdfAIUAEHIWHgNpD++DszPbYbcZcOQg2r/b3oO1/Wj38fi90iQj3IGbgFyyxsgh2mBjD8uhfRVeyDz5b1gemUf5Ly6D3JX74Pc1/dB7pp9kLt2L4ZAzrq9kL72E7Dd8DBYa8NgZej2Y08AQ0BfLGTVJSiVbcQWV9NoTnn9WHZpHZhL6nQQqMVuphAgfQoI3BAAcGdc1BvPPwcqGmZBWR0Rfymd/xeh0b+qDcpqOoD1d4NHCKFRDjxKq20xrBN/BI/8OPyXIlCGlvtmfQNsz23CoX/msAIA4hlDAOlIuMMAaVvQyI9G8i+g6HePA9NyOrgDfeBsngvO5n5wtswFV3MfuJv7oCJ8AWS98iGkDR/AlYAzae5AAUDaOABE8H4APQDcOAII0dJgGgH0LaqYfBgALPrmZU5OiG7gdC3LGAoBZQqA/nt4xe6h7nnf5L5qLZxwlpw8OdlVKc9zMNJBEv4HSSNOJTmmH/0xAJrA7q7b0ijOFo/03gWOEgSASyw4AqDCwmF3QAWA1auM7hQAj62DnOc2Q97SIchdthVMNz5NASAS4XMS5LMS5DEoCuAht6wezNUhSP/7G5C5ej+YXtsPOasJAPJeJ44gkLeWRAOmdXtg5msfgu3a28DKdZBNQ1yAQIAmJMm+AZIXUK7atmIBcp2NYC5VAIDEXwNZJTUqBNDKAFkWDOAkH4dCfyT++na83q/M+5H40chfVNUKpdVtRPxU+ET8IVL8ooooggttFEe1/kViP1jvXo439mQiAFDxm9DoT8WPCnwU0c7YOgql974M3o7FZAkx2IfdFezHEHA394I7GIOy0AWQ+fIHMHUI7fwjAEBRhP690t4jAPBRAMRPAUJfGgAoN9AZPjXgFqIfkS7GvRQAummASIqCPGLPTqFzbsuR8gmGHcHyc80nMXXt1+PlP08wPgJQQ2ACABwBME3gcNd/IrWHFh7pvUtLXKkOj/htKyOMqiNrYm8/3PdPBos3CJkLr4UMDIBNkL90EHKXDoP5d0/gnYKo8i4fFQwhECAAoHu3CPmuJsgpq4OsrstgxvMfgHnNZ2B+fT/kvrYf8pCj+zX71Ugg9429kPHmHsh4ZSs4TrsKLG56yIcCAA+JNtQdhIr4Oa3QB3UjyqlowGG/iY7+BAAUAuV1kO/m8c+jZT4EACT+sto2suRX04bn/Uj8hVVo7t8GrobZeOTHohdDKgBYUQMAFn4gAi45jCv+8Lz/ilsgb/PnkDV0EDJQ8m+QhP9I/Bm0sg8JFmX8Z2wDsK3cBr4FV4CnuQ/Y5j5ggnPBjZJ+CAJo9A+SZcXS7vMhfeV2mDZ0AG8IStcBAEUBadt0AGg7XAQQ1gAgIAAsrjjppIkBkJp6cnJTS+8CRoh+wcp9tKlJVBO+cn4B/m/Tc8Df3nf2KSelfflutYZpduftv5laUd3+QKGXtubGAKDVcUoOQGmi4aYQcDd8UelvvXbdO6sPWwvgcnKTCjjpCgsjjKpzf6UIx6sAIIABYPU2Q9bC70PGo29A7rMbIX/JAOQ9NwQ5v3kMrG4ZC0oFAEMgkI83EQmQ72qEnHIeTOf/Hu8TyF77KeSsoRBAAFB8zV6cEMxetwfS39oF2Y+/Drb2s8DiJmf9oUSkfipgVSBA246hCj/SskyCfMYP2eX1JAmIlwVrVAig59BrCBRlde3gbpoNZbWtUFbTCqU1rVBc3QLFVa1QVNUCRZUtUIEgQUd7DQDkyiLhoNEUzall4hW42CcMjlOvgbzXd4AJiX/wIF7zN9FCHxz6I7FuIUU+aL0/d90uqLr0d+BrWwhsCxrt5wIT7FcBgB3VFMgRDICZy7fC1MEvYAbeIjwBALYrEcAivBtQWwY8JADem9W32HkoAExKTk2tlCIXcWJsDPcYkGKqay3MaVGQ0A21gdCPfvyTn024ccuwo7Trr/tJVpEnuLyAFsloEYCUAAAifrwa4G6CUi9/49kXX3bYpUBfbcPkAo98rZUVx+xx4pc1CNDHBADXQuYjBAAWNA14dgByfvUwoO5E+QxPowASCeCcABUpCsvznU2Q6wxC1g/vg3wa9ue8tg/ysCsA2Ac5CABv7AYzigLe2gmWvy4Da30M/xsKBKwUAhZapWjTNflw0PV9FBGg6AOF/CZ19CeOlgazy2rxVKGkqhkq6tpV8aPHxVXNUFTZDEWoZVh1K44QlPn++JE/RMJpKn4nqvMXesAx6xtgfWkrmAcPQCYVv5LxV0b/GVT8qNAna+QgMD+7HyrbTweudS4wLXPB3dyPAcDQTr8IBEyAJBfLe86HGS9tgakDn2MAZAyMQTotIJpOawgIAEbA17YIvIGEJKColAKH1CahDI8B4DrppIk1e3LqSZOrAr3X4gQgamSqSwK61XMMIrQsuAfYhvbH/vrEkqNq53ZCWCptcZ2clJrU3dqQEvBXJSuPD2Wh6KmlRZ7AgHJyD97Eou7Z13IANrIESHrpMX4o8vB/kVs7px7u80hzojMLvYE/4802Hm3kV/r923VluQgAJgSAh9dC7jPvggVNA54ZgJxfPqQBgBVUxyE6BoCynZj0CcyqiULmPashZ/VeyH59H84H5KGcwGv7IOf1fZC9Zi+Y1+4mEHhrD2S9+RHk/egOyPfMIn0IUZ2BLh+glvjiLr/UvRLYvWhqwNN8AJ0CUDeV1mAA5JTXQ4FHgnJU44/Ej0d+JH7SDbnYGwS2qQuP9h7dyI+coeJn5DAVfwhcUg+UoU0+Qh9Y73wRcjcT8WcqDT0GSQIQjf5YqFT8mdsACv+xBiq7zgVf63xgEQDQfD/QH9fpF7X+VpKL5d3nw4wXhiFt82cUAGgaQFcChgkApm4HmP70MIkA5ENFACHaKRhHAO93IACcfPKEfy8zpk6dUhXo/wOrAEA5q0CMqeJndNunOX/ngNC5wH6kysITxvKnzUia3TO/sNQTvLjI13Fdsbf5+1X1waarfnh96qGSJVJrT8DByjvUnv10a6y6CsBoALApzTQZHgrZpkelltmHbBCKur51hxc67Zzwrn53HDnwQzcNwI9RDqAZTAuugayH10DuMxsg/7lNkPfMpjgAWLDwBTUs1zL2tFOwm4fcCj+kt5wDmY+8jZcCc17fi2GAIgECgb1gXrOHQGDtLjCt3w0Zr78Hlm//GvKZFtwKDUcAurMH7HEAkDAAMAQ8AoFART2GgImKn1QIomlAHS4rLqtugZKqFjz6Y/H7Alj87sZOPPpzYg8RPp0CMNL4kd8l90A5PwcK/SGw/PQ+yN/0OZh0oz+CAFrrV+b9yiidvg0gb/l24OZfBZ6WeXitn1FG/kAfFb/SApx09EHFOxU9F8D0ZYOQtulTmL75AKRvpnkABQBbSQQw/SkdANQkIPnsjLoRSE0Cvt/Ru9h98iEAYHMUzfDJ/Y+z6lkGSPi9GACkq5DWTAUDgJ+z29/eFzr5CE1GU1NSklOTU5JTk77cuRb/UQYwmrTwzHOtpb7g34u4wBdFHlRVFoRiRlhXXd/cFqivmfDLe+sC59kZ6VO8BEgP78ARAOmYM6YXP6kD4MHO8lDA8avqxTbHoT6P1V6YXOVvj9k58VO7lyQY9Sf+2H0kErAqAPAFMQBMDxEAWJ7dCHlPb4TcOACIOvGL2oYiD4lUCAQEMDllmBG7ErKfHobcV/dAzmt7MAzyKABwFIAhsAt7+puopHgYrP1XgMUVwElHJQpQpy109Ld79QBAnwE1HfFDTgXJB5hLa+MAgKZQStiPKv0QAIq8QXDWk+QgJ3STKQAFAasHgKzN+51iNxQ3zQHbBb8Ay7v7IQeJfwA5iQAwAFBHHyp+FPrP2A5gensvOM+5HtiWBcC2oNC/Hy/zsUG9+KNE/DR8RzX8ztCFMH1pPABm6gGwjeQBpj81BF6aA1CSgErOYtwqgDD7g47excwpp5wy4d/i1T+4LouToqtJ2N8btwzoViIADAGyqYrjuz5vau275vEHH54wBHjowX8mXfSd/06XuhY3yt1ndsrdZ3kefWrlv31M/HFp137vW2lOj/TbQq758yJvCxAANEORJzBWwor/vO1v94zr4nPLT36aXMz4b0Un92Dhs1r472DlMTsrvmZnhB3aFICnJcECFHmEdzt7z2AO9XlGv9iX6q5rvszuCRxwKCsMdPTHh3/QeyUCQCBQAfD0O5D/7LsqANB6PR75UYNP5WwAT2LRjkiX7URcI5DpDELGhTdA7vPvUwhoxUEqBNbuBvMbu/HS4Iy3d0P202+BVTwdrAwtEvJqSUq7V8kBUPHTaQCCgJ1D7cmbsOA1ANThx+i/HarxL0bCp+IvQ/N+vouIngKAxT30e+LEjzL+yNG8v4TvAmvn2WBZ9T7kDH4BWQMHIGvgIHZF/Om6Qh0k/ozBz6H4v/+KK/24ln5gcNKvD7siftLLD/X+j5C9BbRwxxW+GKYtG4ApG/fDNB0AcC3AMNk5iAAw7akhugyonwKE4pYC1QgAAaBvMTPllCnjAJCSnJIU7T+znOXDw4wy95di6tmFuOMR6qmo6w3ACaEDlUL3zetefX5cSPHiSy8lnXnu5ab6YN8tdS3zPqxtmb+rJti/pdI/5+o5kYXpX43qjhND//HcvoCryNP6VoGnBQqxI/EHcRRQ6pHW9Z1+SUni751z5pmZBYy4hOyDJyf34K69+BANabfV5T/T5uZXoWVAFOpqAEANQvkt0uy+2kN9pg8H1k4u8Uo32D3BUU38QdovL6ABwEeuFgoA80OvQx4GwAYMgDwMgCAtrpF0ABC1HXwcOQjUSu8xBFx+SGc7YObPH4Hc5TsgF00FXiOejXMB+8C8di+Y3tiD9wqgUuGZ7+wB+53LwFbbC3auhR5NppxOJFPR610DAIqK0GpEdhmBAAIAcpubh2JfEIqol1S24JoAbfTX7RGgAHDHLflFoEzsgYLAPLD841XIHzxAQv/NB8C0mQAAhf7pyho92tePQv+RUXDc+gKw7YuBC/YDi8P+PnLSDz3ai6WZewwAWevoixt5hC/GEcCUTZ/C1M0HYKYKgDFtCkAjAAUAnKyLAMSQCgBSxBTCLcFQBDARACZPnpzc2nNGJytEd5Ly33gnAAjTJGBI2Rw0xjbNfvLGG/8wrkXYXXffN0lom3tJldy3tyrQB1VyL1RJyCO72NrggpSU/0P1A3f86Y4UnxhbXMC1fI4AgDL6hZ4gBQCabwbe41v7OxN/78xFZ3sKWGmj0gjDTk/Pwd2AXPw7wc6I01rRsARvjWWV3YAi7hJUyAm7KvnOzpMOUdTxnXOvmO5gxSV2T3BML3wEAhs9/ks5AgxNB6y+ZjBjAKzBALBQAOT/6mHc6x+391a7+ojj3K7eCwQCjIDr82fWzYWsO1dA3qt7wPzaHsjWQcC8dh+Y39iLIwDzm3shc8OnkPXOLrD/6C6wVXaDw9MCdm8z2HwB9dxBvfgdHgIAckUnFaGkYAMO/zEESuvA4vLjhF+RtxmKfc3gapgFHN+tih8DQOzG4ncjV0J/OvpXiD1QJPWC9bePQv7mz8E8RESviB9NAdIHyRIdEiYK/WduHQPLU+8C23MxcMG5qvjJAZ9kvq9k7BXx6wGAPXIJTF86AKfQCGDmplEMAQSAaXE5gMEJIgBlFyBJZiLxY0cA6FvETJkyHgCb312VKsxacImbj+yfEAC0ozKrWy1B7hW6Xq9vDBQlvl+gY76jWu5dVRnoB5/ci7dTV4pR8AnhscqmzgfOv/yaf+mE6OPSrr32+mwHIy21MWgJrxkv5RUi95COt8Ue+QtnZeDH0fC8uLmSHGhrsbPye3b91l8G74CDQrf/sb5ox1RrWc0DDkYYc9B98gUcEj+6Cgd9TR0XlBYWTTj/qmrs9NkYabNNF/47PAFdDiABAJXNYF5IIoB8BQDPvAv5v34Ej8a4vh5vsBkvfDwC63bxEQgIeGXAjJKCreeB6dENkLN6D5gQBHBycD9kr9kP5jf2g2ndPjCt3wumt/dD5ubPIfOd3WC/6Nd45yCBQICeS0j/fSR4BQBqJKCAhyYFS0i5sMXZRGDsbcbr/ay/C4vewyujP9koRAAQIp10MABoay8xArbv3YyTfubhgyTph3b3bT5IW3iTHX6ozh9t8UWZf9Oaj8E9/0rAxTQo2YcAECDhPqcc5EkTdqyky9orAED30UsnBABuEjqkmwI8SQDgTUwCThgB4ByAe8op46fh299dfXKV2HOTm48c0DYAKZuAKAAEklBkRXVTEPjEno+Etti4VvWB7jNDVYG5n/jkPkBt1HAzFSGCAAA+vntnVb3cNSnlyD0t/iOsXgo1WF3SR3a2GRws2cyDMvqFpN01AgCU+wLPBjp61Wae3Z0tyfVC2/wCT2APmfMr+/5RN5ymsTKm4YaMjJmp1vKaH9sZ/iBuB4ZDfwIAtDW4olL82dDQlnGLuq+sWJlUGwydZWflPcoSoLIMaFMSgFj4zWCrRO2zNQBkIwA88w5Yn90A+Wg58DePgt3TousfoIlcE79271CmARxPioTcfsgq5yHzrJ+D+fltYH51F5he34OrBbPXfArmtRQC6/eD6a19YNrwGaQPH4Cs19+DvM4Lwca1kiYinngA2Gj475ggKajkA9CqADrGDAGgrLoNGP9sXdivuTL6uygAnHTJDxf7zP0eWN74BLJHDkLmMM34DxDxz1TEj3b50Yq/jIEDUHrVHXgZDR/jrYT9AeUY74gGAHqSrzrt0AGAQQBYNgAnJ0YAAxMDAE8BEpKAjBoBEACw4pz322OL3FOmjG8q/ehf7pnm4XuecQuJlX8YAKOsED5AogAUAUQpACIIAGPVUvd3pupWFlKTU5Ka2k+90Cf3f4E6KHnFGPjEGPl5tMmK74Eqf+f1siBOvBzxn2TvvL4qyVXT9h0bE/gCtb0iTjL6+NAL2vK61CMNBDvnVSq/190mTfY0zrrSwQVG7fTobIdS9uts+Iyp9F988iknJRcyjQvsjP8zMvpL2AvxVYBitvHeNW+9NS3xM/39r3edUlYZ/J2Nkw+q4qcAwPN/nwYBW2Uz2CsDYKtswQDIwRHA2xgAaCXA8tvHwOFtTei5pxe+zlkhLgqwsiQsz3M2gcndDNlX3wE5z28H86u7wYRyAGs+hey1n4H5jU/BvO5TMGMI7Iesdz+DmcMHIHfp22AR5uP9AnZ1E5OkwsiumxI4PLQ2gE4FUD4ATQMsTj+UVrWCu3E2Df17SNKPHpnN0bk/Gf1DOOHnFHuglO8GR+d5kL9sGLLRyD+kX+8ne/tnDhLxT6VdemYOj0LBnS8CGzyVVNAliB+F+xwd9fHIr7QpV0qN9QCIfUsFwFR9BDBAOgSrbcF1EQA3bhlwPAA6ehe50tLGA2BO99xspql7ldIBCB8xTnsAeMTIACdG7mOE0GeMcogKBQCKAqrl8J9r63j1Tc+7+JLJ9a0LfqEcnOIRo+BF0BAigHdZos1WjZ1rLv7Wdx1JSUd/2vVxaVdc/RO73ckvI333mycAABFsESfu9DXN6jh5MoFeuZOZUewN3qJU/Tlo919c6ltRt7u6TuhJTpmc7G/pEh2Mf0cBRwHgIe9XiEY/d8Nrv7vjL5njPtP3rrTYXP4laDsxfn8VAEEdAKijCAABoKoFsk+9FgPA8szbYFMA8LsnoMDXRkSHwnCvHgATgUCfExDoMh0KyxvB7J0N2b99BPJf+hBy8CrAp5D9xmfYzes+A/P6T8H05n7sGAIDn0L+LU+AlW0Hu5v0B7CqkUg8AOwqmNC/y+OlQTQVQKsnrvpOYPkude6Phc/rxU9GfyL+blzsU8RHIfdPKyF38AAWPSrEIZV+pOAnHffsJz370mhTz9zHNoC7/WxSPBPo1cQfICO/In5la3EcAOL27keAjV2G6wAIAA6OB8AWbRWgEgFAXQaMaMt+dBqg5gDEOe+3xc5wTZ06bsxICrRHizg+tI5s9qFzfdoBqFIMLe899bwOhu95j42bAqBeCWHwCT3LLr3y+nzlvX76qxvMPjH2iEeMAXJ0fJpHBQCKAiLoPfc3BXuuuOPPt//nZgN/8MP/SWkKhM9wsIF9aJ6sAUBWAUBGbAQC8aC3sf3CH33/Sjxnd1WLtmJf8PUCj7bujyGACn0q6j6sbww0nHJKWtLsOf3lhSy/XgWAPgpgGreET7swP/FzzZ4TctkYfp1NOXzDo8/+B/DobzsUAB5+HSxPEwBYn90I1t8/CYWV7Vj44wFAR33atITci7Sll6SLBHiwuNFafSNkB88A8z9Wg3X1bshGo/4bn0L2us/BjHy9BgHzm/sh/Z1PYcaGnWA798eQ76QJUgwiDQR2r0Q/k9ZNCP17CABo+oEy/2zTHLzsp7mS/OvBhT9KE02nhIp9uqDI3wOWy/8A+Rs/Ix19B8i8Xyn1TafNPXAoPkLq/bNW74SKuVfRc/p6cZEPI2thv+qSEgEo8+mQDgCR8QDYtF9bBdg8hgGA8gBptC+gCgBZA4Ba+UfhgsTPKQDoXeSamja+gFRoiXJeKbqZ9AEM00w/WusPgU/ofmrxed+2M/6u11iU+acNUnCzFLw1uOetU8+5wjVpUmpScnJqUuuchV6ODw9i4Qs6CGAARAkExAhUC93LG4WW/9yeAn+86c6MUl/LX1Hir8DTCg6uBScB7fSEXAcFABGvAMWM/46lK1alTUqdlOQTepqKfMF9BR6l+o+eAYCmABV1r5127qVY2G0tXTmlXumpQg/tm8/pEoGs/wOhvdep/0zJSclJvvqWVjsr7cbCpxWACgBsXi3550gEwGnfh9yHXgfr02+D/dkNYHt2EwVAh9pjz+5JiAB0ALCpINAamSjTABQFoIx8rtMP2eHLwPz4Bsh7Yz9kr/8MAyBn3Rf4mr3+c3U6YF63D2a+sx/SXx0Be/9leFNSgdLRiArfpk4J6Oiv/Jvo3ABWxDv/EgGgzv9p4Y+blvs6hW4o8fdAwVn/A9Z1OyEHZfk3H9S19SLNPfTiR9n4zLf3geusnwIrzwU2oBN/Qug/XvxhenhnD4UAjQjQ9CB2GUxbNggnbRwPgGkUAGlbx0cAbADlGKjwJ5gCtMX+H3vnAR5VlfbxFHpJIL1MS09mbpn0NuXemfSezEwKAQQELIhIU6Soq+vu6tpdyza3qGvvhaaogLri2kB6CqHasCxSAiTv95x2752A+7G7YFlynuc8E10WE+X9nf/bp5nHjj4VAAUlvtJMueVzMgeQ1PrjVmhbPVhttQ/ffPP9IXxRzd9Ep6ePp1OSCADQbfyqtvmiihHDhgYWFBYMyXM1zxAcTccZAAQFAF7FHUAZgSzJ+5Wtotkz6+KLv0erPUuHs5gDS2va7Ymi+4DJWqYAwIAAwBp6sAQnbgDaemOyFO8s90yKjzelBQnFdZcnWl0nUaYggboBJrYKzFL4eL41G/tUsrt8XEZuyROJaN89hgCBCb588deF7vp87fd1z723B/H5FXOMoqufGL5bAYB/ENCFg38oCGgYAAD9K9vAqABgpQYALiq3WcBPVQAYArhikXQuKoNMeIcaD+BIpWCsxQXhc++BmHe/hJiPkQI4BtGbelUlgNwBBAGcHTgCYzuOQsTaHaCTJ5NVYrQ0mAGApSZZIRL5Z9lx3QJqAOIwAOqJ8WvnAzpJrT96NXGdv6MBTLWXguHt/RDbeRwbPwYA/uzDDTmh3WRO/2iaigvZ1w/JNz8NnDwBeFcLru/n5Ga8L+B0fj+L+vMsSEcBQFJ2mhXfpwFACANAj6oAxmoAwDoCWQcjUxaChNt3QXDWflrmnWoOCTl1mFSZd1qzVfYdEpQZgOT1F4rr+4SCirteWffucKut+gars+kEef29kCmRl9zqbOjNddRePnr4yKEPPfHsqExHwwMIFET2+zTXC8wtQGlBNG8x21H3yPMrXvvBV43922fzlm1DM231dyeIpSdN1nJIQAAQS5U0oFLSy+Q6ft1th/Ls5dVvv/nBkJScsltMotSXYHUBed0JKJIEqT/d6rzSEB+LXYWiYsdIrqD8NwlW8nsZBTYeHBmg7VuxsKxO+3199N67o9NzSh5PyHSDycquRv5bieEzCLA0IAoGahUAAoDhNaIAEr9LAdDaBNX4NQDgHOokI55lBpx0C5EdonLrIeyelXhISPTmXojapF4CgaM0PXgYwrcehdDuXoh6ZC0Y8j2kbRrvFaAAYP0IeBU56VfAEBBkjQKoJ5OBGABYiSzdpoOWeSS42iH+sbchvqsXIrrQKu4TJN2HL6nFZ34/SvmF7APQv7gFhMoZpNgH5fxRfb/MtgaROYKC5A8AXhOht5wOACiYhwCwbhcM6zwCo7QA2KW6AEQB7IJsBQCkvoCX1PJf5v9TF+CTMu80c0iIfwwgKTkxoLiseY7g9B7X7gEQ7U0g2OqPp1vtS4tyMoPtFc3tVmfTETIhWeMCOOr7hKKqx+t9k0eXVE8YL9jq1ggOTz+R/83U6JvVi9OCzZAlt0CW5Pm8pnmaPDz49OXJ38s5+PVXge9s7xm18p1N417ZsHHc6nc2hS5f/37Iqrc+Cln91gchq9e9G7ri9bdDl7+6dtxzK1ePe37FypALLpxnSRLdWxOQ8VvLiQJAABA1ABCJ0TI3wMjbj2cWlV71hz89PjIx0/WYSZT7FQDg4J4TTaU9lltYUT9iJAkWWgU+yJxftjiB/V7Y+O34GgXbMXOee4b2Z2mbeJExOdO11ZRZAgmZJRgARm0DkMb4FQWQKVMAXKcoANOaHWA8BQB05PbAGAAtU9ZCQKeBAI4LKAVEpG8AlQtHlM6A8c9ugqgPUSzgGERuPEYAsOkYRHyM7lEI30yCguN39sLY7qMQc9uToM+uxWlWozLQlA0QcWgA4CQjwbACqAHeXosv5yAAsFDfH7/+ziZIklog7ranIa7zKEShNB81fnRxI04XmcvHov6o1Td28zcgTlhMi33alAYfASsA/yGiHB0pplzWpIMBwLoPmQLwgsU7H8as68EKQAEAqwTsIVkHBICxq3ZhBZDp8hEA4MrCJrUFGL3++CIA1H1S6pliDh0AgHnzLxteXDHpHkHZAqSOAhfsDd9kZNp9w4cNDajyTrNkyp5u9M8iEPCQLkqkrgorO2rbLtbJ1e3Jor1xp+Bn9D4/wxfRYlVk/K5WyHK3nHRWtd/x8Asrw7fs/XTsvq/+GXLgq29CPv36UMjez78a233gi7Hbez4Zu6Vjd8gHWzpC39u0edymju6xRw73nr1BJB9uemNEVkH1z5Ot5W+nZZW/nZpdsT45q+L1JGv5a4nkvpFgLVubIJauTxRcbyby8tpEwf1RgljSm4Ar/8pw+a/JWjIAArSzTyS+u1Fw9mVky/f/7v6/6BJF+R3s/yMAWGVIoNH9JN6+r7LKV8S+t9CxYwNSs12zjLyzn8wIsNNdgTYw8sXHubySK69d1q78LPayZmdSVunBhKwSwENGlMi/avR+X2e5VABMvg5inv8Q9KsRAHaCcQ0DQIU6ax+/uv4BQPQ9IcPXWWygx1OLHLgEVwWAg/juAi3Y4WkXHydBlHcRhL3cAbEfHYMIdHFasBciPu6FiM3HIBwFBbcehchtR3H5bejOw6BbcDcYxHL879YgSJpJRQ48s0ABgOIC1KCtOMA76sDiqAMzivpr1melODwQP/duiNn+T4ik1X3s5SfGT15fNJsfb+rZCxDR1Qv87NtAKG0nxl8ygRi/i5b54uUhLM9P02oaIChgUFqPmzSw8OBCIAwARQH0//8AcLOMA3UxqKshqDGAT0q9U83oz5T2rF39XITo9L6orQAUWLrP3rCvpHZSNvp1rtLyyFx38+pMZUeChy4LaQDRXvu1s6yxorDEWys6mr5CsQRRs0YNr1PHl36NIICWrLrbwCq3fpkl+daJzuY1grP5dVFqfkOUW14TpJY1grN1jSC1rhGdra+LUutawdn6NlfU8PTjTz58SvXhf3ze2bh+tCW/+nmyvspN8s6cC/RoaCWaVoOGVZhl0JtRia4ERhSM4pDvXkIMn5b/mnAwsPSkSXQdNAqu40ZlE65E5LsoQUqmtKqpeabbyDt3Il8WvewEACSwl8gV/2P2ZbNTtN+fJc8xwcg7TpIIuwoAg6XoZFqWfPeTD/1cqQbMc9ZMTbS6D7PXnwHAeDoA4Py/y18BMAC8ShXAPSsxAEienQBAh6vu7KQ/gcp8FHWPNxcf11lsJwxmOx1jpsYAjDSLQYp17CRaj8qFeRkiL7gBYlbuxhOEwjYegwjqBoRv7oWILegeg4htRyFy+zEY130Cxn3wCRhbF4GBc+PMQDxPFpvE8g6I5dSBJcwFQDEAshsAGX89zvNnoI47ZPz2RtC3LYKYDz6DKJTyo1V+YVT249RbVz+M7gIYRV//0J4+SPvFY8C72kDALz95/ZH8FykAyNJQL833E2PCqTW6VQjXCWC5TgOCAwBg9syF0et6YGiHCgClGWgAAJALkOlmAPBhBaAE/tjrLzUQACAFMNZfASxauCCNs3s2c8oEYDb919vP2xvevOnOe3GkPjcna0huafOv2ZIUNjEZt1Hb648KxZVzMp2Nd4lO70n8vyuG34yMHK1T72cKQJBb8RVdrWTLsqMZLHYfWGxesNg8YLZ5yNfo79HL49sMGcWe/Y8/9pD1rAHgo43vjbLk1T6LgngmNpgD7+cj12BBQCAX/bUJgYJXDB5M+P9H/trIu7ZmZEtzTLy0A5f3MuNnOXxR6koUpadNgnQIvfomfJ3I92cAWH73nTdFar8/m6u80sjZvtYrPQF4PDjoLcVgstie/dXPrlGQbsmRb0mwuvvI61/ilwFQ5H+W5jMLgUDGrgACQOzzH4B+9VZIQABY0wn6e1dSBUAAQHxuYtTk5acRd0txb1xqzl8MnO0Bg7m4l80tIMVBDqVKkNUO4BoBJNctNojkZAhbcC9Ev/kFnik4XlEAxyFiy3GI2NoLEduOQcT2oxCxsxdCuo5C/IqPQF/UBjozmZlABpUSAMSyqUWCBMlIAdiQ9K/Fr38GBUC6gxT7mNyTIe7FDyBqVy+EozLfrj58x7OoO3r5qfGjaj+U70945O/Al07GBo86/NBkX+z7u5qx/Fe3BrNGGrpY09nYyzs9/Xi7EA4Q+pSgoKoA6Ez/pisIAFgasFvTDNRDApAIAqgXIIsCwIp7DVQFwGsUgOICIAUwRs0CBA8ZGtDSPiOfc3gOcsoocFrpJ/n6rFLTA489/yQlRmBAQXnLpaLsOyrQPQmavoCTmVLTW5mSt4PtUBRldH3kU2o+JEreN62S759aAJDJQ80goPZjtI0YlR3bSfkx+WuUlkSf9H+3+yC92Lv7iccf+c5O2H8fAB+/PyqDAoBId7dS0mvkmPGTr43Y+NH/VoIN36gxfhPv6ksUnL/2tjTpDJbi9fjFFtTttybi6/eZROk4evFN9CZQ/z9RcJxMy5Rv+9Mff+NXHlVX3ywaePt2FlAz8MznLgZ9Rt6GJs80E/p102bOHZnAO59DrkWC9vUfEPwjgzWIAjBkkT57PwCs2ooVgGkNVQCZ/gAgxmsnLzkNAOrMRb1JXP5NnokXZxvNhe8ZzUX9rHV5IARw9oAqCBStx6O9Mish8q6XIOq9QxD+cS+EIeNXAHAcIrb1QjiFQNjOozB2+1dguOtp0GXXg86MJhIRFRBDlUA8bV5KzisHix1J/3r8+qPmnnRa6Ycm+8Tf8QzEdh3Gxk8i/n044o9XeHUT2Y+MfyRdyxX3WjfwVTNJlR++JOqP/X4XGaKBvuZk4gYgI0H98+kFlXuszrr7eWfTt7gYCNcH+JSgoLJtiFYDZjAAMAXQ3a9OBqYKYPQ+AoDssmmQ6W4GkTYbfRcABGfdJzgLoFEAIaEjA4tK20s5u/ewhc4BIKW+eB3ayYLytmvz8guUcvPiyrZaUfJ+Lih7AtTmIKvT02eVvP0YALIXG7+VKoVMZ+MHpd6Z+aLk/TsCgIgAILHbogGA/+W0lyoEBICHHnn07AHgvQ/fH52eW/0c6kFHhTNkIKcMetSeizrzLBL5xBt7ad8+AoGgvv4EDPLhVLHEsfq1vw5P5Iv+ipp4DHRppVHwVwMsn6+9CYLj62J33SnTfmdOnh6nF2zr8IRgui2HvL7FoE/P6a5qaMepwIbmydYEgbgWLL5AAMAm6lDjR0afxQCgKoBINOTy+Q/AgADwynYSA8AAKFdWbiv1+ILq3+PAn7mwN91qv6Vzb9fwXGd9pT69YLfJYiPZDwYtljmgMCAVe6hnwAbRqFxYmgQxL2+DuI+OYwCEb9UCgEJg+zEI334EQjsOw5iPPwHdlb+BOL4C4s1kvVmswK4T4kQJEvPKwGyrA7OjAfv+2Pgd9XiyTywa7rHja4jqIQG/CGr842nrLdrGM5pu80HSH8Ug0tuvIcMxaL4fbQXm6IvP1oVzMhmlRfrpPWAuqjmcaa9Y4JkwvYh3NHzFD1AAWvmvzPPDANgFQzsPw+huVQGggSAIAGP20TSkBgCqAvBofH9/AOA6gDFqKfDa15cHOyontPMOTy9yAXDO3kki/Jmy70RxxYSJkeHjlYBb06RZOVYJlwZrJgQzFUDrA2SyS5EoAZT3b+zLctQ9/MjDT4zIdLfcI0q+41gFIMNnn051DwFWAUoTkg9QfwJyAdDXZjsCgGfvnx5+7OztJNjw/tbR6XnVL6JyXjSNBm/C4cjXeEQVvXoLVQJaFwAbfwlxCyyO16dcND8O+l4J4HJKZhs5xzEMEaoADDQQxgBgZL4xz65jR2mtzzzw+7vnxmtGJ1qdTxoEiQBFaRyyIwVwKNdeUVecnR1kc1RON3KOw0ZlBJiLNsqoAzVN7PU/rQtAAKBfuYUA4NVO0DMA0OGcxAVw0hgAKwKyg95S2Mtl2W7es++rob+997bhmQVlsxO54i9MtIWZQQuDi30iAPA2AgGUGjTbIXLyNRD15qcQs5kaPr4nFAiEb0PdgkchbAeCwCEIfbMTdFOug3ihHOJ5F8SJLogRZYhB24uQusorhwx7PTZ+5POj3v5EexPEtS6C2Ld7yDz/bpLrP+3rT40fjfpK/sXjYJFaSOoQz+9jfr6PGjMFAH3NcWGPvbE3V2r884zZV0XXtk6zWeWmQ0ocQPb6+f0YALQaMKPxCpwGPAUAmt0AYxgAyrUA8NGioyYFLioAag+UeadmjNW4AEUFWUOLSlsX8Q7vSeYCMAUgunxH7DXtzqGamX+Tps3VC86m9wRlT0CTRgnguIH/xQtFGg4XlTbNef7pJ4Od7sa8TMnTQVasNwMZQNqsee29ysWG7/Bp4gBefDOKGz958NGnM88aANa//e6ItLzam4xCyQdG3v2BUSh518i7N+g5+V0DJ//DwEnovmvgpA0mTn4ngXe9nSi43k4UXX9PEt1/TxTdbyUJ0ku5jjr3y48/jGnJ57iyTbzjIF7vNQAA2vw5hgD26e39Jq749VkLrzulSmPj0w8Gpma5f2EUpRMGCg9sUBb88vYlcEVTo/Qpo2OTc+7RWeyk/oA2AfkBgI7VQhAwDFAABgqAmGff1wCgA3S/WQEJ1jIFADo/ANiViD4CAJ/t/NWX3xzC7sumj7cNs+aVLknk7UdMLBXIsf+P5jIIIL/dYodoiwQR8++BOFQqvIWqAASALScgEn1SCETsPAaRO47CuJ3fwvg3doC++SqIFyogXiyFWNEN0aIM0ejfVV4FpNuJ8adJjZDkaAJd3WyIXdMF0d3HSU8/Cvp1UuNHwbYuwK+/EvTbA5D40FvAuSfRwZ3NYKZyndOuCncSA8aGjNeQN/bnOOpevPs39+lGjxoV6Jk8qyjb7T0k+rUFq2lCC3MBJA92AcauVwEwrludCRhC5w7g2QOnAMB7SuGRSAEgSnUHyn1T00ePVhVARkb6qKKKSQ+IUnMfR6cA8U5S6CPITV+4Gtv9gm233373cN7h+aMoeU8KStdgEyg9Aorx01oBBAZ73WfZ9ir3sCHBgTf88u7heSXe+dku3/uZcvP7ma6Wf4hy87ui5HuXd/r+wTu8G3i7ZwNvb9rA2Zve4eyeDZzd8y7n8L7HOXwfcHbPx+aihhUPPv7CKQN2/uOz55N9gdPn3xDhu/DKJM/UBUlNU+YlNE6eY6qfONtU3z4roaH90oS6CZeY6touMtW3XWRsmDDTUN8201DbMt1Y23Khsc43TV/jmRz1h789raAyU6qMMPKOLQatAtCu++bVgB5d+oEM+YFNG9897czmLGf9rASr6xjJw0vKynC9uQgSBdvlYXEpkbEpuasJACQKAZqCtEpgUiDgIiogy/8ast0QNflaiHlOA4BXOkB390AAOEkQEPnvvJrS03PFvXyudOOX33yjxC+WXndblMnieMrE2U+SrICTGr5NowLUSkE9LRKKFMsg4pZnIebjwxC59TiEI+PfchwDAF/kDuwgEIjqREZ8DKKWbwaDdCFRAmIJxIguDAFDfiUu8kHSP9nRCCa5HWIf2QBxyPh7yLRdIvtJyo8E/gBG09cf+f3xr3YDVzaDlPjSl98ieQe82rSTz0GvvRFEW93mqRfNLVz9ymuBQ4OHBjRNnlWQXdL8TyuK2Ms+v00+yuYhLQBwIRACwHGsAPDgEQqAsX4AuPAUAAjKy08AIGIA1B8ob74wbawGAK+tXTsmu7TlWV7y9fPKOjDS7CM663cbk9PTtH8Oa2uqgrLllgkomMd+LTN+lj3g6Qp1DAI8Pbh2e3njtLTg4KCAVIMx4PKrbxhz4eXLEiZftjSx/dIlCW2XLDb5Zi4y+aZfZWqefqWpZcaVptaZV5raZl5pnHDx1aa2mVeZJl56dcKkS69Omjbr6pQps5cZ3njn3R93G+G1P//lGCPnfNookCWcKgScfvlzEtDDO/9OpGU6ruvr/fK03VFiYUVbQqb7CO7qo3XvBAI2SM+Rro/Sm1PiUvP3o0ChUZN2NIpaBeDyiwOYqAowUQAg+R2NFcBWMK0mAIhXAOCgKUACAJ1GytPv45glR77+8y8OKt//woVXBpaUewWjueB9UixEocXZNArA4XdR/j4GFQnZWyDi0Q0QtfEITgWGIwBQFRC5/QRE7jgBER3HIarrOMShKT27j0PUHS9AfHYTxAslECsgALjAUFCJX37k95vsXtBf/xDEdxyDyJ4+Kv1Vvz9kQMoPTd6J2vw1mKf8DDhXO1ni4SKvv79sb8IvvhnfBjDb0Cqy+i/kqubJa//+Jn4UhgYNDfBNm5OXXdr6DTHUZv+hILh4h4AFjwZvmosVwLCuUxVAqB8AehQAsDQgCgKSCkQCAVGmAJDr9pd5p6aNHqUOBJl/7a+iRFfz33mpuZ8oAK/i2/NF1R9GRMX5DZ4dEhgUkF/WZhElX4+gAMAzAAA0AIoggtqJbXXP3nrvn8YNPZ/WiB071DMsOdN9ixYArApOG0Azskm/luLjXK7zoht/tuy0FU6Zjlp7Qqb7G9Lay1wJYnwpWY4/lJbWNRsstl7WiacAQHn9XfT1d1HjJ5cAwPWdACAKoHSAAnDSF9uuBPf0nO2oJVde9sXBL/z+KwNAYIZVatdlFH5JNhuphUMMAPj/r0waIqu/cDygfDpErNiK+wXCEQTw638CIrafhIgdJyGi4yREdp2A6K4TpGe/41uIvfxOiOPLIYaTsQowFtZAirMBEuwNoJt0DcRvOggxdKwXafDp07z81Phpwc/4zl7ImH8vmN0TweKegOv8yevvUV9rFLBDhm9vwDe9qAHMRXXHhaLq21onTVMGXgwfMjygdfq8vKyStq9FdwsNGBIXQMkAsJl+CAAeCgCqAMYpCqBfVQD7qQKo0ALASwGgDQAiCDSCVa7bX+qbljpypDqHY8rc69KsJW1dbBWY4tcjF6ao6vmxY8f6tZujZjPvpFnRouR7S9DuCxhwyQYhAoQcl2fxKyuePo+sPyAg4KafXRssFFfNMQlyn0EDANYuq8YBqALgij8XiyqLg4MDT1sTnSs3ZZisrs/xeG/8+6n1+Cbe/ncjV/y0gXP0GVmQkc7KM1pVFWCi8t+kef2NuBuQxAAiUABOAwADUwAiBYCysVdVAKzQR89jACw5+PVBv//QaFnKtT+7bVQCb7/bYCk+abDY/XsFWHaAzvdjTT2ooi/S4oSoC38G0W/ug6jNR3E8IHz7CYjY0QcRO/sgoqMPz+ZD1XuRqHBn90mIeGcf6GtmQ4zFhdOCxvxKSLQ3QHz1xRD52k6I2XUSInb1qcbfTct8u4Dk+6nxo3p70/2vgMV9ATb+DFcrDfx5VZ99gPGjlz+9qA4y8svfnDZrId7ePCSYKNURQ0cEtE2fl5+JAMAqBhkAlLmADAA+rABCFAVwXFEA43roaHAKgHEYANMJAGg5sLb1WFEAMlIA9fvKvNNSRo0aofz3aZt1dbHobvtUSWFiCBAAiPa6340ePfqU+WH33nZXCC/5HiW/1qMMDeX81AD9PRyNx7LsDdXn3fKQ0cPGBOTKDbJJdH1mxKlFFwEAg4DgVOvk8Wfx2jyp8pTefnYK3U06o+jeY8AA0AQUsRJwnjTwjhMs326krboEAlQF0OAfugmnuABEAURMGgCA1R0Qd/cKXOzkBwDW4jsQADnS4s+/+vwU0g8LDAqobGwxJfL2p1Csw8AahFj7MGstpuO+SFMP6hewQSSqFLzuDxDz3kGIQgHAHSchHBn/zn6I6OiHiM5+nL7DBo369LtPQtSLGyHOPhFiUJFQTgXo5YkQ/fCbEN19AiK6+yGc3vGsuAZ1+Gn8fjTcU7diB1jKpoNFbsWbe82yv/FziuxHxl8PGcV1kF5Y228uqNlWWO4rEbL990CMGjYioOXCuQXWkglfC5p+AS0AeGr8aJAIUgAMAGM0AMAKoEd1AbQAsLp8miyAV4kBMAhY5fr9pZ4pKSNHqgComTHPy5W0foP3FKBUpuSl04AaT9gqJyyNjAo/RZE+/peHR+SWtt2OCnz406kAvDykkewPsNftK6ufkn1WjOqndkrKmw2J1pJ3CADcmmwAlbtKINDRn8Dbbs3ML/7OpQnVTdPCjaJ7uxYkes3abDWmQKcHMxDQwZla42cASNDGALIYAFgdwA6sAOIGuADxSgzAoQKAfI0BcODgJ6cAIIiuTJs9e0G2Pj1vk8Fi7zdSJcQAMnCoKOvpjzHbIKqoESL/vAYiNh2GyJ0nNAAAcjv7sS8fQSEQ2tELkX9+AyKzGiA2pxHir38IonYegUjU19+FgNFPevtpWm0sa/LpIX5/5KZDYG5bilN+Fvrym2WvIv05tnQDGb+DSv/CWjDnVx60lzTO3P/VF6f8Oxg5bFiAb+rcApECgKctw+qr78EFRfhrCoDQ9btguAKAkxo34FQFkFVCFIB2+tBAFSDIDftLPFNTRoxQXQDn5Nlz+bL2o7ibkUFJwqO/v5XqJ11wuj+L5oSUoPyK9kusrpZ+5jaom4MoAOzoNgJfXLNx2mXzE/4LM/rpnsvmLBxiEly/I5kAl/JyKxN1qdGaBHtvpq3yojmXX/SdLZGLltw8Ts9J6zEAeEmJJ/hP47GfehEIRBIHIBAgcQDTaRXAMoh+7gOiADAAOiHuruWKC2AQWdvtAAWAjZUogH2fngoAdr786qsge3lLrcHiOGBE03146RTDNyhDRR3K4tEYzgmx1RdB5AubIBZlADr6ILxDCwBQlEBkN9nOG9Z5AmJuegriL/0NxG7/SqnzR8Yf3gUQ1g1klr/W+PcAjO84AWnzfo/7+y1yixL0szAAsC4+BQCNWPpnFNYcz3bUXP/kc8+MKio69cEbPXxEgHfKFfmiu00DAO8AFUCAgHoJLFgBdOMYgB8AeogK8FcAMyBroAJQVACBAAFA/X5305SUYcOJW/L719cG5F9wxf18+cQ+oXQCqWSUSfRekJo+k+vaS0/33xGtuSsonyBZ5ZZv1M1BZHEIy4Jg4ycAWDN55vRTxtadF+fQl18GpOSULzQKrqO4wIhKaPJ6O5RIuIG3f2YrbaoeOuy74yRPP/nKSAMv/VGPKxQlRUFoVIQGAjTNxtn6Dbz9hFF0kJ16NAuQwNwBvywAmgp8DQaAYdU2PwAMdAHi2dgtmgpEN56zHTXnOBf37P/0XwZ7fnbLrSPNOaVLjBbbETYwResSqRBwaIKCTogWXBA79XqIfOsTiNrBANAPkX4qgMp7tKIbRfB39EL8pq8has8JUuff3Q8R3cT4xyMAdJPpPsz4x+3pB9Pdq7Hfz+GAXzOu9GPGr6zbcrA+fmT89WAuqu8zF1Q/Vz/50vjv+rnR1FzPBVfkIQCwmQG8a8CIcKYINAAY3vUtBsB4LQA0QcDxCACVM05RAKLy+vsDACmAYfTP2cW//cuI/BlXvSxUTgYCAOIG4Pp9Z1NPaf2k72y4qfXNTBBdrZtQIQ9bHWahrz8BQAPw9oaTVnv9vff+6bfnVwBQe3KlhgYjL3+uvtraVCDb+WfrqGudlvuvfp8JDb6hSVb3z/DvwyBANwdr6wpYn4CBK4b41OyumCThaQNffNxodfq5AeRTVQMGWgoc/TxRAEYMgC6Iu5MBQMLZDLayO563q4M3FABIi3sOnCp/B57bb7s3PCVTQqXSfUZlfJh2yCgFgqjuH0TNPVFZlRB17Z8hHE0V7ujHEIjcSS6CQDiFQNguwCu6w/cAROzpw+O8x+8iI72w8XcBjOsCPN1nDE33jdsLEPfiVkivuQwsrjawuGnEnxqnRbtxlwIASf+M4gbgimrea558yb/0c8eMGBHgnTwnX3C3fcMMjdNE/bVBQKwAvHMhZF0XDOv8VlEA4xUAqAoAA6BqJmSVtFAF4CXGT6cEkzoACgCpfn+pd2qyAoDX1xuKL7t+IwKAiNqaaSejSP5/W6p9U3Tf9fPMuXzeaKur5XmeLQ91eFUFYG8kLoCj8XBRZcuU/+/Pw//0mTRjodXIOzsNeI22TGbWMf+fo+W0XPE7i5ZdY/hXv09sZFiQUFAzU8/LJxAAiDzWjN3yBwoYUatwZvGvIxMsc3WWopPEDfAPBqppQKIAUAwg+vkPFQWgRwrgzpfxvAMDNUQVAKrx4zHcnO1oRrZzcefez86I9lMuuSrVwDnXGjln/+ncAZYVMGgggGr8o3NqIeLmJyEatQnvILEAAgHiCjB5j2b3oTXd43rUyDl68cdR4w/ppIE/Wlob9fpuMNfPA87dDhZ3Gwn6ScQgLZqIvzbwh6S/ubhuj1TTVnfgwP5/OaACKQDv5MsJAOSBAGBZABIAxJcCgCiAXhUAu/xdgLBV3RgAmSWoEEiTBtRMIxJx8xECQMOB8uYZycOGDwkIHTI6YOrmzhJh4a++Eism483FHAUTni0oNf190sVzTx0fTM8bz74YZHU13yI4m0+opbsMADQG4GjYk+3ypH3X73FenBtuvDHEYLGvNPBSv54CQJmXhwtiHP16wfG3O+6+87QVgOwEBQcF8AW15Tre9aWOIy2w2hl4SkoOQQUN5TAXHHaWNTbq0nOX6C3F/SYaBzBqAZAp+wUB8V4ANA9AGwPwA4Cs7gbUZAIwACzFR9OzHYs79/5rF4CdaVfPD8yT6t0Gc9F+XBvAqdkRdo1s/JhIaxAEGWJQVsAxEcKf/ACicTygnwQEdxJXQOvfo8uaZ1CwD734odT4x3SSqD8a7jl+2xFIm34TWFwTSHcfjfpzLOrvJINDtIafXlQL6QU1RwVb7dJ7Hnn8/61KGzNieIBv8uwCBgBOAQDLAKhZADxY1DsXQrUKoIspgD4/BRC2qosqAOYC+KgCYJcoAtGFYNDwSdWEi1NHjhwWUGWXhtZ8uO1q6/xf9wsUADgTgFuaETQaVy689qbvXNxx4IN1AVZX82ze6TvCKZuDPNj4iQJo6LfYat8ur7/wO1fYnxfn3Q/fDzbnV11jFOSTerr/D8t3JRduP5GYLV1zJr9Xlt2breddu5GSwAM2lam7/oFABABdWu6njvIGq95SsFTP2fpZTQAJBkqnBAQNdDOQnwJAaUAtAESZjuBi47fsyicCQFq2Y3HHnjMDADpPP/3iiLQs6TK9xfYlmoZMYgJOTQrTqcz+19NtxGjQR6RFgnDfQgh/vQcit/eRIGAH4HhAeCfq2iOvfSid4MsuAgDK949Fxk9f/9CuE5B409NgRpV+eKhnC/b9/Ut9acoPGT9L+RXUHOcKKh+88NJ5ZzTWGgGgefLsQt7V9k8OAQB1CrI+AG0a0EVcAKIAOmE4AkBXL5lLeBoXIHxlF2RXX0TrAKjsxwpAdQOQpBfxtOCGT8vaZqaNHDU8oOerI6Ptb216WJzzCxDKJ9HBJi20pdnTnyM3Pv7yylf/5X9LW/W0Wt7p+wb175PrwS8/AoDF1tBnKar+w0OPP/2dKuK8OEMDRwZaCitlE1rTxbM2Yyewld963vZNotVecya/V1ZxZYZBkLfF8zJeu3UKAFiprbkY9KnZG8xZ+XG6jPxFCgCoG0ACgv6uAAYA2guAAaBJAw4AQDzNBCjz99AkII4AIDXLsbhzz5m5AOw89vwboxOsJQ8YLI4TCABs9Lm69JNCgFYhIhUSx0kQwZdA1KxbIGLDFxCJYgFdAJGdxA1AABhPARA6EADo1ad3bGcfxD36PlhKLiRluC4a9KPNPYrxO5nxI5+/HtILayAjr2LDxEsWpO3cufOMfs7RBABFvKv1n1gBUPdCGQjCYgB0ezDnmwshazuoAujFQUAEgPEaAKAbvqJTAQDbPYg7/yR/BSBgANR/Wt42Iw2lAe/avjs6863NW7Jm3QB82UQ81szClplITcftFb7bv/j64L+s3ilrmmnknL6PsQKwq6+/xYbGiTceKyxtuXTt68/8uGv2z/0JDCirm5ZuFOQOsv2XvP6oaQddvaWo09M+M+lMfqdiV128QZDf1vESBoCOzr7Ta6oLcRDQXHhSn5JzY1JaxnAjV3Qlygbg6kClM9ClFAehSkCcBvQDwOkUgEwUAC4EIvP34mkvfxwGQBEGQMfufw8A6NjLm9NNlqJVJt7ZZ6JlzCztqHUBSJEQyUREIQhkVkPkTY9D9JYjENUNENmNZvVp3AANBLQgQBN10GfM2r1gqZpFglhSM5b9Zmb8dEa/hUl/TcFPWn5lZ2Glp+oXd/7qjMvbxowcHtB8weXFAlYAzQpg/NqBaQwAuwC+eRgA2iwAqlvwAwCaTbiiA7KqLyKNQMyVoK3Ap7oA9QdKWi9MCRk2IlDevFtM+/v2g5kzrwO+VO1zIHUADYcLSmsv+6h7x7+Ma+TbK4YKUvNFnN3zGTJ6SzEqg64H3tbQl+VsfH3ekuuT9PHfmRg5f84jDz01JiO34laj4OrVc84+ncXRrzPbUUVcb4Jgu/n6X1w34gx+mwDJVRVi4KXnUAwgniM5ch2nXcRBVIXBnN/tLGsozuCtQUbettDA2/u0CsBkVesCjEo7cAnNAqgxAP3qnRB3x0saACD5LysuQBxyAZDxc3aIpQDo/A8AgPoF7O7GTBNn30Z2IMoqBAS1RJisBiMxiDiBuAKRRa0Q+cAaiESNQbsJALQQwMFATTwApdDG7QGI2vItpE27ERs+hw0fXbXLT+nuc6oNPsj4zYXVXwiFJdPv/ONf/q2ptBQANsHd9k+eAoBn8h8FGRUXgCqA5nkQunYncQGoAkBFTgoA9pKZAOHLKQBo/p+0ADcqEOCpCyDgf07dfnfL1MTb7vtTUN7WXdMt6zcfsU5fQicat+CsB6kDaPiyyF1bg1qY/9XPFDxkSMA1194xUq6ZXGOVGu+zFNU+xxfVPpsre26afMlC88zpU/83tv/+tycwMDBgwuSLo1JyK6abeOcfTbz9URNnvz8tu+RCLleODAo6sz9LdfUNww288yE0nAQBIB67EdpqQJoWNBe+Onv+vPB0S2ZwgmBfaBQcfawz0GRlDULaOAABQJRGARhXbwf9qp1EAQiqAtBmAeIoBFQAOJd0/xsxAO357KsjwWJxXYORd36u1AcoBUKscIqu/hId+PuIE2SI4t0QXTIDIldvgZjd/RC5i7gBkTQjEI7y/gwAaLAHejV390PqdY9AhtxO/H002Yd14tE6doum1NdC6/zNRbUnzHmli+ddedXooMB/r7adAsAuuNsOEQD4qArwKqPAOG0QUAHAIRhLFUDYAAXAAJCJsgAKAMi6MTaFWA0GIjejbq+7bVrCo3v2D83a3HW3ed3GE5kXXAUCXl/OSp1R52Dd3qZJM7OHDRt6RgbsKsgOaHCVj5pxxaLwi+YtDVt6463Dhw05T5T/88tfDLj/4SfP6NeWu11DLllwzejypkmhMy6ZPyrTyv9bf4reXrU8KFGU7tNZnKoCoJkANR1o70/Mcv3uwYceCEpNtQQniI4FJpEBwH+dtjYbQACgCQKu3gH6lTtoHQAFgOBSFEAcHbwZp1EAadnS0u4zTAOe7sxbdO2IRMH5BxPv7NVCQK+9SAEoV4Y4wQ1RQhnEXnAtRH74BUT29GMFENUBEKUBAU4J7gWI3A9gevgd4MqnA6d0+NGgH5P9jia/XL+5uB4sxXV9GfkV66SKBv1/8rONGYViAJc7GAB4BQBN6jowBgCmAN7YASMUAPRpFAAoCgC5AJlVMzQKoAmvPOPYGHINAHi5bo/UeqHxqvVvhWVu3bva/MbH/cLEBTj6b3HRmgcyOWh76/TZyUOH/svE1OBB5+4/PhjwzMsvfC//rJOfdgSm55T8Umdxnoy3aAHAjB/HAXpTs+V56NcnJqYgYMxXFQDxq7UAMJ4GALgQSKsAxDK6GlxVAHEsC4AAgMZxIwWQLS3b9V8AYEjQkIAGz5R4E2dbTrYlk4Wp/gCgsQAUFMRLQl0QJ5RAdGYVxPzybxDRcRQid/Vj44/eSUCA3YHdAOH7AWI2fALm+jnAlbSDBQe+WtXRXhQA/h1+9bjOn8uv6LbJtUVF2cX/0c82ZuTwwOYLLneqCsCrmQeoDgRhhUAIACGvbycAQFkABQAA4+hiEgSByBWdkFk5HU8FVvYPOhuV3YOqCkC/f93ugvqJhuq/PpkpbD3QbX59K4htc8nr7yIbkvA2IUftB9OvuFo/fOh58or/VM7xPW8HCIXl0/QWx9doxx4DwICS4ANCYUUO+vUJpqSgJKs8z+AHAFmFQKaszAgwZJZAFEoDos1AqxgAdgwIApIYQJwmDRhHXYFYS/GxtGxpWfee7+4FOJNz4mR/YIHc5NCbHdsMFqeaNmXlzywgyJaDWlFq0g2xvAtiC30Q+ddXIaLzGER19UF0B7okOIirArcdhuQZvwKuBEW9Sc7fwgJyVPqjUlYEgAwU8beRJp+M/MovMgtLZ996x21DgoL+sx9v7KgRCACS6J6guADakeB+AKAKAAFgeMc/MQDCMABAAUDoXgKB6JVdYK2cjouA8G5Abb8C/T15CgCLs253dmWLoezD7kkZWz47YnljO4jNc7D/b6YAQKvSLY6ad+cvvTH+vJHxP6VT7Gxw6HnHHr0mCKjj1MWcJt7+zEvPPRSKfm1qclpQYqZrLtpIpBTVoJJgzYwANicQKwBaCahbtRUMCAAoCIh6AYQynH5Dr+1AFyBeBcDR9Bx5Wc9/GAPQngf+8ucga1GNx2ApPkiyG7JSiUjSkZI6ppxdNAyUkyHOOQEinv47RHUcxYNCopE70IPUwFFIvOq3YHG1kx1+buL3svHdzHDY659BX/603PITlpySGy6/esmoM/jWv/NQBSALCAB4EKb3/wXA2NcYAI4rAEAlzuNR3wKaBrQPIHpVN2RWTVfGgZEsgLptiFMajRrR+vPdOb5Ljeatn/7SvP0gmBEAmi5TAGDGJc+ojbd6w6Kf/Tr+vJrg81M5DY1TkvWcc7NeqQZ04Im6yPiRKkjNKVn8p98sw//lEhNSg5IwAKQ+A93KY9K6AMqUYBmvDI+kAPBzAe5agUefawEQR/v145RAIHEB0nPkpT3/hQugPU89u3x0iiX/Vr3FdlhvcdIYhFoTgLcUW9UtwXhlGdoJgAKkTZdB2NvdEN3ZC1E9/RC76wSY7lsOFjepd+eY8SvLNFnKT339UaVfWm7FyXTR+WJb21TTf/vzEADMlpkC4DUKgNe81vjFpkHAMa9tIwDoJgAI30VcGQyA/eRGr2YA0CgAqVFVAMj4cQ1AI9qLsDt37o0ZGVv3P2rp+BoyXtsOfN3FFAAsBtCAAPDOkp/fGjcIgB/huW7pTWP0vLRCz0n9OBhoIYavM+PR2kfTcqvqhg8n/+GMhqSg5KySK7ACECQlr64NBLIZgQoA0HbglVtwIBC5ALq7VuDlJwQALAZAmnPiNBBACiAj17205790AdhZuui6gCtmLQo3ifLDeouj38CmKzMAaEBmoADA6gC7RTLoL7kBwj/6AuK6joNxxRaw1F1KtvbSDT5a4+dpLzsb6kmkfw1kZJV8VNVwgbD/08/+63QWAoB30iwCAEkFAIva+6kAZIw+jQJAANhF2pxRl2MYVQAqAGaQPgA2YJTGAHAHI91+jBWAs2Gf5br7GlI379/IdR6C9Fe2AFc9HfgSFgT0MAC8veyXdwwC4Md4Fl+5JDgtt+pXBkHq01tIQ1A8Mv4MO8SlF30oVzans19r0CcHJWe5rzDwzj61tp4VA6kxgIEA0PsBYPl3AEDdxBuHB3liACzp2X3grP6pKa+fIBgF+X0jBYBRVCGgDj1VG4eMNF2IxoPH3/hXSH5nL6RPXIRbXcniTrq8U2Y7+rwqAFj031YPXGH1J87KNu8Ty1eflS20CACeSZdqAOD1UwAWCgHSgOQDC3YBmALohTA0xkwLgP3EBYhc3Q1Z1TM1AKBrxyWy/dhMAWCWGiDD7TuS9tSaV9M7vujlug5B+ksfAVc5TZMFYEHA6reu+dWdsUOCz94C3sFzls6w4KGB2bbq4gRR/tDAOU/okQIw2/t16cW78+SGyb/57f2KARoMFACCU3EBFMNBr2amGgPQIwBMRAD4SOMCEAVg4EvILACcdnPhIhyykdehfDIA7N6z/6wCwBRlCswqqmkzcY4v0DAUowYCSmpTKRt2KGPQUMYizu6FlHm/BmtZGxmU4VKHcHCal9/voj724pqj2fa6GydfvOCMCrTO5IweOSLQM3GWCwGAbMPxKlV7HF1VzkaCYwCgSsA12/0AENbTr7gAoftUAGTWzADR7VUUADH+RuzTIwDgT6kRUiunQOIbH/WldB4ES9dhSH9yA1jQjkM3zQK4KADsVW8u++UdMcFnEQDtF08LuOMPfz1rv995ffZ2dgW1+C5OtxRUz0/OKv1NktX98xy5qfSll5/3C9sakAuQ6ZpDFMAA6awNAmI/2gURE5cpWQCiAHaC7u6VYOBK8AyCeGz8JAYQq2zkVQFgznUv2XOWAYDOmjfeG2nJKkFK5isyFdmlvv7Y4B30OrEaQEHOBDrvIL24VhmWqUh+6vP7A8CLMwC8veFElr32kUsX/iL6bP4MCABNky51ie72b8kEXgIAQSvZnXQ5CBoKigGAFMA3uBIwbBepBAyjW4pC9pEbuaoLA8DqVpeMYOPHr78HMmQvZMgeSHc2QlL7fNC/uxOSOr+G1I7DkPrAKyQuQgHAMQVgr15/za/uPKsAuO/BBwM2fLTxrP1+gwc1B5n5gMJCx9C8vLzT+qgIAEmZrisMvKNPz2vq661qXwBTAQYKgJgXN2IFYFhFsgDxCAB8Cejwum36+gvE8OPo9F4EgGgzAcDuPfvOieN4w013j03JLntAz6PtSC6lVZg0Dg0EADH+xCwXpBdW0zSYF6/NFvzGetH5dRgGXjLE0lbTU986NW98WMRZ/f5HjxwZ2DRplgYAPpKzZwNGpSYah/AoABirAcD4XWioiaYOgCqAiFXdYK0mCoCng0vQa58hNUGG3ISNH32NdiPoFt4K8Zv2QULnIUjc9k9IuvVx4FxtNCDqpWvF0SSfqnXLfnnnWQXg4PkBTrzOFIgUgJ539CmzCDV1AAbs+7s0CuAaDAAdAsBqjQJQACANAIAD4tC8PjSyCymAPPfivXv3nrPIkaOiJdsgyAeMmuGqar+AQ3EFWJlzQpYb0guqyYhqOiGXBP0oABz+11xcBymZ0vs33nqbLvgMy7PP9CAAeCZe6rJqAMBrugG1LoAKgO0UAMdIM9BpABC+qhvE6uk4BYii/WYGALkJ0tHLjy6S/y4fxPz+eYjf8QUkdh2GxM1fQ9JV99AWaJ/y+nPOBhDsVWsHAfA/cGLjDIFJVhkDgBXSMN+Z5dERBEwMAJMQAD4iLgACwOqdeDGIgXNjAMTjGACFAIr888T4YxAAzMVHM/LcSw7sO/suADvVtW3xUcn5nSgFaqDNQcrwELphWQWAhAuc0gqqyZYbNiLbqfX9SdCPo4G/5Owy0KfnvXv3fffEDz3LRTCjR4wIbNIAQJD83RGcgnSy1WBe6gKQGIAWAHgiEC0FZgpAqJqG230tchMGQIbUCOlyE6RRAKSinYieWRDz9nbQd34DSV1HwLTxS0i+8Gck3iCrVYAIAEgBLP3lHYMA+KmfuHhjYLJVvlzPIQBoR20xN4CtDCMVddgFeGmjWgk4EAA0BoBWb6MbowCAugB57qUH9p87AFTUtOjHG7K6YtKK6SxE1fiVS2sdCAQIAHhHo2aLrQYADjK5Fhl/al4F2s4E+rTsdx7484NxQ4PP7o8xcvhwDADRPeFbXmqhC0WpO4IAhCHgIRCQ/QEwlnYDjtMMBBlDARC5shuEiqn4BSfG34RffGT8BABNkCz7wLjkHoje+gnouw5BYucRMLz7GaR4ryAjz+jYMwwAB2rnxQCIOqv/AgbP939iY3SBSYI0GwMAuwAO6gLICgBwDMDKALBUAQCpBOzAMQC8Kp1nZcBoNp+kvPxICcQoLkDJ0k8PnDsA1NRNMozTZ3aHJeRCnNlGuh8HtA0TANBqR6uMAcBRAPCa7TUMABzK+RdU4yGquvR8MKRlvfXXhx+NHfIflvx+1xkxbFigp/1SWXAhADTjoCPrPUDfBxo5ZmFKQKMARnSo3YB4M9AushgEAWAsA0D5FAwT5uunoU/Zi1//NASAyqkQ+egaiOv4GgxI/nceBd0beyC94kISNKRZAs7RQAFQOQiA/4UTgwAgUgBoXACtAjDQmgD0Ga4AYBsBAFoNdtcKDQAkPwAoGQCkACzEBfjswLkJAqJT1zDRiAAw3pQDkSn5oLM41FZhlg4UNCvRrDKk5lcRQ6dBP167vcbeiPb4QQJygTIKKQAy1z30yGMxwf9mu+//d4YPHRroab9EEuS2QxwFgFp9SGYOWvAnAoAHzGgi0JodGgBo1oP3AIym3YCRKygAsK9P5D6GAAVAqqsZEmfdCNEf7oH4rkNg3HUUTJ3HIPalzWApmagCAAMItT7XAVdcuX7ZL+8adAF+6icmJj4wSXDO1lEXQGss2nJaI525F96+FGJe3kSDgAQAqBcAASD+tArAoboAFhsFwLkLAtY1tBsYAMITcyA6rZC4AvTnMmomCTP3JjW/moypchAD45RXtwnNrYPknDI8RVlvLgR9RgEY0rPXPfL40zFn+3tHAPBOuNQpyBMOcWiUtqNJGTiC247R4BFnE2Q4yXAQi28uhK7ZASM7voWQ7hMqAHaR1WVaAIhl/gBIdTbilz9V8kBS3cUQufxdiOn6CnTdh8HQfRT0nccg7qF1wLtaqQvAhp+gRiAEgIr11/zq7kEA/NRPTHQ8dgF0VAGgvgGD6NQEAdWUoAKAlzbROgDqApyiAEgMIEaJATgUAKA04GcH9pwzADQ2thtCGQASciAiKQdi04vILESlU9CpKXc+FQAWFvW3N0JqQRWYUPaALGcFg6UITBm56x598pmzDoBhQ4YENk24xMnLbYcsaJuOw6NKfrZkhAYCcVNOMwHAqM5vIWTXAABQBYBu2PJOsJZdgH14HO13NuCbIjVBculkiLvlMYjaeRDidn0L+q4jYNjVC3Gdx8B0+7MYALzsUwHgYAqg4s3rbr7n/AHA7/54S8C1t9/7Q38bZ/3ExuoRAObEc44+HVtLLjqUnnqlLJi22IZPWAzRL39MXAAGgDuXg97CFAB9/U/rAtiOZuS6lnx+DhVAY+MECoBcrAAiErMhMiUP4s3FZEWaNhZAAZCSX6X09mMQ0IuafVCtgFGwg5G3gZFHa9qLwWTOXfvIE8+c9T/8Q4ODAz1tlzh5iQBAXaPVqF4nieLjppzmK2D8mu0wqvMwhOwi8wAZAEJ6+mH0HrLNKOKlbWAtmYT993RHA6TaGyDZ3ghJJZNBt+T3ELHxAMTs+hbiuo+AvrsX9D0nIGbbYUha8Fu8/YiXSeERLkVWAFD51s9uuf+sQ/BHe1a/tS7gvY/e+6G/jbN+qAKYE28hLoAOr9uSlFdSiQXQOXvhbQMB0IlLgXXfCQCHvwLIkc+tAmhqM4wzZnePT0AAyMYKAF0CARtdLab+bGj4qQoAYvh4tl9RLSRll5BgoeBQL2+HBC5/3SNPPXfWAYCq6jxtlzgsztZDFmcz9vuxz4+aj7DxMwB4cFUe75sDYa9uh9FdhyGUAoAsMyUXuQHoRi3vALFmNqS7L4C00qmQWnURpExcCtF/fhXCtn4JUd3fQkz3YYjvOgbx3SdA19MPMX//BLiWq3BLNE9bonE5sr1eAcANt/3+/FEA/6snNlYfxACgTA5iSzgZBKykog4BIAwDYDMpA15JAXDncgUAA/1/HAPgNAogR776s/27zxkAPJ42w3hjdndYQh5RAEkUAskoHpBPpiyz+gBUMmx1QXJeJTb+DDrXL6OoDpJzSiEBpQlRulAk9QMJogQJohOShMJ1Tzz3YnRQ4NmdZ4kKi+pbLrJxzrZDZofXDwD4a5YFkAkABO9sCH9lKwYAWgYS1q0uPCEqgAAgbPsx0L+9D3TrekC/tgdi3twPkR98DRE7j0JE5xGI6jgCMZ1HcVdkbE8fxO8G0D+8AYTSC0DEbdEtJA6A5ggiBWBDAKhaf8MdgwD4yR+UBUgUnHPiLXYaBFQXbxpEdboO+hp19YW3Xg0xL20G3cptYFiJpgJ34W5ADADF/6cxAJr+i9EEAc058tWf7Nt1zgDg9U0whCXkdIUl5kF4Ui42/nB6EQRi0wvJcBTWOowAoHEB0Gw/lO9PRAtSRZnUCtCUIcoEJGXKkJppf+OZF18+6ykwNPi11jsjn3O2fo326CEomVn+n35ytAYAVebxTbMgevVmGNt9BAMAzwLwAwBSASgrcBLCdx2HcNQvgCYHdfTC+A70eQxDIHLnMYhG69K7TkDk7n6I6uiFtGV/BrF0IoglbbgTkExEIgs9UU2EpahyzfW3/+H83ujzv3CQAkgUpCtUBWD3W75JAmcOXEaL1EFE62KIfmkzGNDrv4IAIP7O07gAvDYLYCe9AKgOIEdefGBP1zkDQEvLRH10SmFXRHIBhCciAOQS48dKIBuiUnIhNqOIjElDKoABwEZe/7SCKkjKckOC1YUNHl3WOIT+flpOKZjz5DdeWLHq7AMgMCigvOGCTM7R/JnF7iXuCDZ8jzrAk7UCo67F+osh/oX3IbT7KIzb3QcRu8iE4/EaCBB3oA8HCUO6eyGk6ziEdhyH0J29MH5nL4TvOA4RO9H6NDJRGE1DjtjwCfATl4C1tJ1sA2KLSnFwtIFAoLjqmZ/ffnfI2f53MHi+5xMbcyoAyNpthxIQNNA2WgyAtiUQ/dIW0K3YhgGgW4W2A68kQUClBoAG/ziHcpkCsORKS/bt3nnOANDaNkkfl1bcGZNeDBHJBADMBYhIzsY3KjUP4tBmJJ64Acl5BABowAeS/okIAEgBWF1gwlfGiiAVGX9hJXCFpeteXvXqWZe/CAAl1ZPNZptnNwoAYkWiAMCjzCYgy0GagauYAsY/rIDxHYchrOckHneOZxt2+a83J5/9ENp1EkI7T0JoxwkI3XkCxu04AeN3nMR3XCdakAowvrMX9Hc8D9aKqQQA7gnA0S1FFtwJ2YSrJjOlhvtLqmpGnu1/B4Pnez4xMfqgJFGaS4KAdIEodQEGXjTgEwUBo17cDLoV20G3fDvoVnVD3B1IAchkBBgtAVaj/3a/QiBLjrR0X8+OcwaAttbJhrh0WyeagBSVWkAAkJyj3Eh0U3IgOjUP4tGCVNFNYgDF9ZCSV44DfwQA5KJSYQSD5KwStPADeHsNCMXl65evfu2cRMALpSYTb/ds5h1EAXBK7b8HG6GAG4R8eFGJpWQCJM2/C0Le/xzCunshopusP/NbesIu24XY1Q+hnf0QurMPQnf2Q+iOfgjZSdahhezuh7DXu8DqvQIvAhVK0Hi0NmCtyaw4SnA2Qq6r6WqdMWFwHNBP/cRE64KSRHkuSQM6VAWA6gEEcnUi+ntkvHd462KIfHEzxC3fBrrlOyAeKYA7UBqQrgMbCADaChzD2SkAnEv39Ww/Z39wJrZfYIhNK+5Eo9BQKXB0aj5EJufSqwIgKiUHYtLz8Zj05NwKLP2Tc0ooAMhNwNcNSVklkJ5fCZytDgRHHYjFFeuWv/L6OQmApWXwYaLT+5SgbNNtUhaD8Hh7jw/I5mC0pKMF0usvg7BnPoLx2w9DePdJiOjsJ4tQu8j+QxYYHK9Zex7aQS8y/A6AMV10FdrmbyB90f1gRb6/ewIIbmb8dCqyg5RGi87Gvny5aULo+HGDW31+6ic6Wof2AszVZgGUVeJaBYC3+9ggvGUxRLywGWKXb4e4lxEAuiHu9pcxAJgC0Bb/xHJ2JRWIm4FynEv392w7ZwBon6gCAI1DQ/l/DIEUAoCoZGL8USnIFUDxgEL84qfklkFSTim+iRgCpfgmZZVCWl4lWvoBvL0eBEc9ZNoq165c88Y5AUB8fFywKHnmCA7PMd5Bh5DQBSFkUpEPyMhwAgGz3AqmWbdC6Po9ELbzOIR19ZFtR12arUfsouUnnQDj6EUr0MfS9ech2w9Dyh3PQ1b5JLC60XSkNuDkVlAWlDjJam+02Vew139W13Lhf7b8YPD8uE50VFxQAgMAHh9uJ8bP22lKkBi/gScbfsN8i2D885sh6uXtEP3yDohBALj1JUAGhwASPyD/H0uXgmAFYC4+asl1LtndveXcKYCJU4yx6TYMALZkFUEA+f0IAlEpOZqbCzFpebjqMSmbGD/6TKQ3KbsMUqnxo8CX4GgAkQHg9bXnLAXWOvXybNHp3SE6fSA4mfH7NBcBoJl8Or2QLrVA7JLfw6gNn8L4Hcex0eO7i6w8w3sPu0+zDp32DIRs+gZSf/E4ZFVdCJmoDVluxcbPKcbvxddiJxAQ7PWrfn7jdWHn6ucfPN/jiY6MC0oUZRwEJOvEbcT4BTs2aOwCCHaqAOwQ6b0KQp/bgvfNoY0zqNPMcDMCAFMA/hWAaC8gCwQyAOzt+vicAWDy5KmmuHR7FxqEamAbkRGEMgrxi68afzb+jE7NxW6A1ugTc8qI8edW4poA1A3IYwA0guhoAKutcu0ra9efMwDcdeM9I3NcLU9bJR+IeCqQzw8AAr1kajAxzozSdohF8YDl22D8tqMQ0XUSwrv78Y6AcDoibJzmhqH04M7jELKqA1IW3geZ5ReAlRo/WU1OpxI7ie9vdiirvY9muz1XvPHWi4Py/3/hREUiBSBfEWexUwVgI3EAekn5LFEASBFEN8yB4U9+AKHPbIKw5zZD+LObwXD9UxCPthHzA0aBMRWgcQEQAPZ1n2MAZDi60HZkugWJrERHrkh6/gAFkIOhgOId2O+nxo9uSm4FXvqBmoFQTwCaCYCCXwIGQNXaV9a+eU6LYPLL2udbpeajVjSmHL/25OVXjJ/BgAFCIsM905tmg/HW5yBy5XYI2XAAxm48CKO3fA2jth2CEVv+CSM++hJGbvgUQl7eCnE3PAJc4+VgLZkAotRMXn6JLSUlLz+eP0A3IZlt6Nbvzitt5c/lzz54vscTGRFLFQACgA27ADrF+LVxABII1OVVQmzNdNDVTQddzTSIq7wA9IUNZPcAAgDvvw8glu0E4MhQUC5XWrL3HAJgEgFAt56TVQVAQaCzFGPJrxh/MgOAk/j8VAUk55RDekEN3mWPI/EIAHheAIHA9wGAxinzk6xS89tWuaVflFo0EGAAYDBAgUEVDGingVg2EcS6mWBpXwDJl94A+oW3Q+zi34Bu3q2QcNH1kNY6H/iqC3GkH/n7Inr50dgvvACVrj93sqCfh1RJ4tXn9Sd4W919V11/65hz+bMPnu/xRIbHIAWAYwDYiDUAwJ2BPDF85AqgoZom0Q5GwQYm1ByDuuOQy8ARd4HsAWAbgUgdgLIhGO8FsB3lcqQlB3rOXQxg0uRpCRgAaFUY3h6MrkOFAA4K5ioAGOgCJGeXQhoqDCqux9KfNQYpE4OQG2A/9wCYv2B+kKPuQl+Wq/UIkuaiMiOw2c8NIDDwKiPNRVcLWN0tkOluhcySNnJL28Ba0ob/Prmt5NchWLiI8ZOsgrr+3EJ3IDDjTy9GdRJ1/6hunZly3Y0/P5c/+uD5Pk9EWHSQSZTnIQWgAIBjACDGr9YGOJVuOrJcg1QM6tgiUPoZx7FdAOp+QDIW3HaUy5OX7t91LhUABsAuPe/C9f5+o8AEAgEcD2AASMnFKgHJfxQATMktxwNALLZG5fXntABACsBevXb1G+cWAOhcdNmi8OySCY9Y5ZY+pgJYPEAxfPzq+5SFJoK7BQR3K/4USzQX7QV0N4OI/r6bGD3bgISDibjlF3X8MZ+frkDDxl8PaYV131qlxiuuXrro7E5BGTw/7IkIiwpKFBAAkAJAuX7aMUcBYKA1Af5FQaRrUEc/43n/q7z6igKQqAKwH+Xz5GWf9Gw+d2nASVP8ADAQAri2AccDCkgQMCUPQwwF/dDrn1FU49cSrBi/MjIMKYDqtatfP3dBQO2pnzA7J1Nu7sbBQGcz9tVR4I/FAbDx43Vm9CoAaCW9/O4WvPGIXB/deqTGFHgaTOQk/9efNEc14pc/tbDueEZx7YPeabPO7hz0wfPDn4jw6KBE0TUvzqwCIJ4aP3EF1JoAHb1YCfDqX7PaAbyEdIDsj+dUFUAUgOuaT3s2/dsAeG7Vy2f06yZMnJIQZ3Z2awFgwlcFgBF//2pQELkJyPjNRTVkCg+ee0f677kBMQAKgPWrXlv/vfTCP/bCy8FFVRfMFSXfN4KTQIAF/sjr30ylPzV+9LJToyefdMchHuvtf5XMAq0zYCvQ8dARZPy2ekgrqoWMgsrXS2pbk6LCxn0fP/Lg+T5PeFhUUJLomh+nUQDYBeC0AKCKgBo7DgYqCoD9fbvy+scrQUCnGhPgsAI4xheUXPfZ3jMHwDW33xnwyltvB7y38bUz+vUTJk5NiFcAIINRYMtByGBQMhOQQcAGsWl5GA6o/58tAMFbeDTGzzEF4FAUwPrVr62PCQo493vxRo0YGTDzonljs0tarxccniMoLYdBIJHsAHv9RaYA6H5D/x2HPmW0N8+qCvHVGL5E/X46f5AE/er6Mgpr/pHprM555KmXBtN+/4sHxQCSRNcCJQhoYQBw+GcDaG0AA4FeY/jE+O3UBWCfEjZ6ZvyoOzDa7DjGF5Rdf/DAv68AzvQwAOgoAMhGYLokRNQMBqXrwlAQMzm7hK7eIi+8FgBsEg9HAYC64QR79Zur1iAAfH82MXnyzHE57uZFvKPpAIaAAoAWLOVFrRugkfmCZsEpruaTNKvOJLYmzKNKf5zvb0RB0GNcUc2ztgpf7rqPOgeN/3/1REbEBCWL7vnxFkc/AwBSAjpOvQQGNqU2gBi/6ib4A0Dj93PEBUAwiOWcGABiYfnPD+7feHY3amhOa/vpAKCJBSjGT/v8RSek5ldQeU+28BJDp8tAKAR4+tcMACteXfe9AQB1CaJz571/HVZYMbFVsDd+zDu9JwVap8+UgH+1oE+zXZgZuTrvkCwZoUNHHSzqj42/n7fVH7Taam6bMGVubGK08Xv5GQfPD3RiI2ODEkQXBkAcWiGO3QAHNX4bvnoMAZsSGCTXNsD4SbMQqSYk68AIANDXCABYAfSKRRW//GTP++cMAC0TpiTEW5zdesFNAUDXnAl0USj9RIafgPv8JUgrqDwFAIqh2DWxAA0AXn7lje9VAbDzt4cfGVLeOE3McbfeL0jeTwTJ14fjAU5UtecDnlXwsfp9avRs4KlZ+WxSJg7ha8dDUA9n2uvX5coNVW0TZ4Sif15g4OD67//pEx8VG5TASwv9AIBVgA10Fhvo6aeOAYDTQICzK2lDEjwkQUB2tS4AhoDZ0SsUVtz82d4PzhkAfK2TTXEWaZeOAsCoAQDbd2CiN4EuCMWbgU4BAM0CaF5+9inaa956YcWa2MAfAADoJMUnBkxfdOtIe4m3Ksfl/avoaNzHOxr6cYzC4aHlu16/8eZmBjN7E63oa8BVjrjeobj+mFBc/0aey7OgpLbdIJrTBiX/+XKMMbogI+ecH59h64/LsEE8goDZduqlsYH4Uy5pEoqzkF4B5Ebgr/0+HRBLft9eLq/s5nOpADzNkxLiFQC4FAAY2LYjOuMQ/X0EALQdmKwGYxuA6ditAdN4Oc0VHDXvPPfy6rgfCgDsbN70ccCMKZeHuGtbivJdniVWR93Tor3+A85W/wlna/gnZ2/otdjqT5qL6/syiupOmovrTpiL649Yiuq/tBRW91gKqtaJhZV/ynfWTW6eeKnx7t/8djDHf74dk94UaC2oKE8UHH9LEpxPJAnSk4mC8wl0E3jHEwm8/YkE3oavyf8+aeRsT5r44ifofTyBtz2WwNseTySfj5k4dIsfNVmKHjGZix4xZeQ/XCBV+D7b/e45+4PW6G1PRADwdwFk5fU30kvWg2sB0Oi3BVhxAfyCgEQB8Paad596fmX8Dw0A7XlzzYohv/vtfWNmzJoTV1bTki3kueoyshyzM21V13O2upvTiyp/lZbjWpae657K5bolT117+qIFV4W/9MJTI5OTEn48P8jg+f7P+mf/FnDLdVcGXXvtNUHXLrsuePGixcFXzVsUfOUV84OvumJ+8Pw5VwQvvOKK4IVz5gQvmrcgeOHcBcEL5y0MXjB3QfCC+VcGz5t/VfC8uVcFz19wVfDCK68OvnrxsuClS5YFX3fd9cHXXntd8A0/vyHo5l9cE3Tjr68JevCPN53Tn6XR056o4+QeDAA09ZcCQOsCGNmwT7oenO0GHLgKnFMUQIMaFCQA+McTz674UQFg8AyewRMQENDgmZCss8i7CQBYDED91G48NmEFQAFgb1Q3AjEFYFezAJxSHIS6A2s+ePTpl3WD5j94Bs+P7GAAcNIePY0B+Bk//lpSNgLheX/UBVCj/P7S36KpB9AA4KOHnnxRfz4D4LHnz6wyc/AMnu/1NPraU3ScvEePAoCC1vhV/1+JAaB7GgCwAKC2DoDUAjTQ3Xg1G//6xAuG8zlB9sRLL/3Q38LgGTynHk9ze6qOk/YyF4BlALTLTnEaUIkBuPBAUDzrXiP//RVAg+ICmB1oNVbN5j8/9rzxfFYAg2fw/CiPp6U9TcdJ+5ACYC6AfxqQuQAuxQVIVQCg2Q5sb1QbgjQXKwBbzbbf/+2ZhPNZAQyewfOjPI2+VrOec+4n9f+yEvX3SwMqMQCtAvAv/Dk1/09UAAKA2Vbdcd9fn0weBMDgGTw/slPb5BUNvONTPS351boA7K9JFkBSYgBMAfi/9AMVQINSB5Bhq+654Y7fpQ0CYPAMnh/Zqa5vKjLwji+0CsAgamHAegGIAjBRAFiQC2BvOK3s57UAsNcDZ6/d66qfzKFlnoNn8AyeH9GRyhuqDLz0Nfb3/SoBZdAzVwCtO7eqAEDNQBZNoO+US7fzKpOBHHWf5Lgb8wLP9n7wwTN4Bs9/fv74lz8E5LhqpxoE6VsCAJdfGbDBzyWQSSoQK4BKJQjIDF75VBqEmPEjJVD/ebarwRkYFDQIgMEzeH4s5/OvNgeJtqpbDKJ8grz+tBCITQYS1K5AI00DYhcgv9I/BkANXgsAwdGknQr0TaazzjtkyNBBAAyewfNjOXPnLow38Y61emzwLr9eAMOAXgCiAFxgynITAGD5jwZkDDB8etWvUbtt04lMufG+2pKy0T/0zzx4Bs//7Bk5dGjA0KCg4GFDgoeMHDpkyOhhw4aGjBo1fNzYsaNioiJHX3T5nJDq+va4TFt1Lp/rnm6y2J8z8M7DpA3YjVd/+/v/8oAgoIsGASvVSkCt7EdXYteDjR9fyQui7P0yv9TzoFzb3lrZMjOn3DtTXzdjQVj7vGtGp2WYRySajMPioiOHRISGBoeOHh08btSYQbUweAbPv3MqymtjEyz2WQmivDjJ6lqWnOn6RUqW6/7kLNcTydmu5SbR+YZJkDaaBOenJt5xxCRI/UaB+f7abkCiBvSsIpAFAWkxUIqiABoGGD8ydo/yib/Gs/gRANDePm+f4PQcEpxNnwnOpu28o+Ft0dn0Uqar+U+i7LtFkH3LBMl3FSd5FmRKDbUrVz0x7If+dzp4Bs9P5uTZ5OK4tMLP0aQinRmNJSOrvox04w8e901bfU2CDCbRha+RGr8RGb5VPk0g0KWJAbgpAP6vvXPrbeKI4jhfoEVV1ao4vsADTYjXlxQTO7F3ZtfEJjiJHa+DQ1so0I+F1EeCGmgo4tLQil64CLXlc7Rp1SdMX3E1M+fszqapSCXApP3/pKPZrAKKRpqzZ86cOX+66mst/r8ZC3GQaSegnIEXWVGNcsV05SE57Wxt+VmpHty/un7xrVHPKQB7hrKcL41N1raSWdOYlLX+Mvm4A4jMLHpV5qsXPhvt+cP2YAVTCMQRgMoB6Ft+dlswvehtR2A664b9+P1+qMlH0YA2kyPohe24cm6ghUU/8IOHt2+tobH+v+Dug921ggf/UWbrC6WxrPurUi02DkCQwg+LfVBzD+tYjxd6xnIA+jkflQTrSsCCFyYBD6s6ANGxWoP/gwOg8N8o6hgHUNBmZLyNlDc7gai/oDo9mKoH9+5sXt0/6jkFYM8w6y+UklmxlSSFX/P1Z21CTubx7b5o8R+0ooBMYacrwRQxFK1jQEF1AOwEvIASfir051zAiqXG249tB/T7UHDDRAGhE5DaAdy/fXMdDgCA3VLxTpaSVgSQCiMAqdV8DloiH+wI7AggFglQEjCqBPSGmSk/TAJm+TowNwb1THNQ7QjCRKCJAjgS4EVvW45UdpxYHiEYTtV7P9y4ceXNUc8pAHuGinfy6NgkOYCc7QA8kviy+/3L8OuethyAvfhTRU9bmpKD3BXocBgBLMc6A+dkzzoGjC9+7RDo5yg/YH39tSBHEHcAtzbeGPWcAvBSubj22b6HPz58If9XRZ4ojU26W6rVeJQHkFYyUG5T+4nu+5v9P33trVOAFP9cpGvBU76JACgJGFlgfcWDKLTnaMA3W4MwMmAVHlr87ATM+2BYrPfu3bh5DREAALulIprHxo6oUwBSKsqJMBeQZrVfzgtYDoD3+ikO9+k5s+04kHsC6OvAoQMIwkQg5wKUOdscgLPtiNAJF7v58jvbkoiFevDg2pfPzwFsfvvNq5lcAF53ym7jWGKitqXrALKRTiFvB/SpgK4LMA4gRaq/vD3Q7wrGWWy/EhxFANQPQFrXgGNCoZwPsHID1t6eF39odARoHyeqf5uv9x59sXH5uXUAm9/ffTWTC8DrznTtuHEAR4xaUYrqAVRBEDsAPWq1YqFlv82zWvhmTJOpBiEpUgcOVYKpGMhEADvIgElqFb7T1oDKhO3F7ljn/1FFITkAv/fT51cuvT3qOf0/sPHV9X1fw5Hufaar9XJivPpbYsI4gCRFAjoXEBofEbp68fP2QDsBdgZq8bM8OEUD0RZAHQO2Ygs/K5atlmDLVneguGiIvdAdOkHQ1X/2O2owmvd7jy+vX3pn1HMKwJ5hekZWE+Ozvx+YqA2VbqEuB84KY+QAlHKx3go4UX7ARAXGMaTIGaQ5TxCeFvCFoOPD8XKLuv10qS8AOQBuEmJfFbaecyJ+gchWFYokxs1Y8IPHa1fW3h31nAKwZyhVfJkYn/3jwER1qLYBiUkxHMvKYdKRw2SWtgJ0P8DkBfiZzdOWzrP5oWIwlw0fKhoH4LAAiBvsaE6sZXikHRiG/cIqASaFXn0SQJWARa/7eH3jKiIAAHbL0WNu7b33Z35JTFT/TE7WniYnxSCVFYO0YyyjR1dbJidCS5NlcnKQzsmnmTybN1B2sOANDhX9waGCsSMzrUFedAc50R04rhlzPMbtSU7aFugxry14kveCaPR62goyGBRk92lRLn93ffMO7gKAl8vtu5uj/hNeGBc+7O3vdFcbzVbQmmv1jtfnA+nPd6XX7Aiv2XZloy1EY0nIZlvIRtvVz40lfidls+2xeWo80fHovZRN9buLwm8uirlW4M4tnRJziytibqnvamuv1hrt1Wqzc7p6Yvn0LNnMfPBRZT74WFl5fuVM+eTK2YqyhZWz5YVTn5QXT52bXuifm17sny8v9c/PdFYvuJ3+ufrqmU/zj36+jy6iAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACA152/AErrexEnkMWlAAAAAElFTkSuQmCC";

  // src/ui/floating-menu.ts
  function formatTime(seconds) {
    if (isNaN(seconds) || seconds < 0) return "00:00";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) {
      return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }
  function parseTime(timeStr) {
    if (!timeStr) return 0;
    const parts = timeStr.trim().split(":").map(Number);
    if (parts.some(isNaN)) return 0;
    if (parts.length === 3) {
      return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    if (parts.length === 2) {
      return parts[0] * 60 + parts[1];
    }
    if (parts.length === 1) {
      return parts[0];
    }
    return 0;
  }
  var FloatingMenu = class {
    isVisible = false;
    menuEl = null;
    stateManager;
    lastTracksSignature = "";
    lastFavsSignature = "";
    currentModal = null;
    activeTab = "tracks";
    showOnlyFavorites = false;
    constructor(stateManager) {
      this.stateManager = stateManager;
      this.init();
    }
    init() {
      this.stateManager.subscribe(() => {
        if (this.isVisible && this.menuEl) {
          this.updateStateView();
          this.renderTrackList();
          if (this.activeTab === "favs") {
            this.updateActiveFavItemStyles();
          }
        }
      });
    }
    toggle() {
      this.isVisible = !this.isVisible;
      if (this.isVisible) {
        this.lastTracksSignature = "";
        this.lastFavsSignature = "";
        this.show();
      } else {
        this.hide();
      }
    }
    show() {
      this.isVisible = true;
      this.lastTracksSignature = "";
      this.lastFavsSignature = "";
      this.renderFull();
    }
    wrapperEl = null;
    hide() {
      this.isVisible = false;
      if (this.wrapperEl) {
        this.wrapperEl.remove();
        this.wrapperEl = null;
        this.menuEl = null;
      }
      this.closeModal();
    }
    renderFull() {
      const shadowRoot = ShadowHost.getInstance().mount();
      if (!shadowRoot) return;
      if (this.wrapperEl) {
        this.wrapperEl.remove();
      }
      const wrapper = document.createElement("div");
      wrapper.className = "tm-menu-wrapper";
      const borderLight = document.createElement("div");
      borderLight.className = "tm-border-light";
      const menu = document.createElement("div");
      menu.className = "tm-menu";
      ["click", "mousedown", "mouseup", "keydown", "keyup", "keypress"].forEach((evt) => {
        wrapper.addEventListener(evt, (e) => e.stopPropagation());
      });
      const controllerState = this.stateManager.videoController.getState();
      const currentTime = controllerState.currentTime;
      menu.innerHTML = `
      <div class="tm-header">
        <div class="tm-title-group">
          <div class="tm-logo-icon-wrap">
            <img src="${TM_LOGO_DATA_URI}" class="tm-logo-img" alt="TM" />
          </div>
          <span class="tm-logo-text">TRACKMARK</span>
          <span class="tm-author-tag">by <a href="https://github.com/daemon1s" target="_blank" rel="noopener noreferrer" class="tm-author-link">daemon1s</a></span>
        </div>
        <div class="tm-header-actions">
          <a href="https://github.com/daemon1s/trackmark" target="_blank" rel="noopener noreferrer" class="tm-header-icon-link" title="GitHub">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>
          </a>
          <button class="tm-btn-close" id="tm-close-btn" title="Close">\u2715</button>
        </div>
      </div>

      <div class="tm-tabs">
        <button class="tm-tab ${this.activeTab === "tracks" ? "active" : ""}" data-tab="tracks">Tracks</button>
        <button class="tm-tab ${this.activeTab === "favs" ? "active" : ""}" data-tab="favs">\u2605 Favorites</button>
        <button class="tm-tab ${this.activeTab === "detect" ? "active" : ""}" data-tab="detect">Detect</button>
        <button class="tm-tab ${this.activeTab === "boost" ? "active" : ""}" data-tab="boost">Audio & Equalizer</button>
        <button class="tm-tab ${this.activeTab === "storage" ? "active" : ""}" data-tab="storage">Storage</button>
      </div>

      <div class="tm-content-pane ${this.activeTab === "tracks" ? "active" : ""}" id="pane-tracks">
        <div class="tm-active-bar">
          <div class="tm-active-info">
            <div class="tm-active-title" id="tm-active-title">No track selected</div>
            <div class="tm-active-times" id="tm-active-times">Select or add a track below</div>
          </div>
          <button class="tm-toggle-loop" id="tm-loop-btn">
            Loop disabled
          </button>
        </div>

        <div class="tm-add-section">
          <div class="tm-inputs-row">
            <input type="text" class="tm-input tm-input-title" placeholder="Track title" id="tm-new-title" />
            <input type="text" class="tm-input tm-input-time" placeholder="Start" id="tm-new-start" value="${formatTime(currentTime)}" />
            <input type="text" class="tm-input tm-input-time" placeholder="End" id="tm-new-end" value="${formatTime(currentTime + 30)}" />
          </div>
          <button class="tm-btn-primary" id="tm-add-btn">
            + Save and loop
          </button>
        </div>

        <div class="tm-list-bar">
          <span class="tm-list-count" id="tm-list-count">All tracks</span>
          <button class="tm-btn-filter-fav ${this.showOnlyFavorites ? "active" : ""}" id="tm-filter-favs-btn" title="Show only favorites">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="${this.showOnlyFavorites ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
            <span>Favorites only</span>
          </button>
        </div>

        <div class="tm-list" id="tm-track-list"></div>
      </div>

      <div class="tm-content-pane ${this.activeTab === "favs" ? "active" : ""}" id="pane-favs">
        <div class="tm-favs-header">
          <div class="tm-title-with-info">
            <span class="tm-favs-header-title">\u2B50 Global favorites</span>
            <div class="tm-info-tooltip-wrap">
              <span class="tm-info-icon">\u2139\uFE0F</span>
              <div class="tm-tooltip-content">
                <strong>How do global favorites work?</strong><br/>
                \u2022 Shows your favorite tracks and loops across all videos.<br/>
                \u2022 Click any track to open that video at the exact timestamp.<br/>
                \u2022 If you are already on that video, it jumps and loops immediately.
              </div>
            </div>
          </div>
          <span class="tm-favs-count-badge" id="tm-favs-total-count">0 tracks</span>
        </div>

        <div class="tm-list tm-favs-list" id="tm-favs-list">
          <div class="tm-empty">Loading favorites...</div>
        </div>
      </div>

      <div class="tm-content-pane ${this.activeTab === "detect" ? "active" : ""}" id="pane-detect">
        <div class="tm-tools-panel">
          <div class="tm-tool-card">
            <span class="tm-tool-title">\u26A1 Auto-detect tracks</span>
            <span class="tm-tool-desc">Extract songs and timestamps from description and comments with one click.</span>
            <button class="tm-btn-action" id="tm-scan-btn">Scan metadata</button>
          </div>

          <div class="tm-tool-card">
            <span class="tm-tool-title">\u{1F4CB} Paste timestamps</span>
            <span class="tm-tool-desc">Paste any text with timestamps to parse them automatically.</span>
            <button class="tm-btn-action" id="tm-paste-btn">Paste text</button>
          </div>

          <div class="tm-tool-card">
            <span class="tm-tool-title">\u{1F5D1}\uFE0F Clear track list</span>
            <span class="tm-tool-desc">Delete all detected or imported tracks from this video with one click.</span>
            <button class="tm-btn-action tm-btn-danger" id="tm-clear-all-btn">Clear all tracks</button>
          </div>
        </div>
      </div>

      <div class="tm-content-pane ${this.activeTab === "boost" ? "active" : ""}" id="pane-boost">
        <div class="tm-boost-panel">
          <div class="tm-eq-section">
            <div class="tm-section-header">
              <div class="tm-title-with-info">
                <span class="tm-boost-label">\u{1F39B}\uFE0F Graphic equalizer</span>
                <div class="tm-info-tooltip-wrap">
                  <span class="tm-info-icon">\u2139\uFE0F</span>
                  <div class="tm-tooltip-content">
                    <strong>How does the equalizer work?</strong><br/>
                    \u2022 <strong>60Hz - 150Hz:</strong> Bass and sub-bass.<br/>
                    \u2022 <strong>400Hz - 1kHz:</strong> Midrange body and vocals.<br/>
                    \u2022 <strong>2.4kHz - 15kHz:</strong> Treble, presence and brightness.<br/>
                    Adjust the vertical sliders (-12dB to +12dB) or select a genre preset.
                  </div>
                </div>
              </div>
              <button class="tm-btn-reset-eq" id="tm-reset-eq-btn" title="Reset to flat">Reset</button>
            </div>

            <div class="tm-preset-select-wrap">
              <select class="tm-preset-select" id="tm-eq-preset-select">
                <option value="flat">Flat / Default</option>
                <option value="bass_boost">\u{1F525} Bass boost</option>
                <option value="electronic">\u26A1 Electronic / Dance</option>
                <option value="rock">\u{1F3B8} Rock / Metal</option>
                <option value="pop">\u{1F3A4} Pop</option>
                <option value="hiphop">\u{1F3A7} Hip-Hop / R&B</option>
                <option value="vocal">\u{1F399}\uFE0F Vocal clarity / Podcast</option>
                <option value="acoustic">\u{1F3BB} Acoustic / Classical</option>
                <option value="treble_boost">\u2728 Treble boost</option>
                <option value="custom" disabled>Custom (manual adjustment)</option>
              </select>
            </div>

            <div class="tm-eq-rack">
              <div class="tm-eq-col">
                <span class="tm-eq-val" id="tm-eq-val-0">0dB</span>
                <input type="range" min="-12" max="12" step="1" value="0" class="tm-slider-v" data-band="0" />
                <span class="tm-eq-freq">60Hz</span>
              </div>
              <div class="tm-eq-col">
                <span class="tm-eq-val" id="tm-eq-val-1">0dB</span>
                <input type="range" min="-12" max="12" step="1" value="0" class="tm-slider-v" data-band="1" />
                <span class="tm-eq-freq">150Hz</span>
              </div>
              <div class="tm-eq-col">
                <span class="tm-eq-val" id="tm-eq-val-2">0dB</span>
                <input type="range" min="-12" max="12" step="1" value="0" class="tm-slider-v" data-band="2" />
                <span class="tm-eq-freq">400Hz</span>
              </div>
              <div class="tm-eq-col">
                <span class="tm-eq-val" id="tm-eq-val-3">0dB</span>
                <input type="range" min="-12" max="12" step="1" value="0" class="tm-slider-v" data-band="3" />
                <span class="tm-eq-freq">1kHz</span>
              </div>
              <div class="tm-eq-col">
                <span class="tm-eq-val" id="tm-eq-val-4">0dB</span>
                <input type="range" min="-12" max="12" step="1" value="0" class="tm-slider-v" data-band="4" />
                <span class="tm-eq-freq">2.4kHz</span>
              </div>
              <div class="tm-eq-col">
                <span class="tm-eq-val" id="tm-eq-val-5">0dB</span>
                <input type="range" min="-12" max="12" step="1" value="0" class="tm-slider-v" data-band="5" />
                <span class="tm-eq-freq">15kHz</span>
              </div>
            </div>
          </div>

          <div class="tm-boost-section">
            <div class="tm-section-header">
              <div class="tm-title-with-info">
                <span class="tm-boost-label">\u{1F50A} Volume booster</span>
                <div class="tm-info-tooltip-wrap">
                  <span class="tm-info-icon">\u2139\uFE0F</span>
                  <div class="tm-tooltip-content">
                    <strong>How does the volume booster work?</strong><br/>
                    \u2022 <strong>100% - 600%:</strong> Boosts audio above YouTube's native maximum.<br/>
                    \u2022 <strong>Limiter compressor:</strong> Prevents distortion when increasing gain.<br/>
                    Toggle the booster and select a level with quick buttons.
                  </div>
                </div>
              </div>
            </div>

            <div class="tm-boost-controls">
              <button class="tm-btn-preset" data-boost="1">100%</button>
              <button class="tm-btn-preset" data-boost="1.5">150%</button>
              <button class="tm-btn-preset" data-boost="2">200%</button>
              <button class="tm-btn-preset" data-boost="3">300%</button>
              <button class="tm-btn-preset" data-boost="4">400%</button>
              <button class="tm-btn-preset" data-boost="6">600%</button>
            </div>

            <div class="tm-boost-status">
              <span class="tm-boost-value-label" id="tm-boost-val-label">100% (disabled)</span>
              <button class="tm-btn-toggle-boost" id="tm-boost-toggle">Enable booster</button>
            </div>
          </div>
        </div>
      </div>

      <div class="tm-content-pane ${this.activeTab === "storage" ? "active" : ""}" id="pane-storage">
        <div class="tm-tools-panel">
          <div class="tm-tool-card">
            <div class="tm-title-with-info">
              <span class="tm-tool-title">\u{1F4BE} Local storage</span>
              <div class="tm-info-tooltip-wrap">
                <span class="tm-info-icon">\u2139\uFE0F</span>
                <div class="tm-tooltip-content">
                  <strong>How does storage work?</strong><br/>
                  \u2022 <strong>100% local:</strong> Your tracks and loops are saved in <code>chrome.storage.local</code> in your browser.<br/>
                  \u2022 <strong>Full privacy:</strong> No data leaves your machine or is sent to external servers.<br/>
                  \u2022 <strong>Persistent:</strong> Not cleared when closing YouTube or restarting your machine.
                </div>
              </div>
            </div>
            <span class="tm-tool-desc">All your loop markers and track marks are stored offline directly in your browser's private storage.</span>
          </div>

          <div class="tm-tool-card">
            <div class="tm-title-with-info">
              <span class="tm-tool-title">\u{1F504} Backup & Transfer</span>
              <div class="tm-info-tooltip-wrap">
                <span class="tm-info-icon">\u2139\uFE0F</span>
                <div class="tm-tooltip-content">
                  <strong>Export & Import JSON:</strong><br/>
                  Export a <code>.json</code> file to create backups of all your tracklists or migrate them to another browser in seconds.
                </div>
              </div>
            </div>
            <span class="tm-tool-desc">Create portable backup files or restore your saved library across different devices.</span>
            <div class="tm-tools-row">
              <button class="tm-btn-action" id="tm-export-btn" style="flex: 1;">Export JSON</button>
              <button class="tm-btn-action" id="tm-import-btn" style="flex: 1;">Import JSON</button>
              <input type="file" id="tm-import-file" accept=".json" style="display: none;" />
            </div>
          </div>
        </div>
      </div>
    `;
      wrapper.appendChild(borderLight);
      wrapper.appendChild(menu);
      shadowRoot.appendChild(wrapper);
      this.wrapperEl = wrapper;
      this.menuEl = menu;
      this.bindStaticEvents();
      this.renderTrackList();
      this.updateStateView();
    }
    bindStaticEvents() {
      if (!this.menuEl || !this.wrapperEl) return;
      const header = this.menuEl.querySelector(".tm-header");
      if (header && this.wrapperEl) {
        let isDragging = false;
        let startMouseX = 0;
        let startMouseY = 0;
        let initialLeft = 0;
        let initialTop = 0;
        const onMouseDown = (e) => {
          const target = e.target;
          if (target.closest("#tm-close-btn") || target.closest("a") || target.closest("button")) return;
          isDragging = true;
          startMouseX = e.clientX;
          startMouseY = e.clientY;
          const parentRect = this.wrapperEl.offsetParent?.getBoundingClientRect() || { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight };
          const wrapperRect = this.wrapperEl.getBoundingClientRect();
          initialLeft = wrapperRect.left - parentRect.left;
          initialTop = wrapperRect.top - parentRect.top;
          this.wrapperEl.style.bottom = "auto";
          this.wrapperEl.style.right = "auto";
          this.wrapperEl.style.left = `${initialLeft}px`;
          this.wrapperEl.style.top = `${initialTop}px`;
          window.addEventListener("mousemove", onMouseMove, { capture: true });
          window.addEventListener("mouseup", onMouseUp, { capture: true });
          e.preventDefault();
        };
        const onMouseMove = (e) => {
          if (!isDragging || !this.wrapperEl) return;
          const dx = e.clientX - startMouseX;
          const dy = e.clientY - startMouseY;
          const parentEl = this.wrapperEl.offsetParent || document.body;
          const parentWidth = parentEl.clientWidth || window.innerWidth;
          const parentHeight = parentEl.clientHeight || window.innerHeight;
          const menuWidth = this.wrapperEl.offsetWidth || 420;
          const menuHeight = this.wrapperEl.offsetHeight || 400;
          const maxLeft = Math.max(0, parentWidth - menuWidth);
          const maxTop = Math.max(0, parentHeight - menuHeight);
          const clampedLeft = Math.max(0, Math.min(maxLeft, initialLeft + dx));
          const clampedTop = Math.max(0, Math.min(maxTop, initialTop + dy));
          this.wrapperEl.style.left = `${Math.round(clampedLeft)}px`;
          this.wrapperEl.style.top = `${Math.round(clampedTop)}px`;
        };
        const onMouseUp = () => {
          if (isDragging) {
            isDragging = false;
            window.removeEventListener("mousemove", onMouseMove, { capture: true });
            window.removeEventListener("mouseup", onMouseUp, { capture: true });
          }
        };
        header.addEventListener("mousedown", onMouseDown);
      }
      this.menuEl.querySelector("#tm-close-btn")?.addEventListener("click", () => this.hide());
      this.menuEl.querySelectorAll(".tm-tab").forEach((tabBtn) => {
        tabBtn.addEventListener("click", () => {
          const tab = tabBtn.dataset.tab;
          if (tab) {
            this.activeTab = tab;
            this.menuEl?.querySelectorAll(".tm-tab").forEach((t) => t.classList.remove("active"));
            tabBtn.classList.add("active");
            this.menuEl?.querySelectorAll(".tm-content-pane").forEach((p) => p.classList.remove("active"));
            this.menuEl?.querySelector(`#pane-${tab}`)?.classList.add("active");
            if (tab === "favs") {
              this.lastFavsSignature = "";
              this.renderFavsList();
            }
          }
        });
      });
      const filterFavBtn = this.menuEl.querySelector("#tm-filter-favs-btn");
      filterFavBtn?.addEventListener("click", () => {
        this.showOnlyFavorites = !this.showOnlyFavorites;
        filterFavBtn.classList.toggle("active", this.showOnlyFavorites);
        const svg = filterFavBtn.querySelector("svg");
        if (svg) {
          svg.setAttribute("fill", this.showOnlyFavorites ? "currentColor" : "none");
        }
        this.renderTrackList();
      });
      this.menuEl.querySelector("#tm-loop-btn")?.addEventListener("click", async () => {
        await this.stateManager.toggleLoop();
      });
      const addBtn = this.menuEl.querySelector("#tm-add-btn");
      addBtn?.addEventListener("click", async () => {
        const titleInput = this.menuEl?.querySelector("#tm-new-title");
        const startInput2 = this.menuEl?.querySelector("#tm-new-start");
        const endInput2 = this.menuEl?.querySelector("#tm-new-end");
        const title = titleInput?.value.trim() || `Track @ ${startInput2?.value || "00:00"}`;
        const startTime = parseTime(startInput2?.value || "00:00");
        let endTime = parseTime(endInput2?.value || "00:00");
        if (endTime <= startTime) {
          endTime = startTime + 30;
        }
        const created = await this.stateManager.addTrack({
          title,
          startTime,
          endTime,
          isFavorite: false
        });
        if (created) {
          if (titleInput) titleInput.value = "";
          if (startInput2) startInput2.value = formatTime(endTime);
          if (endInput2) endInput2.value = formatTime(endTime + 30);
          await this.stateManager.selectTrack(created.id, true);
          await this.stateManager.setLoop(true);
          this.renderTrackList();
        }
      });
      const videoEl = this.stateManager.videoController.getVideoElement();
      const booster = this.stateManager.audioBooster;
      const presetSelect = this.menuEl.querySelector("#tm-eq-preset-select");
      presetSelect?.addEventListener("change", () => {
        if (videoEl) booster.init(videoEl);
        const presetId = presetSelect.value;
        booster.setPreset(presetId);
        this.updateEqUI();
      });
      this.menuEl.querySelector("#tm-reset-eq-btn")?.addEventListener("click", () => {
        if (videoEl) booster.init(videoEl);
        booster.resetEq();
        this.updateEqUI();
      });
      this.menuEl.querySelectorAll(".tm-slider-v").forEach((slider) => {
        slider.addEventListener("input", () => {
          if (videoEl) booster.init(videoEl);
          const bandIndex = Number(slider.dataset.band);
          const gainVal = Number(slider.value);
          booster.setBandGain(bandIndex, gainVal);
          this.updateEqUI();
        });
      });
      this.menuEl.querySelectorAll(".tm-btn-preset").forEach((btn) => {
        btn.addEventListener("click", () => {
          if (videoEl) booster.init(videoEl);
          const multiplier = Number(btn.dataset.boost);
          booster.setBoost(multiplier);
          booster.setEnabled(true);
          this.updateBoostUI();
        });
      });
      this.menuEl.querySelector("#tm-boost-toggle")?.addEventListener("click", () => {
        if (videoEl) booster.init(videoEl);
        booster.setEnabled(!booster.getIsEnabled());
        this.updateBoostUI();
      });
      this.menuEl.querySelector("#tm-scan-btn")?.addEventListener("click", () => {
        this.handleAutoScan();
      });
      this.menuEl.querySelector("#tm-paste-btn")?.addEventListener("click", () => {
        this.handlePasteTracklist();
      });
      this.menuEl.querySelector("#tm-clear-all-btn")?.addEventListener("click", async () => {
        if (confirm("Are you sure you want to delete all tracks for this video?")) {
          await this.stateManager.clearAllTracks();
          this.renderTrackList();
          this.updateStateView();
        }
      });
      this.menuEl.querySelector("#tm-export-btn")?.addEventListener("click", async () => {
        await BackupManager.exportBackup();
      });
      const fileInput = this.menuEl.querySelector("#tm-import-file");
      this.menuEl.querySelector("#tm-import-btn")?.addEventListener("click", () => {
        fileInput?.click();
      });
      fileInput?.addEventListener("change", async () => {
        const file = fileInput.files?.[0];
        if (file) {
          const res = await BackupManager.importBackup(file);
          alert(res.message);
          if (res.success) {
            const vid = this.stateManager.getVideoData()?.videoId;
            if (vid) {
              await this.stateManager.loadVideoData(vid);
              this.renderTrackList();
            }
          }
        }
        fileInput.value = "";
      });
      const startInput = this.menuEl.querySelector("#tm-new-start");
      startInput?.addEventListener("dblclick", () => {
        startInput.value = formatTime(this.stateManager.videoController.getCurrentTime());
      });
      const endInput = this.menuEl.querySelector("#tm-new-end");
      endInput?.addEventListener("dblclick", () => {
        endInput.value = formatTime(this.stateManager.videoController.getCurrentTime());
      });
      this.updateEqUI();
      this.updateBoostUI();
    }
    updateEqUI() {
      if (!this.menuEl) return;
      const booster = this.stateManager.audioBooster;
      const gains = booster.getGains();
      const currentPreset = booster.getCurrentPreset();
      const presetSelect = this.menuEl.querySelector("#tm-eq-preset-select");
      if (presetSelect) {
        presetSelect.value = currentPreset;
      }
      gains.forEach((gain, i) => {
        const valLabel = this.menuEl?.querySelector(`#tm-eq-val-${i}`);
        const slider = this.menuEl?.querySelector(`.tm-slider-v[data-band="${i}"]`);
        if (valLabel) {
          valLabel.textContent = `${gain > 0 ? "+" : ""}${gain}dB`;
          valLabel.classList.toggle("active", gain !== 0);
        }
        if (slider && Number(slider.value) !== gain) {
          slider.value = String(gain);
        }
      });
    }
    updateBoostUI() {
      if (!this.menuEl) return;
      const booster = this.stateManager.audioBooster;
      const percent = Math.round(booster.getBoost() * 100);
      const enabled = booster.getIsEnabled();
      const label = this.menuEl.querySelector("#tm-boost-val-label");
      if (label) {
        label.textContent = enabled ? `${percent}%` : "100% (disabled)";
      }
      const toggle = this.menuEl.querySelector("#tm-boost-toggle");
      if (toggle) {
        toggle.textContent = enabled ? "Disable booster" : "Enable booster";
        toggle.classList.toggle("active", enabled);
      }
      this.menuEl.querySelectorAll(".tm-btn-preset").forEach((btn) => {
        const b = Number(btn.dataset.boost);
        btn.classList.toggle("active", enabled && Math.round(b * 100) === percent);
      });
    }
    handleAutoScan() {
      const duration = this.stateManager.videoController.getDuration();
      const result = TracklistExtractor.extractFromDOM(duration);
      if (result.tracks.length === 0) {
        alert('No timestamps found in description or comments.\nYou can use "Paste text" to add them manually.');
        return;
      }
      this.showPreviewModal(result.sourceLabel, result.tracks);
    }
    handlePasteTracklist() {
      if (!this.menuEl) return;
      this.closeModal();
      const modal = document.createElement("div");
      modal.className = "tm-modal-view";
      modal.innerHTML = `
      <div class="tm-modal-header">
        <div class="tm-modal-title">Paste tracklist</div>
        <button class="tm-btn-close" id="tm-modal-close">\u2715</button>
      </div>
      <div class="tm-modal-body">
        <span style="font-size: 10px; color: #71717a;">Paste text with timestamps (e.g. 01:23 Song Title):</span>
        <textarea class="tm-textarea" id="tm-paste-area" placeholder="00:00 Intro&#10;03:45 Artist - Track 1&#10;08:20 Artist - Track 2..."></textarea>
      </div>
      <div class="tm-modal-footer">
        <button class="tm-btn-secondary" id="tm-paste-cancel">Cancel</button>
        <button class="tm-btn-primary" id="tm-paste-parse">Parse tracks</button>
      </div>
    `;
      this.menuEl.appendChild(modal);
      this.currentModal = modal;
      modal.querySelector("#tm-modal-close")?.addEventListener("click", () => this.closeModal());
      modal.querySelector("#tm-paste-cancel")?.addEventListener("click", () => this.closeModal());
      modal.querySelector("#tm-paste-parse")?.addEventListener("click", () => {
        const area = modal.querySelector("#tm-paste-area");
        const text = area?.value.trim() || "";
        const duration = this.stateManager.videoController.getDuration();
        const tracks = parseTracklistText(text, duration);
        if (tracks.length === 0) {
          alert("No timestamps could be detected in the pasted text.");
          return;
        }
        this.showPreviewModal(`Pasted text (${tracks.length} tracks)`, tracks);
      });
    }
    showPreviewModal(title, candidates) {
      if (!this.menuEl) return;
      this.closeModal();
      const modal = document.createElement("div");
      modal.className = "tm-modal-view";
      modal.innerHTML = `
      <div class="tm-modal-header">
        <div class="tm-modal-title">${title}</div>
        <button class="tm-btn-close" id="tm-modal-close">\u2715</button>
      </div>
      <div class="tm-modal-body">
        <div style="display: flex; flex-direction: column; gap: 4px;">
          ${candidates.map((c, i) => `
            <div class="tm-preview-item">
              <input type="checkbox" checked data-index="${i}" class="tm-preview-check" />
              <div class="tm-preview-title">${c.title}</div>
              <div class="tm-preview-time">${formatTime(c.startTime)} - ${formatTime(c.endTime)}</div>
            </div>
          `).join("")}
        </div>
      </div>
      <div class="tm-modal-footer">
        <button class="tm-btn-secondary" id="tm-modal-cancel">Cancel</button>
        <button class="tm-btn-primary" id="tm-modal-import">
          Import selected (${candidates.length})
        </button>
      </div>
    `;
      this.menuEl.appendChild(modal);
      this.currentModal = modal;
      modal.querySelector("#tm-modal-close")?.addEventListener("click", () => this.closeModal());
      modal.querySelector("#tm-modal-cancel")?.addEventListener("click", () => this.closeModal());
      modal.querySelector("#tm-modal-import")?.addEventListener("click", async () => {
        const checkboxes = modal.querySelectorAll(".tm-preview-check:checked");
        const selected = [];
        checkboxes.forEach((cb) => {
          const idx = Number(cb.dataset.index);
          if (candidates[idx]) {
            selected.push({
              title: candidates[idx].title,
              startTime: candidates[idx].startTime,
              endTime: candidates[idx].endTime
            });
          }
        });
        if (selected.length > 0) {
          await this.stateManager.importBulkTracks(selected);
          this.closeModal();
          this.activeTab = "tracks";
          this.menuEl?.querySelectorAll(".tm-tab").forEach((t) => t.classList.toggle("active", t.getAttribute("data-tab") === "tracks"));
          this.menuEl?.querySelectorAll(".tm-content-pane").forEach((p) => p.classList.toggle("active", p.id === "pane-tracks"));
          this.renderTrackList();
          const videoData = this.stateManager.getVideoData();
          if (videoData && videoData.tracks.length > 0) {
            await this.stateManager.selectTrack(videoData.tracks[0].id, false);
          }
        }
      });
    }
    closeModal() {
      if (this.currentModal) {
        this.currentModal.remove();
        this.currentModal = null;
      }
    }
    renderTrackList() {
      if (!this.menuEl) return;
      const listEl = this.menuEl.querySelector("#tm-track-list");
      if (!listEl) return;
      const videoData = this.stateManager.getVideoData();
      const allTracks = videoData?.tracks || [];
      const activeTrackId = this.stateManager.videoController.getState().activeTrack?.id;
      const signature = JSON.stringify({
        onlyFavs: this.showOnlyFavorites,
        tracks: allTracks.map((t) => ({ id: t.id, title: t.title, fav: t.isFavorite, s: t.startTime, e: t.endTime }))
      });
      if (signature === this.lastTracksSignature && listEl.children.length > 0) {
        this.updateActiveItemStyles();
        return;
      }
      this.lastTracksSignature = signature;
      const tracks = this.showOnlyFavorites ? allTracks.filter((t) => t.isFavorite) : allTracks;
      const countEl = this.menuEl.querySelector("#tm-list-count");
      if (countEl) {
        const favCount = allTracks.filter((t) => t.isFavorite).length;
        countEl.textContent = this.showOnlyFavorites ? `Favorites only (${tracks.length})` : `All tracks (${allTracks.length}${favCount > 0 ? ` \u2022 ${favCount} \u2605` : ""})`;
      }
      if (allTracks.length === 0) {
        listEl.innerHTML = `<div class="tm-empty">No tracks saved for this video.<br/>Use the detect tab or add one above.</div>`;
        return;
      }
      if (tracks.length === 0 && this.showOnlyFavorites) {
        listEl.innerHTML = `<div class="tm-empty">No favorite tracks in this video yet.<br/>Click the \u2605 icon on any track to mark it as favorite.</div>`;
        return;
      }
      listEl.innerHTML = tracks.map((track) => {
        const isActive = activeTrackId === track.id;
        const cleanSearchQuery = encodeURIComponent(track.title.replace(/[[\]()]/g, "").trim());
        const ytSearchUrl = `https://www.youtube.com/results?search_query=${cleanSearchQuery}`;
        const scSearchUrl = `https://soundcloud.com/search?q=${cleanSearchQuery}`;
        return `
      <div class="tm-track-item ${isActive ? "active" : ""}" data-id="${track.id}">
        <div class="tm-track-details">
          <div class="tm-track-name-wrap">
            <div class="tm-track-name">
              ${isActive ? '<span class="tm-active-badge">\u25B6</span> ' : ""}<span class="tm-title-inner">${track.title}</span>
            </div>
          </div>
          <div class="tm-track-meta">
            <span class="tm-track-range">${formatTime(track.startTime)} - ${formatTime(track.endTime)}</span>
            <div class="tm-track-search-links">
              <a href="${ytSearchUrl}" target="_blank" rel="noopener noreferrer" class="tm-search-link tm-search-yt" title="Search on YouTube" onclick="event.stopPropagation(); window.open('${ytSearchUrl}', '_blank'); return false;">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                YT
              </a>
              <a href="${scSearchUrl}" target="_blank" rel="noopener noreferrer" class="tm-search-link tm-search-sc" title="Search on SoundCloud" onclick="event.stopPropagation(); window.open('${scSearchUrl}', '_blank'); return false;">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M1.17 12.227c-.035 0-.067.03-.07.067L1 15.934c.003.04.035.066.07.066.039 0 .07-.027.07-.066l.102-3.64c-.004-.037-.035-.067-.07-.067zm1.196-.928c-.05 0-.09.04-.093.09l-.164 4.542c.003.05.043.09.093.09.047 0 .086-.04.086-.09l.168-4.542c0-.05-.039-.09-.09-.09zm1.22-.397c-.062 0-.113.05-.117.113l-.145 4.938c.004.062.055.113.117.113.059 0 .11-.05.11-.113l.148-4.938c0-.063-.05-.113-.113-.113zm1.23-.05c-.078 0-.14.062-.14.14l-.04 4.99c0 .077.062.14.14.14.075 0 .137-.063.137-.14l.043-4.99c0-.078-.062-.14-.14-.14zm1.246-.665c-.094 0-.172.079-.172.172v5.652c0 .094.078.172.172.172.094 0 .172-.078.172-.172v-5.652c0-.093-.078-.172-.172-.172zm1.274-1.28c-.11 0-.203.09-.203.204v6.933c0 .114.093.204.203.204.114 0 .207-.09.207-.204v-6.934c0-.113-.093-.203-.207-.203zm1.285-.567c-.129 0-.234.106-.234.235v7.504c0 .129.105.234.234.234.129 0 .235-.105.235-.234v-7.504c0-.129-.106-.235-.235-.235zm1.313-.488c-.145 0-.262.117-.262.262v7.992c0 .144.117.261.262.261.144 0 .261-.117.261-.261V7.852c0-.145-.117-.262-.261-.262zm1.32-.207c-.16 0-.293.133-.293.293v8.2c0 .16.133.293.293.293.16 0 .293-.133.293-.293v-8.2c0-.16-.133-.293-.293-.293zm1.344-.066c-.18 0-.324.148-.324.328v8.266c0 .18.144.328.324.328.18 0 .328-.148.328-.328V7.579c0-.18-.148-.328-.328-.328zm2.493-2.149c-.219 0-.414.043-.594.125-.133.062-.25.148-.351.25-.098.098-.18.211-.239.34-.058.125-.093.261-.105.406-.008.082-.012.164-.012.25v9.336c0 .137.05.266.14.36.095.093.223.144.36.144h7.02c1.785 0 3.234-1.45 3.234-3.235 0-1.687-1.293-3.078-2.953-3.219-.242-2.484-2.336-4.41-4.887-4.41-.531 0-1.047.086-1.531.25-.028-.012-.055-.027-.082-.043z"/></svg>
                SC
              </a>
            </div>
          </div>
        </div>
        <div class="tm-track-actions">
          <button class="tm-btn-fav ${track.isFavorite ? "starred" : ""}" data-id="${track.id}" title="${track.isFavorite ? "Remove from favorites" : "Add to favorites"}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="${track.isFavorite ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
          </button>
          <button class="tm-btn-del" data-id="${track.id}" title="Delete">\u{1F5D1}\uFE0F</button>
        </div>
      </div>
    `;
      }).join("");
      listEl.querySelectorAll(".tm-track-item").forEach((item) => {
        const trackId = item.dataset.id;
        if (!trackId) return;
        item.addEventListener("click", async (e) => {
          const target = e.target;
          if (target.closest(".tm-btn-fav") || target.closest(".tm-btn-del") || target.closest(".tm-search-link")) {
            return;
          }
          await this.stateManager.selectTrack(trackId, true);
        });
      });
      setTimeout(() => {
        listEl.querySelectorAll(".tm-track-item").forEach((item) => {
          const innerEl = item.querySelector(".tm-title-inner");
          const wrapEl = item.querySelector(".tm-track-name-wrap");
          if (innerEl && wrapEl && wrapEl.clientWidth > 0) {
            if (innerEl.scrollWidth > wrapEl.clientWidth + 4) {
              const overflowDiff = innerEl.scrollWidth - wrapEl.clientWidth + 16;
              innerEl.classList.add("overflowing");
              innerEl.style.setProperty("--marquee-dist", `-${overflowDiff}px`);
            } else {
              innerEl.classList.remove("overflowing");
            }
          }
        });
      }, 50);
      listEl.querySelectorAll(".tm-btn-fav").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          e.stopPropagation();
          const trackId = btn.dataset.id;
          if (trackId) {
            await this.stateManager.toggleFavorite(trackId);
            this.lastFavsSignature = "";
            this.renderTrackList();
          }
        });
      });
      listEl.querySelectorAll(".tm-btn-del").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          e.stopPropagation();
          const trackId = btn.dataset.id;
          if (trackId) {
            await this.stateManager.deleteTrack(trackId);
            this.lastFavsSignature = "";
            this.renderTrackList();
          }
        });
      });
    }
    updateStateView() {
      if (!this.menuEl) return;
      const controllerState = this.stateManager.videoController.getState();
      const activeTrack = controllerState.activeTrack;
      const isLoopActive = controllerState.isLoopActive;
      const titleEl = this.menuEl.querySelector("#tm-active-title");
      const timesEl = this.menuEl.querySelector("#tm-active-times");
      const loopBtn = this.menuEl.querySelector("#tm-loop-btn");
      if (titleEl) {
        titleEl.textContent = activeTrack ? activeTrack.title : "No track selected";
      }
      if (timesEl) {
        timesEl.textContent = activeTrack ? `${formatTime(activeTrack.startTime)} - ${formatTime(activeTrack.endTime)}` : "Select or add a track below";
      }
      if (loopBtn) {
        loopBtn.className = `tm-toggle-loop ${isLoopActive ? "active" : ""}`;
        loopBtn.textContent = isLoopActive ? "Loop active" : "Loop disabled";
      }
      this.updateActiveItemStyles();
    }
    lastScrolledTrackId = null;
    updateActiveItemStyles() {
      if (!this.menuEl) return;
      const activeTrackId = this.stateManager.videoController.getState().activeTrack?.id;
      let activeElementToScroll = null;
      this.menuEl.querySelectorAll(".tm-track-item").forEach((item) => {
        const id = item.dataset.id;
        const nameEl = item.querySelector(".tm-track-name");
        const badge = nameEl?.querySelector(".tm-active-badge");
        if (id === activeTrackId) {
          item.classList.add("active");
          activeElementToScroll = item;
          if (!badge && nameEl) {
            nameEl.insertAdjacentHTML("afterbegin", '<span class="tm-active-badge">\u25B6</span> ');
          }
        } else {
          item.classList.remove("active");
          if (badge) {
            badge.remove();
          }
        }
      });
      if (activeTrackId && activeTrackId !== this.lastScrolledTrackId && activeElementToScroll) {
        this.lastScrolledTrackId = activeTrackId;
        activeElementToScroll.scrollIntoView({
          behavior: "smooth",
          block: "nearest"
        });
      } else if (!activeTrackId) {
        this.lastScrolledTrackId = null;
      }
    }
    updateActiveFavItemStyles() {
      if (!this.menuEl) return;
      const currentVideoId = this.stateManager.getVideoData()?.videoId;
      const activeTrackId = this.stateManager.videoController.getState().activeTrack?.id;
      this.menuEl.querySelectorAll(".tm-fav-item").forEach((itemEl) => {
        const vId = itemEl.dataset.videoId;
        const tId = itemEl.dataset.trackId;
        const isCurrentVideo = Boolean(vId && currentVideoId && vId === currentVideoId);
        const isCurrentlyActive = Boolean(isCurrentVideo && tId && tId === activeTrackId);
        itemEl.classList.toggle("active", isCurrentlyActive);
        const trackNameEl = itemEl.querySelector(".tm-fav-track-name");
        if (trackNameEl) {
          const badge = trackNameEl.querySelector(".tm-active-badge");
          if (isCurrentlyActive && !badge) {
            trackNameEl.insertAdjacentHTML("afterbegin", '<span class="tm-active-badge">\u25B6</span> ');
          } else if (!isCurrentlyActive && badge) {
            badge.remove();
          }
        }
        const videoNameEl = itemEl.querySelector(".tm-fav-video-name");
        if (videoNameEl) {
          const hereBadge = videoNameEl.querySelector(".tm-fav-here-badge");
          if (isCurrentVideo && !hereBadge) {
            videoNameEl.insertAdjacentHTML("afterbegin", '<span class="tm-fav-here-badge">Playing here</span> ');
          } else if (!isCurrentVideo && hereBadge) {
            hereBadge.remove();
          }
        }
      });
    }
    async renderFavsList() {
      if (!this.menuEl) return;
      const listEl = this.menuEl.querySelector("#tm-favs-list");
      const countBadge = this.menuEl.querySelector("#tm-favs-total-count");
      if (!listEl) return;
      const allData = await StorageManager.getAllData();
      const currentVideoId = this.stateManager.getVideoData()?.videoId;
      const favorites = [];
      for (const [key, val] of Object.entries(allData)) {
        if (key.startsWith("__tm_")) continue;
        const videoData = val;
        if (videoData && Array.isArray(videoData.tracks)) {
          for (const track of videoData.tracks) {
            if (track.isFavorite) {
              favorites.push({
                videoId: key,
                videoTitle: videoData.videoTitle || "YouTube Video",
                track
              });
            }
          }
        }
      }
      favorites.sort((a, b) => (b.track.updatedAt || 0) - (a.track.updatedAt || 0));
      if (countBadge) {
        countBadge.textContent = `${favorites.length} track${favorites.length === 1 ? "" : "s"}`;
      }
      const signature = favorites.map((f) => `${f.videoId}:${f.track.id}:${f.track.updatedAt || 0}:${f.track.isFavorite}`).join("|");
      if (signature === this.lastFavsSignature && listEl.children.length > 0) {
        this.updateActiveFavItemStyles();
        return;
      }
      this.lastFavsSignature = signature;
      if (favorites.length === 0) {
        listEl.innerHTML = `
        <div class="tm-empty">
          <div style="font-size: 22px; margin-bottom: 6px;">\u2B50</div>
          No favorite tracks saved yet.<br/>
          Star any track from your videos to build your personal library.
        </div>
      `;
        return;
      }
      listEl.innerHTML = favorites.map((fav) => {
        const isCurrentVideo = fav.videoId === currentVideoId;
        const activeTrackId = this.stateManager.videoController.getState().activeTrack?.id;
        const isCurrentlyActive = isCurrentVideo && activeTrackId === fav.track.id;
        const cleanSearchQuery = encodeURIComponent(fav.track.title.replace(/[[\]()]/g, "").trim());
        const ytSearchUrl = `https://www.youtube.com/results?search_query=${cleanSearchQuery}`;
        const scSearchUrl = `https://soundcloud.com/search?q=${cleanSearchQuery}`;
        return `
        <div class="tm-fav-item ${isCurrentlyActive ? "active" : ""}" data-video-id="${fav.videoId}" data-track-id="${fav.track.id}" data-start="${fav.track.startTime}">
          <div class="tm-fav-content">
            <div class="tm-fav-video-meta">
              <span class="tm-fav-video-name" title="${fav.videoTitle}">
                ${isCurrentVideo ? '<span class="tm-fav-here-badge">Playing here</span> ' : ""}${fav.videoTitle}
              </span>
            </div>
            <div class="tm-fav-track-name">
              ${isCurrentlyActive ? '<span class="tm-active-badge">\u25B6</span> ' : ""}${fav.track.title}
            </div>
            <div class="tm-fav-meta-row">
              <span class="tm-track-range">${formatTime(fav.track.startTime)} - ${formatTime(fav.track.endTime)}</span>
              <div class="tm-track-search-links">
                <a href="${ytSearchUrl}" target="_blank" rel="noopener noreferrer" class="tm-search-link tm-search-yt" title="Search on YouTube" onclick="event.stopPropagation(); window.open('${ytSearchUrl}', '_blank'); return false;">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                  YT
                </a>
                <a href="${scSearchUrl}" target="_blank" rel="noopener noreferrer" class="tm-search-link tm-search-sc" title="Search on SoundCloud" onclick="event.stopPropagation(); window.open('${scSearchUrl}', '_blank'); return false;">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M1.17 12.227c-.035 0-.067.03-.07.067L1 15.934c.003.04.035.066.07.066.039 0 .07-.027.07-.066l.102-3.64c-.004-.037-.035-.067-.07-.067zm1.196-.928c-.05 0-.09.04-.093.09l-.164 4.542c.003.05.043.09.093.09.047 0 .086-.04.086-.09l.168-4.542c0-.05-.039-.09-.09-.09zm1.22-.397c-.062 0-.113.05-.117.113l-.145 4.938c.004.062.055.113.117.113.059 0 .11-.05.11-.113l.148-4.938c0-.063-.05-.113-.113-.113zm1.23-.05c-.078 0-.14.062-.14.14l-.04 4.99c0 .077.062.14.14.14.075 0 .137-.063.137-.14l.043-4.99c0-.078-.062-.14-.14-.14zm1.246-.665c-.094 0-.172.079-.172.172v5.652c0 .094.078.172.172.172.094 0 .172-.078.172-.172v-5.652c0-.093-.078-.172-.172-.172zm1.274-1.28c-.11 0-.203.09-.203.204v6.933c0 .114.093.204.203.204.114 0 .207-.09.207-.204v-6.934c0-.113-.093-.203-.207-.203zm1.285-.567c-.129 0-.234.106-.234.235v7.504c0 .129.105.234.234.234.129 0 .235-.105.235-.234v-7.504c0-.129-.106-.235-.235-.235zm1.313-.488c-.145 0-.262.117-.262.262v7.992c0 .144.117.261.262.261.144 0 .261-.117.261-.261V7.852c0-.145-.117-.262-.261-.262zm1.32-.207c-.16 0-.293.133-.293.293v8.2c0 .16.133.293.293.293.16 0 .293-.133.293-.293v-8.2c0-.16-.133-.293-.293-.293zm1.344-.066c-.18 0-.324.148-.324.328v8.266c0 .18.144.328.324.328.18 0 .328-.148.328-.328V7.579c0-.18-.148-.328-.328-.328zm2.493-2.149c-.219 0-.414.043-.594.125-.133.062-.25.148-.351.25-.098.098-.18.211-.239.34-.058.125-.093.261-.105.406-.008.082-.012.164-.012.25v9.336c0 .137.05.266.14.36.095.093.223.144.36.144h7.02c1.785 0 3.234-1.45 3.234-3.235 0-1.687-1.293-3.078-2.953-3.219-.242-2.484-2.336-4.41-4.887-4.41-.531 0-1.047.086-1.531.25-.028-.012-.055-.027-.082-.043z"/></svg>
                  SC
                </a>
              </div>
            </div>
          </div>
          <div class="tm-fav-actions">
            <button class="tm-btn-fav starred" data-video-id="${fav.videoId}" data-track-id="${fav.track.id}" title="Remove from favorites">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
              </svg>
            </button>
            <button class="tm-btn-del" data-video-id="${fav.videoId}" data-track-id="${fav.track.id}" title="Delete track">\u{1F5D1}\uFE0F</button>
          </div>
        </div>
      `;
      }).join("");
      if (!listEl.dataset.hasFavListeners) {
        listEl.dataset.hasFavListeners = "true";
        listEl.addEventListener("click", async (e) => {
          const target = e.target;
          if (target.closest(".tm-search-link")) return;
          const favBtn = target.closest(".tm-btn-fav");
          if (favBtn) {
            e.stopPropagation();
            const vId = favBtn.dataset.videoId;
            const tId = favBtn.dataset.trackId;
            if (!vId || !tId) return;
            const currentVid = this.stateManager.getVideoData()?.videoId;
            if (vId === currentVid) {
              await this.stateManager.toggleFavorite(tId);
            } else {
              await StorageManager.toggleFavorite(vId, tId);
            }
            this.lastFavsSignature = "";
            await this.renderFavsList();
            this.renderTrackList();
            return;
          }
          const delBtn = target.closest(".tm-btn-del");
          if (delBtn) {
            e.stopPropagation();
            const vId = delBtn.dataset.videoId;
            const tId = delBtn.dataset.trackId;
            if (!vId || !tId) return;
            const currentVid = this.stateManager.getVideoData()?.videoId;
            if (vId === currentVid) {
              await this.stateManager.deleteTrack(tId);
            } else {
              await StorageManager.deleteTrack(vId, tId);
            }
            this.lastFavsSignature = "";
            await this.renderFavsList();
            this.renderTrackList();
            return;
          }
          const itemEl = target.closest(".tm-fav-item");
          if (itemEl) {
            const vId = itemEl.dataset.videoId;
            const tId = itemEl.dataset.trackId;
            const start = Number(itemEl.dataset.start || 0);
            if (!vId) return;
            const currentVid = this.stateManager.getVideoData()?.videoId;
            if (vId === currentVid) {
              if (tId) {
                await this.stateManager.selectTrack(tId, true);
                await this.stateManager.setLoop(true);
                this.updateActiveFavItemStyles();
              }
            } else {
              const targetUrl = `https://www.youtube.com/watch?v=${vId}&t=${Math.floor(start)}s`;
              window.location.href = targetUrl;
            }
          }
        });
      }
    }
  };

  // src/ui/player-button.ts
  var PlayerButton = class {
    floatingMenu;
    buttonEl = null;
    observer = null;
    constructor(floatingMenu) {
      this.floatingMenu = floatingMenu;
      this.init();
    }
    init() {
      const oldStyles = document.getElementById("tm-btn-styles");
      if (oldStyles) oldStyles.remove();
      this.tryInject();
      this.observer = new MutationObserver(() => {
        if (!this.buttonEl || !document.contains(this.buttonEl)) {
          this.tryInject();
        }
      });
      const moviePlayer = document.querySelector("#movie_player") || document.body;
      if (moviePlayer) {
        this.observer.observe(moviePlayer, { childList: true, subtree: true });
      }
    }
    tryInject() {
      const rightControls = document.querySelector(".ytp-right-controls");
      if (!rightControls) return false;
      if (document.querySelector(".ytp-trackmark-button")) {
        return true;
      }
      const subtitlesBtn = rightControls.querySelector(".ytp-subtitles-button");
      const button = document.createElement("button");
      button.className = "ytp-button ytp-trackmark-button";
      button.title = "TrackMark";
      button.setAttribute("aria-label", "TrackMark");
      button.style.background = "transparent";
      button.style.border = "none";
      button.style.outline = "none";
      button.style.padding = "0";
      button.style.cursor = "pointer";
      button.style.display = "inline-flex";
      button.style.alignItems = "center";
      button.style.justifyContent = "center";
      button.style.verticalAlign = "top";
      button.style.opacity = "0.9";
      button.style.transition = "opacity 0.15s ease, transform 0.15s ease";
      button.innerHTML = `
      <img src="${TM_LOGO_DATA_URI}" style="width: 22px; height: 22px; object-fit: contain; pointer-events: none; display: block; user-select: none;" alt="TM" />
    `;
      button.addEventListener("mouseenter", () => {
        button.style.opacity = "1";
        button.style.transform = "scale(1.12)";
      });
      button.addEventListener("mouseleave", () => {
        button.style.opacity = "0.9";
        button.style.transform = "scale(1)";
      });
      const handleClick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        this.floatingMenu.toggle();
      };
      button.addEventListener("click", handleClick);
      if (subtitlesBtn && subtitlesBtn.parentNode === rightControls) {
        rightControls.insertBefore(button, subtitlesBtn);
      } else {
        rightControls.prepend(button);
      }
      this.buttonEl = button;
      return true;
    }
    destroy() {
      if (this.observer) {
        this.observer.disconnect();
      }
      if (this.buttonEl) {
        this.buttonEl.remove();
        this.buttonEl = null;
      }
    }
  };

  // src/ui/timeline-markers.ts
  var TimelineMarkers = class {
    stateManager;
    containerEl = null;
    observer = null;
    constructor(stateManager) {
      this.stateManager = stateManager;
      this.init();
    }
    init() {
      this.injectContainer();
      this.observer = new MutationObserver(() => {
        if (!this.containerEl || !document.contains(this.containerEl)) {
          this.injectContainer();
        }
      });
      const moviePlayer = document.querySelector("#movie_player") || document.body;
      if (moviePlayer) {
        this.observer.observe(moviePlayer, { childList: true, subtree: true });
      }
      this.stateManager.subscribe(() => {
        this.renderMarkers();
      });
    }
    injectContainer() {
      const progressBar = document.querySelector(".ytp-progress-bar-container") || document.querySelector(".ytp-progress-bar");
      if (!progressBar) return false;
      let container = progressBar.querySelector(".tm-timeline-markers");
      if (!container) {
        container = document.createElement("div");
        container.className = "tm-timeline-markers";
        container.style.position = "absolute";
        container.style.inset = "0";
        container.style.pointerEvents = "none";
        container.style.zIndex = "45";
        progressBar.appendChild(container);
      }
      this.containerEl = container;
      this.renderMarkers();
      return true;
    }
    renderMarkers() {
      if (!this.containerEl) {
        this.injectContainer();
        if (!this.containerEl) return;
      }
      const videoData = this.stateManager.getVideoData();
      const duration = this.stateManager.videoController.getDuration();
      const activeTrack = this.stateManager.videoController.getState().activeTrack;
      if (!videoData || !duration || duration <= 0 || videoData.tracks.length === 0) {
        this.containerEl.innerHTML = "";
        return;
      }
      this.containerEl.innerHTML = videoData.tracks.map((track) => {
        const leftPct = track.startTime / duration * 100;
        const widthPct = Math.max(0.4, (track.endTime - track.startTime) / duration * 100);
        const isActive = activeTrack?.id === track.id;
        return `
        <div class="tm-timeline-seg ${isActive ? "active" : ""}"
             data-id="${track.id}"
             title="${track.title} (${formatTime(track.startTime)} - ${formatTime(track.endTime)})"
             style="
               position: absolute;
               left: ${leftPct}%;
               width: ${widthPct}%;
               top: 0;
               bottom: 0;
               background: ${isActive ? "rgba(0, 240, 255, 0.45)" : "rgba(5, 255, 161, 0.2)"};
               border-left: 2px solid ${isActive ? "#00f0ff" : "#05ffa1"};
               border-right: ${isActive ? "2px solid #00f0ff" : "none"};
               box-shadow: ${isActive ? "0 0 8px rgba(0, 240, 255, 0.8)" : "none"};
               pointer-events: none;
               transition: all 0.2s ease;
             ">
          <div style="
            position: absolute;
            left: 0;
            top: -2px;
            width: 5px;
            height: 5px;
            background: ${isActive ? "#00f0ff" : "#05ffa1"};
            border-radius: 50%;
            transform: translateX(-50%);
            box-shadow: 0 0 6px ${isActive ? "#00f0ff" : "#05ffa1"};
          "></div>
        </div>
      `;
      }).join("");
    }
    destroy() {
      if (this.observer) {
        this.observer.disconnect();
      }
      if (this.containerEl) {
        this.containerEl.remove();
        this.containerEl = null;
      }
    }
  };

  // src/content/index.ts
  function initTrackMark() {
    const stateManager = new StateManager();
    const floatingMenu = new FloatingMenu(stateManager);
    const playerButton = new PlayerButton(floatingMenu);
    const timelineMarkers = new TimelineMarkers(stateManager);
    window.__trackmark = {
      stateManager,
      floatingMenu,
      playerButton,
      timelineMarkers,
      videoController: stateManager.videoController,
      spaNavigator: stateManager.spaNavigator
    };
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initTrackMark);
  } else {
    initTrackMark();
  }
})();
